# AI-FishBot WPF v3

Ez a C# / WPF újraírás a v2.9 WinForms-kijelölési hibái helyett stabil objektumazonosítókat használ.

Indítás: `bin\Release\AI-FishBot-WPF-v3.exe`

- A **Kliensvezérlés** táblában egy sorra kattintva a `SelectedItem` lesz a vezérelt kliens. A START, PAUSE és STOP csak erre az egy kliensre hat.
- Minden kliensprofil saját GUID-t, PID-et, billentyűket, két buffot, reconnect-jelszót és SavedVariables-útvonalat kap. A jelszó PID-profilonként, Windows DPAPI-val titkosítva mentődik.
- Az F7 küldése után a közös input-koordinátor legalább **350 ms**-ig nem enged új fókuszváltást. Az érték az Advanced fülön `General.LootAfterBobberMilliseconds` néven állítható.
- Az **Itemek és árak** fül a ténylegesen kijelölt itemet mutatja. Az itemek egységára külön menthető.
- A dashboard órás mutatói a közös session eltelt idejével számolnak; nem adják össze a kliensek óráit. A Wyrmfish/kiemelt hal neve az Advanced fülön `Loot.HighlightFishName`.
- A célösszeg és az eddig jóváírt, árazott lootérték mentődik az `ai-fishbot-wpf-settings.json` fájlba, így kilépés után is megmarad.
- A Blizzard API fül menti a Client ID-t és a Client Secretet. A Secret DPAPI-val védett, és később üres mezővel is a mentett értéket használja.
- Az **Advanced** fülön 106 örökölt globális beállítás szerkeszthető. Egyéni kulcs is felvehető és törölhető, tehát a WPF-beállítások módosításához nem kell megnyitni a forráskódot.

## Loot adatforrás

Kliensenként add meg az addon `AIFishLootTracker.lua` SavedVariables-fájljának útvonalát. A WPF alkalmazás az `AIFishLootCounts` táblát olvassa, és fájlmódosításkor frissíti a listát.

## Build

A mellékelt `.csproj` .NET Framework 4.8 WPF projekt. A kiadott EXE-t ezen a gépen a telepített .NET Framework fordítóval ellenőriztem. Visual Studio / Build Tools telepítése esetén a projekt közvetlenül megnyitható és fordítható.

Az új v3 a konfigurációt, PID-profilt, UI-állapotot, input-sorrendet, loot/ár/célstatisztikát különíti el. Emiatt nem örökli a régi WinForms sorindex-cache hibáját.
