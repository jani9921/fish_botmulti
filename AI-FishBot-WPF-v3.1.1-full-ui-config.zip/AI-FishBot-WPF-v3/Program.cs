// AI-FishBot WPF v3: stable, ID-based client/UI state. Requires .NET Framework 4.8.
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Threading;
using Forms = System.Windows.Forms;

namespace AIFishBotWpf {
  public class Notify : INotifyPropertyChanged {
    public event PropertyChangedEventHandler PropertyChanged;
    protected void Changed(string n) { var h = PropertyChanged; if (h != null) h(this, new PropertyChangedEventArgs(n)); }
  }
  public sealed class BuffProfile : Notify {
    bool _enabled; string _key = "F9"; int _cast = 1; int _duration = 5;
    public bool Enabled { get { return _enabled; } set { _enabled=value; Changed("Enabled"); } }
    public string Key { get { return _key; } set { _key=value ?? ""; Changed("Key"); } }
    public int CastSeconds { get { return _cast; } set { _cast=Math.Max(0,value); Changed("CastSeconds"); } }
    public int DurationMinutes { get { return _duration; } set { _duration=Math.Max(0,value); Changed("DurationMinutes"); } }
  }
  public sealed class ClientProfile : Notify {
    string _id = Guid.NewGuid().ToString("N"), _title="", _state="STOPPED", _cast="F6", _bobber="F7", _logout="F8", _lootFile="", _status="Ready";
    int _pid; bool _enabled=true; double _active; Dictionary<string,int> _loot = new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
    public string Id { get { return _id; } set { _id=value; Changed("Id"); } }
    public int Pid { get { return _pid; } set { _pid=value; Changed("Pid"); Changed("PidText"); } }
    public string PidText { get { return Pid == 0 ? "–" : Pid.ToString(); } }
    public string WindowTitle { get { return _title; } set { _title=value ?? ""; Changed("WindowTitle"); } }
    public bool Enabled { get { return _enabled; } set { _enabled=value; Changed("Enabled"); } }
    public string ControlState { get { return _state; } set { _state=value; Changed("ControlState"); Changed("IsRunning"); } }
    public bool IsRunning { get { return ControlState=="RUNNING"; } }
    public string CastKey { get { return _cast; } set { _cast=value ?? ""; Changed("CastKey"); } }
    public string BobberKey { get { return _bobber; } set { _bobber=value ?? ""; Changed("BobberKey"); } }
    public string LogoutKey { get { return _logout; } set { _logout=value ?? ""; Changed("LogoutKey"); } }
    public string PasswordProtected { get; set; }
    public string SavedVariablesPath { get { return _lootFile; } set { _lootFile=value ?? ""; Changed("SavedVariablesPath"); } }
    public string Status { get { return _status; } set { _status=value ?? ""; Changed("Status"); } }
    public double ActiveSeconds { get { return _active; } set { _active=value; Changed("ActiveSeconds"); } }
    public ClientProfile() { Buff1=new BuffProfile { Key="F9", CastSeconds=1, DurationMinutes=5 }; Buff2=new BuffProfile { Key="F10", CastSeconds=5, DurationMinutes=30 }; }
    public BuffProfile Buff1 { get; set; }
    public BuffProfile Buff2 { get; set; }
    public Dictionary<string,int> Loot { get { return _loot; } set { _loot=value ?? new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase); } }
    public DateTime LastLootReadUtc { get; set; }
    public DateTime NextActionUtc { get; set; }
  }
  public sealed class ItemRow : Notify {
    string _name; int _id, _quantity; double _price, _min, _max, _average;
    public string Name { get { return _name; } set { _name=value; Changed("Name"); } }
    public int ItemId { get { return _id; } set { _id=value; Changed("ItemId"); } }
    public int Quantity { get { return _quantity; } set { _quantity=value; Changed("Quantity"); Changed("TotalGold"); } }
    public double UnitGold { get { return _price; } set { _price=value; Changed("UnitGold"); Changed("TotalGold"); } }
    public double TotalGold { get { return Quantity*UnitGold; } }
    public double MinGold { get { return _min; } set { _min=value; Changed("MinGold"); } }
    public double MaxGold { get { return _max; } set { _max=value; Changed("MaxGold"); } }
    public double AverageGold { get { return _average; } set { _average=value; Changed("AverageGold"); } }
    public string Signal { get { return UnitGold>0 ? "ÁRAZVA" : "NINCS ÁR"; } }
  }
  public sealed class AdvancedRow : Notify { public string Category {get;set;} public string Path {get;set;} public string Value {get;set;} public string Description {get;set;} }
  public sealed class AppSettings {
    public AppSettings() { Version=3; Clients=new List<ClientProfile>(); Advanced=Defaults.Advanced(); Prices=new Dictionary<string,double>(StringComparer.OrdinalIgnoreCase); Prices["Wyrmfish"]=62; ItemIds=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase); BlizzardClientId=""; BlizzardSecretProtected=""; TargetHuf=100000; AccountedLoot=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase); }
    public int Version {get;set;}
    public List<ClientProfile> Clients {get;set;}
    public Dictionary<string,string> Advanced {get;set;}
    public Dictionary<string,double> Prices {get;set;}
    public Dictionary<string,int> ItemIds {get;set;}
    public string BlizzardClientId {get;set;}
    public string BlizzardSecretProtected {get;set;}
    public double TargetHuf {get;set;}
    public double TargetEarnedHuf {get;set;}
    public Dictionary<string,int> AccountedLoot {get;set;}
    public double TotalSessionSeconds {get;set;}
  }
  public static class Defaults {
    public static Dictionary<string,string> Advanced() { return new Dictionary<string,string> {
      {"General.Retail","true"},{"General.AutoStop","false"},{"General.AutoStopMinutes","3000"},{"General.AutoLogout","false"},{"General.UseWindowFocus","true"},{"General.FishingRetries","15"},{"General.UseWeakAura","false"},{"General.CastKey","F6"},{"General.BobberKey","F7"},{"General.LogoutKey","F8"},{"General.LootWaitSeconds","2.0"},{"General.NoBiteStreakLimit","10"},{"General.NoCatchWarningMinutes","15"},{"General.FishRateDropThresholdPct","50"},{"General.MaxClients","8"},{"General.ProcessCheckIntervalSeconds","3"},{"General.FocusSettleMilliseconds","35"},{"General.LootAfterBobberMilliseconds","350"},
      {"Client.UsePi","false"},{"Client.PicoComPort","COM6"},{"Client.KeybindConfigPath","client-keybinds.json"},{"Client.GuiSettingsPath","ai-fishbot-wpf-settings.json"},{"Client.BuffsEnabled","1"},{"Client.Buffs.1.Keybind","F9"},{"Client.Buffs.1.CastTimeSeconds","1"},{"Client.Buffs.1.DurationMinutes","5"},{"Client.Buffs.2.Keybind","F10"},{"Client.Buffs.2.CastTimeSeconds","5"},{"Client.Buffs.2.DurationMinutes","30"},
      {"Audio.Sensitivity","1"},{"Audio.PollIntervalMs","100"},
      {"Recovery.Enabled","true"},{"Recovery.NetworkPollSeconds","2"},{"Recovery.NetworkLearnTimeoutSeconds","30"},{"Recovery.DisconnectConfirmSeconds","12"},{"Recovery.StableConnectionSeconds","5"},{"Recovery.MaxAttempts","3"},{"Recovery.BackoffSeconds","15,30,60"},{"Recovery.AllowPasswordTyping","false"},{"Recovery.FallbackToNoBiteOnly","false"},{"Recovery.ServerPorts",""},{"Recovery.IgnoreRemotePorts","80,443"},{"Recovery.ActionPlan.0.Name","Reconnect"},{"Recovery.ActionPlan.0.Type","Key"},{"Recovery.ActionPlan.0.Key","ENTER"},{"Recovery.ActionPlan.0.WaitForConnectionSeconds","8"},{"Recovery.ActionPlan.1.Name","Password"},{"Recovery.ActionPlan.1.Type","Password"},{"Recovery.ActionPlan.1.Key",""},{"Recovery.ActionPlan.1.WaitForConnectionSeconds","12"},{"Recovery.ActionPlan.2.Name","Confirm"},{"Recovery.ActionPlan.2.Type","Key"},{"Recovery.ActionPlan.2.Key","ENTER"},{"Recovery.ActionPlan.2.WaitForConnectionSeconds","15"},
      {"Loot.Enabled","true"},{"Loot.ReloadEveryCatches","10"},{"Loot.MaxUnsyncedMinutes","3"},{"Loot.CatchJournalEnabled","true"},{"Loot.RequiredAddonVersion","1.3"},{"Loot.HighlightFishName","Wyrmfish"},{"Loot.ReloadSettleSeconds","4"},{"Loot.ReloadSpacingSeconds","8"},{"Loot.BindTimeoutSeconds","15"},{"Loot.BindMaxRetries","3"},
      {"Price.GameVersion","retail"},{"Price.Region","eu"},{"Price.Realm","Ragnaros"},{"Price.Faction","Horde"},{"Price.Item","Wyrmfish"},{"Price.ImportPollSeconds","5"},{"Price.FallbackPrice","62"},{"Price.BlizzardEnabled","true"},{"Price.ConnectedRealmId",""},{"Price.BlizzardRefreshMinutes","60"},{"Price.BlizzardRetryMinutes","5"},{"Price.BlizzardTimeoutSeconds","180"},{"Price.BlizzardPriceMetric","MinimumBuyout"},{"Price.BlizzardCachePath","blizzard-ah-price-cache.json"},{"Price.PriceHistoryPath","blizzard-ah-price-history.csv"},{"Price.PriceHistoryMaxDays","120"},{"Price.SellMinimumSamples","12"},{"Price.SellMinimumDistinctDays","3"},{"Price.SellNowPercentile","0.75"},{"Price.SellExpectedRisePct","5"},{"Price.AdditionalItemPrices",""},{"Price.BootyBayBrokerUrl","https://bootybaybroker.com/inventory-price-check"},{"Price.InventoryExportPath","bootybaybroker-catches.json"},{"Price.PriceImportPath","bootybaybroker-price-import.csv"},
      {"Revenue.GoldPerEuro","25000"},{"Revenue.EurToHuf","400"},{"Target.TargetHuf","100000"},{"Gui.MonitorIntervalMs","100"},{"Gui.RefreshIntervalMs","1000"},{"Gui.ReportIntervalSeconds","60"},{"Gui.AlertHistoryLimit","200"},{"Gui.AlertDisplayCount","20"},{"Notification.Enabled","false"},{"Notification.DiscordWebhook",""},{"Notification.OnStart","true"},{"Notification.OnStop","true"},{"Notification.ThrottleMinutes","10"},{"Notification.TimeoutSeconds","5"},{"Logging.Enabled","true"},{"Logging.Directory","logs"},{"Logging.Debug","false"},{"Logging.ErrorThrottleSeconds","30"}
    }; }
  }
  public static class SecureStore {
    public static string Protect(string plain) { if(string.IsNullOrEmpty(plain)) return ""; return Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(plain), null, DataProtectionScope.CurrentUser)); }
    public static string Unprotect(string protectedValue) { try { return string.IsNullOrEmpty(protectedValue) ? "" : Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(protectedValue),null,DataProtectionScope.CurrentUser)); } catch { return ""; } }
  }
  public sealed class SettingsStore {
    readonly string _path; readonly JavaScriptSerializer _json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
    public SettingsStore() { _path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"ai-fishbot-wpf-settings.json"); }
    public AppSettings Load() { try { return _json.Deserialize<AppSettings>(File.ReadAllText(_path,Encoding.UTF8)) ?? new AppSettings(); } catch { return new AppSettings(); } }
    public void Save(AppSettings s) { var text=_json.Serialize(s); File.WriteAllText(_path,text,new UTF8Encoding(false)); }
  }
  public sealed class InputCoordinator {
    readonly object _gate=new object(); DateTime _focusLockedUntilUtc=DateTime.MinValue;
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);
    public bool Send(ClientProfile client, string key, int settleMs, int postBobberMs) {
      lock(_gate) {
        var now=DateTime.UtcNow;
        if(now<_focusLockedUntilUtc || now<client.NextActionUtc) return false;
        try {
          var p=Process.GetProcessById(client.Pid); if(p.HasExited || p.MainWindowHandle==IntPtr.Zero) { client.Status="Ablak nem elérhető"; return false; }
          SetForegroundWindow(p.MainWindowHandle); Thread.Sleep(Math.Max(0,settleMs)); Forms.SendKeys.SendWait(key);
          var delay=string.Equals(key,client.BobberKey,StringComparison.OrdinalIgnoreCase) ? Math.Max(300,postBobberMs) : 0;
          client.NextActionUtc=DateTime.UtcNow.AddMilliseconds(delay);
          if(delay>0) _focusLockedUntilUtc=client.NextActionUtc;
          client.Status=delay>0 ? "Loot várakozás " + delay + " ms" : "Billentyű elküldve";
          return true;
        } catch(Exception ex) { client.Status="Input hiba: "+ex.Message; return false; }
      }
    }
  }
  public sealed class MainWindow : Window {
    readonly SettingsStore _store=new SettingsStore(); readonly DispatcherTimer _timer=new DispatcherTimer(); readonly InputCoordinator _input=new InputCoordinator();
    AppSettings _settings; DateTime _sessionStartedUtc; ClientProfile _selectedClient; ItemRow _selectedItem;
    ObservableCollection<ClientProfile> _clients; ObservableCollection<ItemRow> _items=new ObservableCollection<ItemRow>(); ObservableCollection<AdvancedRow> _advanced=new ObservableCollection<AdvancedRow>();
    DataGrid _clientGrid,_itemGrid,_advancedGrid; TextBlock _runtime,_fishHour,_wyrmHour,_goldHour,_totalGold,_targetText,_itemDetails,_apiState,_selectedLabel; TextBox _password,_targetInput,_clientId,_secret; Action _clientEditorLoad;
    public MainWindow() {
      Title="AI-FishBot WPF v3"; Width=1500; Height=930; MinWidth=1120; MinHeight=720; Background=Brush("#101827");
      _settings=_store.Load(); NormalizeSettings(); _clients=new ObservableCollection<ClientProfile>(_settings.Clients ?? new List<ClientProfile>()); foreach(var p in _clients) Normalize(p);
      foreach(var pair in _settings.Advanced.OrderBy(x=>x.Key)) _advanced.Add(new AdvancedRow {Category=CategoryOf(pair.Key),Path=pair.Key,Value=pair.Value,Description=Describe(pair.Key)});
      Content=BuildUi(); _timer.Interval=TimeSpan.FromMilliseconds(500); _timer.Tick += delegate { Tick(); }; _timer.Start(); Closing += delegate { Persist(); };
      _sessionStartedUtc=DateTime.UtcNow; RefreshProcesses(); RebuildItems(); RefreshDashboard();
    }
    static SolidColorBrush Brush(string hex) { return (SolidColorBrush)new BrushConverter().ConvertFromString(hex); }
    static string Describe(string path) { return path.StartsWith("General.LootAfterBobber") ? "F7 után ennyi ms-ig nem fókuszál másik kliensre" : path.StartsWith("Target") ? "Célhaladás" : "Migrált advanced beállítás"; }
    static string CategoryOf(string path) { var key=(path??"").Split('.')[0]; switch(key) { case "General":return "Általános"; case "Client":return "Kliens / buff"; case "Audio":return "Hang"; case "Recovery":return "Reconnect"; case "Loot":return "Loot"; case "Price":return "Árak / AH"; case "Revenue":return "Bevétel"; case "Target":return "Cél"; case "Gui":return "GUI"; case "Notification":return "Értesítés"; case "Logging":return "Naplózás"; default:return "Egyéni"; } }
    void NormalizeSettings() { if(_settings.Advanced==null)_settings.Advanced=new Dictionary<string,string>(); foreach(var pair in Defaults.Advanced())if(!_settings.Advanced.ContainsKey(pair.Key))_settings.Advanced[pair.Key]=pair.Value; if(_settings.Prices==null)_settings.Prices=new Dictionary<string,double>(StringComparer.OrdinalIgnoreCase); if(_settings.ItemIds==null)_settings.ItemIds=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase); if(_settings.AccountedLoot==null)_settings.AccountedLoot=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase); if(_settings.Clients==null)_settings.Clients=new List<ClientProfile>(); }
    static void Normalize(ClientProfile p) { if(string.IsNullOrWhiteSpace(p.Id)) p.Id=Guid.NewGuid().ToString("N"); if(p.Buff1==null)p.Buff1=new BuffProfile(); if(p.Buff2==null)p.Buff2=new BuffProfile(); if(p.Loot==null)p.Loot=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase); }
    UIElement BuildUi() {
      var root=new DockPanel { Margin=new Thickness(18) }; var head=new StackPanel { Orientation=Orientation.Horizontal, Margin=new Thickness(0,0,0,14) };
      var title=new TextBlock { Text="AI-FishBot", FontSize=28, FontWeight=FontWeights.Bold, Foreground=Brush("#F8FAFC") }; head.Children.Add(title); head.Children.Add(new TextBlock {Text="  WPF v3 · stabil kliens- és itemkijelölés",VerticalAlignment=VerticalAlignment.Bottom,Margin=new Thickness(12,0,0,4),Foreground=Brush("#94A3B8"),FontSize=14}); DockPanel.SetDock(head,Dock.Top); root.Children.Add(head);
      var tabs=new TabControl { Background=Brush("#101827"), BorderBrush=Brush("#334155") }; tabs.Items.Add(Tab("Áttekintés",Dashboard())); tabs.Items.Add(Tab("Kliensvezérlés",Clients())); tabs.Items.Add(Tab("Itemek és árak",Items())); tabs.Items.Add(Tab("Advanced",Advanced())); tabs.Items.Add(Tab("Blizzard API",Api())); root.Children.Add(tabs); return root;
    }
    TabItem Tab(string title, UIElement content) { return new TabItem { Header=title, Content=content, Foreground=Brush("#E2E8F0"), Padding=new Thickness(15,7,15,7) }; }
    Border Card(string title, UIElement content) { var s=new StackPanel(); s.Children.Add(new TextBlock{Text=title.ToUpperInvariant(),Foreground=Brush("#94A3B8"),FontWeight=FontWeights.SemiBold,FontSize=11,Margin=new Thickness(0,0,0,9)}); s.Children.Add(content); return new Border{Background=Brush("#182235"),CornerRadius=new CornerRadius(12),Padding=new Thickness(17),Margin=new Thickness(6),Child=s}; }
    UIElement Dashboard() { var panel=new StackPanel{Margin=new Thickness(10)}; var cards=new WrapPanel(); _runtime=Metric("KÖZÖS FUTÁSIDŐ","00:00:00"); _fishHour=Metric("FISH / ÓRA","0"); _wyrmHour=Metric("WYRMFISH / ÓRA","0"); _goldHour=Metric("GOLD / ÓRA","0"); _totalGold=Metric("ÖSSZÉRTÉK","0 g"); _targetText=Metric("CÉL","0 / 0 Ft"); foreach(var x in new[]{_runtime,_fishHour,_wyrmHour,_goldHour,_totalGold,_targetText}) cards.Children.Add(Card("",x)); panel.Children.Add(cards); panel.Children.Add(Card("Számítási elv",new TextBlock { Text="Az órás értékek a közös session eltelt idejével osztanak – nem adják össze a 3–8 kliens futásidejét. A célhaladás csak az újonnan megjelent, árazott loot értékét írja jóvá és kilépés után is megmarad.",TextWrapping=TextWrapping.Wrap,Foreground=Brush("#CBD5E1"),FontSize=14 })); return new ScrollViewer{Content=panel,VerticalScrollBarVisibility=ScrollBarVisibility.Auto}; }
    TextBlock Metric(string label,string value) { return new TextBlock {Text=label+"\n"+value,Foreground=Brush("#F8FAFC"),FontSize=18,LineHeight=28,Width=205}; }
    UIElement Clients() {
      var grid=new Grid{Margin=new Thickness(10)}; grid.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)}); grid.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(420)});
      var left=new DockPanel(); var controls=new WrapPanel{Margin=new Thickness(0,0,0,8)}; foreach(var def in new[]{new[]{"WoW folyamatok frissítése","REFRESH"},new[]{"START","START"},new[]{"PAUSE","PAUSE"},new[]{"STOP","STOP"},new[]{"F6 küldése","CAST"},new[]{"F7 küldése + loot várakozás","BOBBER"}}) { var b=Button(def[0]); b.Tag=def[1]; b.Click+=ClientAction; controls.Children.Add(b); } DockPanel.SetDock(controls,Dock.Top); left.Children.Add(controls);
      _clientGrid=new DataGrid{ItemsSource=_clients,AutoGenerateColumns=false,IsReadOnly=true,SelectionMode=DataGridSelectionMode.Single,SelectionUnit=DataGridSelectionUnit.FullRow,Background=Brush("#182235"),Foreground=Brush("#E2E8F0"),BorderBrush=Brush("#334155")}; AddCol(_clientGrid,"PID","PidText",85);AddCol(_clientGrid,"Ablak","WindowTitle",240);AddCol(_clientGrid,"Állapot","ControlState",100);AddCol(_clientGrid,"Státusz","Status",220); _clientGrid.SelectionChanged+=delegate { _selectedClient=_clientGrid.SelectedItem as ClientProfile; LoadClientEditor(); }; left.Children.Add(_clientGrid); grid.Children.Add(left);
      var editor=new StackPanel{Margin=new Thickness(14,0,0,0)}; _selectedLabel=new TextBlock{Text="Válassz ki egy klienssort",Foreground=Brush("#F8FAFC"),FontSize=18,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,14)}; editor.Children.Add(_selectedLabel); TextBox cast,bobber,logout,loot,b1k,b1c,b1d,b2k,b2c,b2d; CheckBox b1,b2; editor.Children.Add(Labeled("Dobás",out cast)); editor.Children.Add(Labeled("Kapas",out bobber)); editor.Children.Add(Labeled("Kilépés",out logout)); editor.Children.Add(Labeled("Reconnect jelszó (csak a kijelölt PID)",out _password,true)); editor.Children.Add(Button("Jelszó mentése a kiválasztott PID-hez",delegate { if(_selectedClient!=null&&!string.IsNullOrEmpty(_password.Text)){_selectedClient.PasswordProtected=SecureStore.Protect(_password.Text);_password.Clear();Persist();_selectedClient.Status="Jelszó elmentve";} })); editor.Children.Add(new Separator{Margin=new Thickness(0,12,0,8)}); editor.Children.Add(BuffEditor("Buff 1",out b1,out b1k,out b1c,out b1d)); editor.Children.Add(BuffEditor("Buff 2",out b2,out b2k,out b2c,out b2d)); editor.Children.Add(Labeled("SavedVariables .lua fájl",out loot)); editor.Children.Add(Button("Kijelölt profil mentése",delegate { if(_selectedClient==null)return; _selectedClient.CastKey=cast.Text;_selectedClient.BobberKey=bobber.Text;_selectedClient.LogoutKey=logout.Text; _selectedClient.SavedVariablesPath=loot.Text; SaveBuff(_selectedClient.Buff1,b1,b1k,b1c,b1d);SaveBuff(_selectedClient.Buff2,b2,b2k,b2c,b2d);Persist(); }));
      _clientEditorLoad=delegate { if(_selectedClient==null)return; cast.Text=_selectedClient.CastKey;bobber.Text=_selectedClient.BobberKey;logout.Text=_selectedClient.LogoutKey;loot.Text=_selectedClient.SavedVariablesPath;LoadBuff(_selectedClient.Buff1,b1,b1k,b1c,b1d);LoadBuff(_selectedClient.Buff2,b2,b2k,b2c,b2d);}; Grid.SetColumn(editor,1);grid.Children.Add(editor); return grid;
    }
    UIElement Labeled(string text,out TextBox box,bool password=false){ var p=new StackPanel{Margin=new Thickness(0,0,0,8)};p.Children.Add(new TextBlock{Text=text,Foreground=Brush("#CBD5E1")});box=new TextBox{Height=27,Background=Brush("#0F172A"),Foreground=Brush("#F8FAFC"),BorderBrush=Brush("#475569")};if(password)box.Text="";p.Children.Add(box);return p; }
    UIElement BuffEditor(string label,out CheckBox enabled,out TextBox key,out TextBox cast,out TextBox duration){var p=new WrapPanel{Margin=new Thickness(0,3,0,3)};enabled=new CheckBox{Content=label,Foreground=Brush("#E2E8F0"),Width=85};key=new TextBox{Width=55,Margin=new Thickness(4),Background=Brush("#0F172A"),Foreground=Brush("#FFF")};cast=new TextBox{Width=45,Margin=new Thickness(4),Background=Brush("#0F172A"),Foreground=Brush("#FFF")};duration=new TextBox{Width=45,Margin=new Thickness(4),Background=Brush("#0F172A"),Foreground=Brush("#FFF")};p.Children.Add(enabled);p.Children.Add(key);p.Children.Add(cast);p.Children.Add(duration);return p;}
    void LoadBuff(BuffProfile b,CheckBox e,TextBox k,TextBox c,TextBox d){e.IsChecked=b.Enabled;k.Text=b.Key;c.Text=b.CastSeconds.ToString();d.Text=b.DurationMinutes.ToString();}
    void SaveBuff(BuffProfile b,CheckBox e,TextBox k,TextBox c,TextBox d){b.Enabled=e.IsChecked==true;b.Key=k.Text;int x;if(int.TryParse(c.Text,out x))b.CastSeconds=x;if(int.TryParse(d.Text,out x))b.DurationMinutes=x;}
    void LoadClientEditor(){ if(_selectedClient==null){_selectedLabel.Text="Válassz ki egy klienssort";return;} _selectedLabel.Text="Kijelölt PID: "+_selectedClient.Pid+" · "+_selectedClient.WindowTitle; if(_clientEditorLoad!=null)_clientEditorLoad(); }
    UIElement Items(){var grid=new Grid{Margin=new Thickness(10)};grid.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});grid.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(385)});_itemGrid=new DataGrid{ItemsSource=_items,AutoGenerateColumns=false,IsReadOnly=true,SelectionMode=DataGridSelectionMode.Single,SelectionUnit=DataGridSelectionUnit.FullRow,Background=Brush("#182235"),Foreground=Brush("#E2E8F0")};AddCol(_itemGrid,"Item","Name",190);AddCol(_itemGrid,"Db","Quantity",55);AddCol(_itemGrid,"Ár (g)","UnitGold",85);AddCol(_itemGrid,"Össz. (g)","TotalGold",95);AddCol(_itemGrid,"Jelzés","Signal",85);_itemGrid.SelectionChanged+=delegate{_selectedItem=_itemGrid.SelectedItem as ItemRow;UpdateItemDetail();};grid.Children.Add(_itemGrid);var right=new StackPanel{Margin=new Thickness(14,0,0,0)};_itemDetails=new TextBlock{Text="Válassz ki egy itemet",TextWrapping=TextWrapping.Wrap,Foreground=Brush("#F8FAFC"),FontSize=16};TextBox price;right.Children.Add(Card("Kiválasztott item",_itemDetails));right.Children.Add(Labeled("Kijelölt item kézi egységár (gold)",out price));right.Children.Add(Button("Ár mentése",delegate{if(_selectedItem==null)return;double v;if(double.TryParse(price.Text,NumberStyles.Float,CultureInfo.InvariantCulture,out v)||double.TryParse(price.Text,out v)){_settings.Prices[_selectedItem.Name]=v;RebuildItems();Persist();}}));right.Children.Add(Labeled("Cél összeg (Ft)",out _targetInput));_targetInput.Text=_settings.TargetHuf.ToString("0");right.Children.Add(Button("Cél mentése",delegate{double v;if(double.TryParse(_targetInput.Text,out v)){_settings.TargetHuf=Math.Max(0,v);Persist();RefreshDashboard();}}));right.Children.Add(Button("Célhaladás nullázása",delegate{_settings.TargetEarnedHuf=0;_settings.AccountedLoot.Clear();Persist();RefreshDashboard();}));Grid.SetColumn(right,1);grid.Children.Add(right);return grid;}
    UIElement Advanced(){var p=new DockPanel{Margin=new Thickness(10)};var bar=new WrapPanel{Margin=new Thickness(0,0,0,8)};var save=Button("Minden beállítás mentése",delegate{foreach(var r in _advanced)_settings.Advanced[r.Path]=r.Value ?? "";Persist();});bar.Children.Add(save);var newKey=new TextBox{Width=260,Height=30,Margin=new Thickness(0,0,6,7),ToolTip="Új kulcs, pl. Saját.Valami"};var newValue=new TextBox{Width=160,Height=30,Margin=new Thickness(0,0,6,7),ToolTip="Érték"};bar.Children.Add(newKey);bar.Children.Add(newValue);bar.Children.Add(Button("Egyéni kulcs felvétele",delegate{var key=(newKey.Text??"").Trim();if(string.IsNullOrEmpty(key)){MessageBox.Show("Adj meg egy beállításkulcsot.");return;}if(_advanced.Any(x=>string.Equals(x.Path,key,StringComparison.OrdinalIgnoreCase))){MessageBox.Show("Ez a kulcs már létezik.");return;}_advanced.Add(new AdvancedRow{Category=CategoryOf(key),Path=key,Value=newValue.Text??"",Description="Felhasználó által hozzáadott beállítás"});newKey.Clear();newValue.Clear();}));bar.Children.Add(Button("Kijelölt egyéni kulcs törlése",delegate{var row=_advancedGrid==null?null:_advancedGrid.SelectedItem as AdvancedRow;if(row==null){MessageBox.Show("Válassz ki egy sort.");return;}if(row.Category!="Egyéni"){MessageBox.Show("Az örökölt beállítások nem törölhetők, csak átírhatók.");return;}_advanced.Remove(row);_settings.Advanced.Remove(row.Path);Persist();}));DockPanel.SetDock(bar,Dock.Top);p.Children.Add(bar);_advancedGrid=new DataGrid{ItemsSource=_advanced,AutoGenerateColumns=false,CanUserAddRows=false,Background=Brush("#182235"),Foreground=Brush("#F8FAFC")};AddCol(_advancedGrid,"Csoport","Category",115);AddCol(_advancedGrid,"Kulcs","Path",310);AddCol(_advancedGrid,"Érték","Value",230);AddCol(_advancedGrid,"Leírás","Description",300);p.Children.Add(_advancedGrid);return p;}
    UIElement Api(){var p=new StackPanel{Margin=new Thickness(30),Width=650};p.Children.Add(new TextBlock{Text="Blizzard Auction House API",FontSize=22,FontWeight=FontWeights.SemiBold,Foreground=Brush("#F8FAFC"),Margin=new Thickness(0,0,0,15)});p.Children.Add(Labeled("Client ID",out _clientId));_clientId.Text=_settings.BlizzardClientId;p.Children.Add(Labeled("Client Secret",out _secret,true));p.Children.Add(Button("API hitelesítés mentése és tesztelése",async delegate{var actualSecret=string.IsNullOrEmpty(_secret.Text)?SecureStore.Unprotect(_settings.BlizzardSecretProtected):_secret.Text;_settings.BlizzardClientId=_clientId.Text;if(!string.IsNullOrEmpty(_secret.Text))_settings.BlizzardSecretProtected=SecureStore.Protect(_secret.Text);Persist();_apiState.Text="Hitelesítés folyamatban…";_apiState.Text=await TestApi(_clientId.Text,actualSecret);_secret.Clear();}));_apiState=new TextBlock{Text=string.IsNullOrEmpty(_settings.BlizzardSecretProtected)?"A Client Secret Windows-felhasználóhoz kötött DPAPI titkosítással mentődik.":"Titkosított Client Secret elmentve – üresen hagyhatod, tesztnél a mentett értéket használja.",Foreground=Brush("#CBD5E1"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,10,0,0)};p.Children.Add(_apiState);return p;}
    async Task<string> TestApi(string id,string secret){if(string.IsNullOrWhiteSpace(id)||string.IsNullOrWhiteSpace(secret))return "Add meg a Client ID-t és Secretet.";try{using(var http=new HttpClient()){var auth=Convert.ToBase64String(Encoding.UTF8.GetBytes(id+":"+secret));http.DefaultRequestHeaders.Authorization=new System.Net.Http.Headers.AuthenticationHeaderValue("Basic",auth);var body=new FormUrlEncodedContent(new[]{new KeyValuePair<string,string>("grant_type","client_credentials")});var r=await http.PostAsync("https://oauth.battle.net/token",body);return r.IsSuccessStatusCode?"OAuth rendben: a hitelesítés elfogadva.":"OAuth hiba: "+(int)r.StatusCode+" "+r.ReasonPhrase;}}catch(Exception ex){return "Kapcsolati hiba: "+ex.Message;}}
    Button Button(string text){return Button(text,null);} Button Button(string text,RoutedEventHandler handler){var b=new Button{Content=text,Margin=new Thickness(0,0,7,7),Padding=new Thickness(11,7,11,7),Background=Brush("#2563EB"),Foreground=Brush("#FFF"),BorderThickness=new Thickness(0)};if(handler!=null)b.Click+=handler;return b;}
    void AddCol(DataGrid grid,string header,string binding,double width){grid.Columns.Add(new DataGridTextColumn{Header=header,Binding=new Binding(binding),Width=new DataGridLength(width)});}
    void ClientAction(object sender,RoutedEventArgs e){var op=(string)((Button)sender).Tag;if(op=="REFRESH"){RefreshProcesses();return;}if(_selectedClient==null){MessageBox.Show("Előbb kattints egy kliens sorára.");return;}if(op=="START"||op=="PAUSE"||op=="STOP"){if(op=="START"&&_selectedClient.Pid==0){MessageBox.Show("Ehhez a profilhoz nincs élő WoW PID. Frissítsd a folyamatlistát.");return;}_selectedClient.ControlState=op=="START"?"RUNNING":op=="PAUSE"?"PAUSED":"STOPPED";_selectedClient.Status="Felhasználó: "+_selectedClient.ControlState;Persist();return;}var settle=Int("General.FocusSettleMilliseconds",35);var lootWait=Int("General.LootAfterBobberMilliseconds",350);_input.Send(_selectedClient,op=="CAST"?_selectedClient.CastKey:_selectedClient.BobberKey,settle,lootWait);}
    int Int(string key,int fallback){int x;string s;return _settings.Advanced.TryGetValue(key,out s)&&int.TryParse(s,out x)?x:fallback;}
    void RefreshProcesses(){var found=Process.GetProcesses().Where(p=>{try{return p.ProcessName.IndexOf("wow",StringComparison.OrdinalIgnoreCase)>=0&&!p.HasExited;}catch{return false;}}).ToList();foreach(var p in found){var existing=_clients.FirstOrDefault(x=>x.Pid==p.Id);if(existing==null){existing=_clients.FirstOrDefault(x=>x.Pid==0&&string.Equals(x.WindowTitle,p.MainWindowTitle,StringComparison.OrdinalIgnoreCase));if(existing==null){existing=new ClientProfile();_clients.Add(existing);}existing.Pid=p.Id;existing.WindowTitle=string.IsNullOrWhiteSpace(p.MainWindowTitle)?p.ProcessName:p.MainWindowTitle;existing.Status="Folyamat megtalálva";}}foreach(var c in _clients.Where(c=>c.Pid!=0&&!found.Any(p=>p.Id==c.Pid))){c.Status="Folyamat nem fut";c.ControlState="STOPPED";} }
    void Tick(){ReadLoot();RebuildItems();RefreshDashboard();}
    void ReadLoot(){foreach(var c in _clients){if(string.IsNullOrWhiteSpace(c.SavedVariablesPath)||!File.Exists(c.SavedVariablesPath))continue;try{var mod=File.GetLastWriteTimeUtc(c.SavedVariablesPath);if(mod<=c.LastLootReadUtc)continue;var t=File.ReadAllText(c.SavedVariablesPath);var section=Regex.Match(t,@"AIFishLootCounts\s*=\s*\{(?<x>.*?)\}",RegexOptions.Singleline);if(!section.Success)continue;var d=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);foreach(Match m in Regex.Matches(section.Groups["x"].Value,@"\[""(?<n>[^""]+)""\]\s*=\s*(?<q>\d+)")){int q;if(int.TryParse(m.Groups["q"].Value,out q))d[m.Groups["n"].Value]=q;}c.Loot=d;c.LastLootReadUtc=mod;c.Status="Loot frissítve";}catch(Exception ex){c.Status="Loot hiba: "+ex.Message;}}}
    void RebuildItems(){var total=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);foreach(var c in _clients)foreach(var pair in c.Loot)total[pair.Key]=(total.ContainsKey(pair.Key)?total[pair.Key]:0)+pair.Value;var selected=_selectedItem==null?null:_selectedItem.Name;_items.Clear();foreach(var pair in total.OrderBy(x=>x.Key)){double p=0;_settings.Prices.TryGetValue(pair.Key,out p);int id=0;_settings.ItemIds.TryGetValue(pair.Key,out id);_items.Add(new ItemRow{Name=pair.Key,Quantity=pair.Value,UnitGold=p,ItemId=id,MinGold=p,MaxGold=p,AverageGold=p});}if(selected!=null&&_itemGrid!=null)_itemGrid.SelectedItem=_items.FirstOrDefault(x=>x.Name==selected);if(_itemGrid!=null&&_itemGrid.SelectedItem==null&&_items.Count>0)_itemGrid.SelectedItem=_items[0];UpdateItemDetail();AccountTarget(total);}
    void UpdateItemDetail(){if(_selectedItem==null){if(_itemGrid!=null)_selectedItem=_itemGrid.SelectedItem as ItemRow;if(_selectedItem==null){_itemDetails.Text="Válassz ki egy itemet";return;}}var x=_selectedItem;_itemDetails.Text=string.Format("{0}\nMennyiség: {1} db\nAktuális ár: {2:N2} g/db\nÖsszérték: {3:N2} g\nHistorikus min / átlag / max: {4:N2} / {5:N2} / {6:N2} g\nJelzés: {7}",x.Name,x.Quantity,x.UnitGold,x.TotalGold,x.MinGold,x.AverageGold,x.MaxGold,x.Signal);}
    void AccountTarget(Dictionary<string,int> total){foreach(var pair in total){var key=pair.Key;var previous=_settings.AccountedLoot.ContainsKey(key)?_settings.AccountedLoot[key]:0;if(pair.Value>previous){double price=0;_settings.Prices.TryGetValue(key,out price);_settings.TargetEarnedHuf+=(pair.Value-previous)*price*HufPerGold();}_settings.AccountedLoot[key]=Math.Max(previous,pair.Value);} }
    double HufPerGold(){return (1d/Math.Max(0.0001,Double("Revenue.GoldPerEuro",25000)))*Double("Revenue.EurToHuf",400);} double Double(string key,double f){double x;string s;return _settings.Advanced.TryGetValue(key,out s)&&double.TryParse(s,NumberStyles.Float,CultureInfo.InvariantCulture,out x)?x:f;}
    void RefreshDashboard(){var elapsed=Math.Max(0,(DateTime.UtcNow-_sessionStartedUtc).TotalSeconds);var hours=Math.Max(elapsed/3600d,1d/3600d);var total=_items.Sum(x=>x.TotalGold);var fish=_items.Sum(x=>x.Quantity);var wyrm=_items.Where(x=>string.Equals(x.Name,Highlight(),StringComparison.OrdinalIgnoreCase)).Sum(x=>x.Quantity);_runtime.Text="KÖZÖS FUTÁSIDŐ\n"+TimeSpan.FromSeconds(elapsed).ToString(@"hh\:mm\:ss");_fishHour.Text="FISH / ÓRA\n"+(fish/hours).ToString("N1");_wyrmHour.Text="WYRMFISH / ÓRA\n"+(wyrm/hours).ToString("N1");_goldHour.Text="GOLD / ÓRA\n"+(total/hours).ToString("N1");_totalGold.Text="ÖSSZÉRTÉK\n"+total.ToString("N1")+" g";_targetText.Text="CÉL\n"+_settings.TargetEarnedHuf.ToString("N0")+" / "+_settings.TargetHuf.ToString("N0")+" Ft";}
    string Highlight(){string s;return _settings.Advanced.TryGetValue("Loot.HighlightFishName",out s)?s:"Wyrmfish";}
    void Persist(){foreach(var r in _advanced)_settings.Advanced[r.Path]=r.Value??"";_settings.Clients=_clients.ToList();_settings.TotalSessionSeconds+=Math.Max(0,(DateTime.UtcNow-_sessionStartedUtc).TotalSeconds);_sessionStartedUtc=DateTime.UtcNow;try{_store.Save(_settings);}catch(Exception ex){MessageBox.Show("Mentési hiba: "+ex.Message);}}
  }
  public static class Program { [STAThread] public static void Main(){var app=new Application();app.Run(new MainWindow());} }
}
