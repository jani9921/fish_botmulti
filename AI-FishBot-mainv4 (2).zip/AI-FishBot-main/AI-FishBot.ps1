### =========================================================
### AI-Fishbot - General Settings
### =========================================================
$retail           = $True   # $True for Retail, $False for Classic. Fishing cast times differ.
$autoStop         = $False  # $False to disable. Will autostop the bot after the time set below.
$autoStopTime     = 3000    # Minutes until autostop. Used when $autoStop = $True.
$autoLogout       = $False  # If $True, logs out each client when $autoStopTime is reached.
$audioSensitivity = 1       # 1-9. Lower = more sensitive (detects quieter bites).
$UseWindowFocus   = $True   # $True = bot focuses the correct WoW window before every keypress.
$enableBuffs      = (0)     # e.g. (1..3) for 3 buffs, or (0) for none.
$fishingRetries   = 15      # WeakAura mode: how many recast attempts before giving up on a client.
$usePi            = $False  # $True if using a Raspberry Pi Pico for hardware input.
$picoComPort      = "COM6"
$useWeakAura      = $False  # $True on Classic (needed), optional on Retail.

### Main Keybinds (F5-F12) ###
$cast   = "F6"
$bobber = "F7"
$logout = "F8"

### Notification Settings (Discord only) ###
$enableNotifications = $False
$discordWebhook = "https://discord.com/api/webhooks/your webhook here"
$onStart = $True
$onStop  = $True

### Buff Settings ###
$buffKeybind1  = "F9"
$buffCastTime1 = 1
$buffDuration1 = 5
$buffKeybind2  = "F10"
$buffCastTime2 = 5
$buffDuration2 = 30
# buff3
# ...

###################################
### DON'T EDIT BELOW THIS LINE ####
###################################

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

if (-not $psISE) {
    $buffer = $host.ui.RawUI.BufferSize
    $buffer.width  = "90"
    $buffer.height = "30"
    $host.UI.RawUI.Set_WindowSize($buffer)
    $host.UI.RawUI.Set_BufferSize($buffer)
}

# ============================================================
# 1) WOW PID VALASZTO - GUI
# ============================================================

$wowProcesses = @(
    Get-Process -ErrorAction SilentlyContinue |
    Where-Object { $_.ProcessName -eq "Wow" } |
    Sort-Object Id
)

if ($wowProcesses.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show(
        "Nem talalhato futo Wow process.", "AI-FishBot",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
    exit
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "AI-FishBot - WoW PID valasztas"
$form.Size = New-Object System.Drawing.Size(560, 500)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "Valaszd ki a figyelni kivant WoW klienseket:"
$titleLabel.Location = New-Object System.Drawing.Point(20, 20)
$titleLabel.Size = New-Object System.Drawing.Size(500, 30)
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($titleLabel)

$infoLabel = New-Object System.Windows.Forms.Label
$infoLabel.Text = "Egyszerre tobb kliens is kijelolheto - a bot korbe fogja jaratni oket."
$infoLabel.Location = New-Object System.Drawing.Point(20, 50)
$infoLabel.Size = New-Object System.Drawing.Size(500, 25)
$infoLabel.ForeColor = [System.Drawing.Color]::DarkSlateGray
$form.Controls.Add($infoLabel)

$list = New-Object System.Windows.Forms.CheckedListBox
$list.Location = New-Object System.Drawing.Point(20, 85)
$list.Size = New-Object System.Drawing.Size(500, 300)
$list.CheckOnClick = $true
$list.Font = New-Object System.Drawing.Font("Segoe UI", 10)

for ($i = 0; $i -lt $wowProcesses.Count; $i++) {
    $process = $wowProcesses[$i]
    $windowTitle = ""
    try { $windowTitle = $process.MainWindowTitle } catch { $windowTitle = "" }
    if ([string]::IsNullOrWhiteSpace($windowTitle)) { $windowTitle = "World of Warcraft" }
    $display = "PID {0} | {1}" -f $process.Id, $windowTitle
    [void]$list.Items.Add($display)
}
$form.Controls.Add($list)

$okButton = New-Object System.Windows.Forms.Button
$okButton.Text = "OK"
$okButton.Location = New-Object System.Drawing.Point(330, 405)
$okButton.Size = New-Object System.Drawing.Size(90, 35)
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Text = "Megse"
$cancelButton.Location = New-Object System.Drawing.Point(430, 405)
$cancelButton.Size = New-Object System.Drawing.Size(90, 35)
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancelButton)

$form.AcceptButton = $okButton
$form.CancelButton = $cancelButton

$result = $form.ShowDialog()
if ($result -ne [System.Windows.Forms.DialogResult]::OK) { exit }

$selectedPids = @()
foreach ($checkedIndex in $list.CheckedIndices) {
    $selectedPids += [uint32]$wowProcesses[$checkedIndex].Id
}
$selectedPids = @($selectedPids | Select-Object -Unique)

if ($selectedPids.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show(
        "Legalabb egy WoW klienst valassz ki.", "AI-FishBot",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
    exit
}

Clear-Host
Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "        KIVALASZTOTT WOW PID-EK" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
foreach ($wowPid in $selectedPids) {
    $process = Get-Process -Id $wowPid -ErrorAction SilentlyContinue
    if ($null -ne $process) {
        Write-Host ("PID {0,-8} | {1}" -f $wowPid, $process.ProcessName) -ForegroundColor Green
    }
}
Write-Host ""

# ============================================================
# 2) NAUDIO BETOLTESE - valodi, per-process (per PID) hangero
#    meres. Ez valtja ki a nem letezo [WowAudioApi] osztalyt
#    es a global Write-AudioDevice -PlaybackStream job-ot.
# ============================================================

function Ensure-NAudio {
    $scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

    # NAudio 2.x-ben a "NAudio" csomag csak egy ures facade - a tenyleges
    # kod ket kulon csomagban van: NAudio.Core es NAudio.Wasapi (ez utobbi
    # tartalmazza a NAudio.CoreAudioApi namespace-t, amit hasznalunk).
    $packages = @("NAudio.Core", "NAudio.Wasapi")
    $missing = $packages | Where-Object { -not (Test-Path (Join-Path $scriptDir "$_.dll")) }

    if ($missing.Count -gt 0) {
        Write-Host "NAudio komponensek hianyoznak - automatikus letoltes..." -ForegroundColor Yellow
        foreach ($pkg in $packages) {
            if (Test-Path (Join-Path $scriptDir "$pkg.dll")) { continue }
            try {
                $tmpZip = Join-Path $env:TEMP "$pkg.zip"
                $tmpDir = Join-Path $env:TEMP "$($pkg)_extract"
                if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }
                Invoke-WebRequest -Uri "https://www.nuget.org/api/v2/package/$pkg/2.2.1" -OutFile $tmpZip -UseBasicParsing
                Expand-Archive -Path $tmpZip -DestinationPath $tmpDir -Force

                $dll = Get-ChildItem -Path $tmpDir -Recurse -Filter "$pkg.dll" |
                    Where-Object { $_.FullName -match "net472" } | Select-Object -First 1
                if (-not $dll) {
                    $dll = Get-ChildItem -Path $tmpDir -Recurse -Filter "$pkg.dll" |
                        Where-Object { $_.FullName -match "netstandard2\.0" } | Select-Object -First 1
                }
                if (-not $dll) {
                    $dll = Get-ChildItem -Path $tmpDir -Recurse -Filter "$pkg.dll" | Select-Object -First 1
                }
                if (-not $dll) { throw "Nem talalhato $pkg.dll a letoltott csomagban." }
                Copy-Item $dll.FullName -Destination (Join-Path $scriptDir "$pkg.dll") -Force
            } catch {
                Write-Host "Automatikus NAudio letoltes sikertelen ($pkg): $_" -ForegroundColor Red
                Write-Host "Toltsd le kezzel: https://www.nuget.org/packages/$pkg" -ForegroundColor Yellow
                Write-Host "Csomagold ki (Rename .nupkg -> .zip, kicsomagolas), es masold a lib\net472\$pkg.dll fajlt a script melle." -ForegroundColor Yellow
                Exit
            }
        }
    }

    # AssemblyResolve kezelo, hogy a NAudio.Wasapi.dll mindig megtalalja a
    # tole fuggo NAudio.Core.dll-t, betoltesi sorrendtol fuggetlenul.
    $resolveHandler = [ResolveEventHandler]{
        param($senderObj, $resolveArgs)
        $asmName = ($resolveArgs.Name -split ',')[0]
        $candidate = Join-Path $scriptDir "$asmName.dll"
        if (Test-Path $candidate) {
            return [System.Reflection.Assembly]::LoadFrom($candidate)
        }
        return $null
    }
    [System.AppDomain]::CurrentDomain.add_AssemblyResolve($resolveHandler)

    Add-Type -Path (Join-Path $scriptDir "NAudio.Core.dll")
    Add-Type -Path (Join-Path $scriptDir "NAudio.Wasapi.dll")
}

Ensure-NAudio

# Ujrahasznalt NAudio objektumok - minden pollnal ujra letrehozni felesleges
# COM-overhead-et okozott, ami rontotta az egyideju harapasok erzekeleset.
$script:AudioDevice = $null

function Get-AudioDeviceCached {
    if (-not $script:AudioDevice) {
        $enumerator = New-Object NAudio.CoreAudioApi.MMDeviceEnumerator
        $script:AudioDevice = $enumerator.GetDefaultAudioEndpoint(
            [NAudio.CoreAudioApi.DataFlow]::Render,
            [NAudio.CoreAudioApi.Role]::Multimedia
        )
    }
    return $script:AudioDevice
}

# Visszaadja: hashtable @{ [uint32]pid = peak% }  a kivalasztott PID-ekre
function Get-WowAudioPeaks {
    param([uint32[]]$Pids)

    $peakResult = @{}
    try {
        $device = Get-AudioDeviceCached
        $sessions = $device.AudioSessionManager.Sessions
        for ($i = 0; $i -lt $sessions.Count; $i++) {
            $session = $sessions[$i]
            $sessionPid = [uint32]$session.GetProcessID
            if ($Pids -contains $sessionPid) {
                $peakPct = [Math]::Round($session.AudioMeterInformation.MasterPeakValue * 100, 2)
                if (-not $peakResult.ContainsKey($sessionPid) -or $peakResult[$sessionPid] -lt $peakPct) {
                    $peakResult[$sessionPid] = $peakPct
                }
            }
        }
    } catch {
        # az alapertelmezett lejatszo eszkoz valtozhatott (pl. headset kihuzva) -
        # dobjuk el a cache-t, legkozelebb ujra letrehozzuk
        $script:AudioDevice = $null
    }
    return $peakResult
}

# ============================================================
# 3) BEMENET-KULDES SEGEDFUGGVENYEK (per kliens fokusszal)
# ============================================================

if ($UseWindowFocus) { $wshell = New-Object -ComObject wscript.shell }

function Focus-Client {
    param([uint32]$WowPid)
    if ($UseWindowFocus) {
        $wshell.AppActivate([int]$WowPid) | Out-Null
        Start-Sleep -Milliseconds 100
    }
}

function Send-Key {
    param([uint32]$WowPid, [string]$Key)
    Focus-Client -WowPid $WowPid
    if ($usePi) {
        $port.WriteLine($Key)
    } else {
        [System.Windows.Forms.SendKeys]::SendWait("{$Key}")
    }
}

function Start-Cast {
    param([uint32]$WowPid)
    Send-Key -WowPid $WowPid -Key $cast
}

function Start-Bobber {
    param([uint32]$WowPid)
    Write-Host "[$WowPid] Bite Detected" -ForegroundColor Green
    Send-Key -WowPid $WowPid -Key $bobber
}

function Apply-Buff {
    param([uint32]$WowPid, [string]$buffKeybind, [int]$buffCastTime)
    for ($i = 1; $i -le 10; $i++) {
        Send-Key -WowPid $WowPid -Key $buffKeybind
        if ($i -lt 10) { Start-Sleep -Seconds 1 }
    }
    Start-Sleep -Seconds ($buffCastTime + 2)
}

function Send-Notification {
    param([string]$msg)
    $discordHeaders = @{ "Content-Type" = "application/json" }
    $discordBody = @{ content = $msg } | ConvertTo-Json
    Invoke-RestMethod -Uri $discordWebHook -Method POST -Headers $discordHeaders -Body $discordBody
}

# ============================================================
# 4) INDITAS
# ============================================================

Write-Host "##########################" -ForegroundColor Magenta
Write-Host "  Audio Interact Fishbot "  -ForegroundColor Magenta
Write-Host "##########################" -ForegroundColor Magenta

if ($usePi) {
    Write-Host "Using Pi for hardware input" -ForegroundColor Yellow
    if ($port -and $port.IsOpen) { $port.Close() }
    $port = New-Object System.IO.Ports.SerialPort $picoComPort, 115200, None, 8, one
    try {
        $port.Open()
        Write-Host "Pi Connection Established" -ForegroundColor Green
    } catch {
        Write-Host "Pi Connection Failed! Check COM port or set `$usePi = `$false" -ForegroundColor Red
        Exit
    }
} else {
    Write-Host "NOT using Pi - input will be software based" -ForegroundColor Yellow
}

if (-not $UseWindowFocus) {
    Write-Host "Not Auto-Focusing WoW. With more than one selected client this WILL misfire." -ForegroundColor Yellow
}
if (-not $useWeakAura) {
    Write-Host "Not Using Weakaura companion. Casting is 'fire and forget'" -ForegroundColor Yellow
}
Write-Host $(if ($retail) { "Retail Mode: Fishing starts in 5 seconds.." } else { "Classic Mode: Fishing starts in 5 seconds.." })

if ($autoStop) { $autoEndTime = (Get-Date).AddMinutes($autoStopTime) }
Start-Sleep -Seconds 5

if ($enableNotifications -and $onStart) {
    Send-Notification -msg "**AI-Fishbot started fishing** ($($selectedPids.Count) client(s))"
}

# per-client allapot
# Phase: "NeedCast" -> "AwaitingBite" -> "ClickBobber" -> "PostCatch" -> "NeedCast"
$clientState = @{}
foreach ($wowPid in $selectedPids) {
    $clientState[$wowPid] = @{
        Phase          = "NeedCast"
        NextActionTime = Get-Date
        RangeCount     = 0
        RestartTotal   = 0
        HookCount      = 0
        BuffTimeLeft   = @{}
    }
}

if ($enableBuffs) {
    Write-Host "Buffs Enabled.." -ForegroundColor Green
    foreach ($wowPid in $selectedPids) {
        foreach ($buff in $enableBuffs) {
            $buffKey  = Get-Variable -Name "buffKeybind$buff" -ValueOnly
            $buffCast = Get-Variable -Name "buffCastTime$buff" -ValueOnly
            $buffTime = Get-Variable -Name "buffDuration$buff" -ValueOnly
            Write-Host "[$wowPid] Applying Buff #$buff" -ForegroundColor Green
            Apply-Buff -WowPid $wowPid -buffKeybind $buffKey -buffCastTime $buffCast
            $clientState[$wowPid].BuffTimeLeft[$buff] = (Get-Date).AddMinutes($buffTime)
        }
    }
    Start-Sleep -Seconds 2
}

$waitAfterCast = 4
if ($retail) { $castingTime = 22 - $waitAfterCast } else { $castingTime = 30 - $waitAfterCast }
$audioThreshold = $audioSensitivity * 10

# ============================================================
# 5) FO CIKLUS - NEM BLOKKOLO allapotgep.
#    Minden kliens fuggetlen idozitessel halad a sajat fazisain
#    at (NeedCast -> AwaitingBite -> ClickBobber -> PostCatch),
#    a hangcsucs-lekerdezes pedig MINDEN AwaitingBite fazisban
#    levo kliensre EGYSZERRE, 50ms-es ciklusidovel fut - igy ha
#    ket kliens kozel egy idoben kap be, mindketto szinte azonnal
#    (nem egymas utan, tobb masodperces csuszassal) kap kattintast.
# ============================================================

while ($true) {

    $now = Get-Date

    foreach ($wowPid in @($selectedPids)) {
        $cs = $clientState[$wowPid]
        if ($now -lt $cs.NextActionTime) { continue }

        switch ($cs.Phase) {

            "NeedCast" {
                if ($useWeakAura) {
                    # Classic-ban a weakaura-s "eltalalta-e a soft targetet" retry
                    # logika jellegenel fogva soros marad az adott kliensen belul,
                    # de a tobbi klienst nem blokkolja (azok tovabb varnak sajat
                    # AwaitingBite/PostCatch fazisukban a kovetkezo tick-ekben).
                    $cs.RangeCount = 0
                    $landed = $false
                    while (-not $landed -and $cs.RangeCount -lt $fishingRetries) {
                        $cs.RangeCount++
                        $cs.RestartTotal++
                        Start-Cast -WowPid $wowPid
                        $recast = Get-Random -Minimum 1000 -Maximum 1500
                        Start-Sleep -Milliseconds $recast
                        $peaks = Get-WowAudioPeaks -Pids @($wowPid)
                        if ($peaks.ContainsKey($wowPid) -and $peaks[$wowPid] -ge $audioThreshold) { $landed = $true }
                    }
                    if (-not $landed) {
                        Write-Host "[$wowPid] $fishingRetries sikertelen dobas egymas utan - kliens leallitva" -ForegroundColor Yellow
                        if ($enableNotifications -and $onStop) {
                            Send-Notification -msg "**AI-Fishbot Stopped ($wowPid)**`nHooked: $($cs.HookCount)`nCasting Retries: $($cs.RestartTotal)`nReason: $fishingRetries unsuccessful casts in a row"
                        }
                        $selectedPids = @($selectedPids | Where-Object { $_ -ne $wowPid })
                        continue
                    }
                    Write-Host "[$wowPid] Casting Succeeded: $($cs.RangeCount) tries" -ForegroundColor Green
                } else {
                    Write-Host "[$wowPid] Fishing.." -ForegroundColor Yellow
                    Start-Cast -WowPid $wowPid
                }

                $cs.Phase = "AwaitingBite"
                # rovid "beallasi ido", hogy ne a dobas sajat hangjat erzekelje harapasnak
                $cs.NextActionTime = $now.AddSeconds($waitAfterCast)
                $cs.CastDeadline   = $now.AddSeconds($waitAfterCast + $castingTime)
            }

            "AwaitingBite" {
                if ($now -gt $cs.CastDeadline) {
                    Write-Host "[$wowPid] Casting finished with no bite" -ForegroundColor Yellow
                    $cs.Phase = "NeedCast"
                    $cs.NextActionTime = $now
                }
                # amíg a hatarido nincs meg elerve, a tenyleges harapasfigyeles
                # a ciklus vegen, egy kozos Get-WowAudioPeaks hivassal tortenik
            }

            "ClickBobber" {
                $cs.HookCount++
                Start-Bobber -WowPid $wowPid
                Write-Host ("[{0}] Hooked total: {1}" -f $wowPid, $cs.HookCount) -ForegroundColor Cyan
                $cs.Phase = "PostCatch"
                $cs.NextActionTime = $now.AddMilliseconds((Get-Random -Minimum 800 -Maximum 1200))
            }

            "PostCatch" {
                $cs.Phase = "NeedCast"
                $cs.NextActionTime = $now
            }
        }
    }

    if ($selectedPids.Count -eq 0) {
        Write-Host "Nincs tobb aktiv kliens - kilepes." -ForegroundColor Red
        break
    }

    # ---- Kozos, egyideju harapas-ellenorzes minden varakozo kliensre ----
    $awaitingPids = @($selectedPids | Where-Object { $clientState[$_].Phase -eq "AwaitingBite" -and $now -ge $clientState[$_].NextActionTime })
    if ($awaitingPids.Count -gt 0) {
        $peaks = Get-WowAudioPeaks -Pids $awaitingPids
        foreach ($wowPid in $awaitingPids) {
            if ($peaks.ContainsKey($wowPid) -and $peaks[$wowPid] -ge $audioThreshold) {
                $cs = $clientState[$wowPid]
                $cs.Phase = "ClickBobber"
                # kis, nem blokkolo, emberszeru varakozas kattintas elott
                $cs.NextActionTime = $now.AddMilliseconds((Get-Random -Minimum 800 -Maximum 1200))
            }
        }
    }

    if ($enableBuffs) {
        foreach ($wowPid in $selectedPids) {
            foreach ($buff in $enableBuffs) {
                $expire = $clientState[$wowPid].BuffTimeLeft[$buff]
                if ((Get-Date).AddSeconds(-10) -gt $expire) {
                    $buffKey  = Get-Variable -Name "buffKeybind$buff" -ValueOnly
                    $buffCast = Get-Variable -Name "buffCastTime$buff" -ValueOnly
                    $buffTime = Get-Variable -Name "buffDuration$buff" -ValueOnly
                    Write-Host "[$wowPid] Re-applying Buff #$buff" -ForegroundColor Green
                    Apply-Buff -WowPid $wowPid -buffKeybind $buffKey -buffCastTime $buffCast
                    $clientState[$wowPid].BuffTimeLeft[$buff] = (Get-Date).AddMinutes($buffTime)
                }
            }
        }
    }

    if ($autoStop -and (Get-Date) -gt $autoEndTime) {
        Write-Host "Time Limit Reached - Fishing Stopped" -ForegroundColor Yellow
        foreach ($wowPid in $selectedPids) {
            if ($autoLogout) {
                Write-Host "[$wowPid] Logging Out.." -ForegroundColor Yellow
                Send-Key -WowPid $wowPid -Key $logout
            }
        }
        if ($usePi -and $port.IsOpen) { $port.Close() }
        if ($enableNotifications -and $onStop) {
            $totalHooked = ($clientState.Values | ForEach-Object { $_.HookCount } | Measure-Object -Sum).Sum
            Send-Notification -msg "**AI-Fishbot Stopped**`nTotal Hooked: $totalHooked`nReason: AutoStop time reached after $($autoStopTime)m"
        }
        Write-Host -NoNewline 'You may close this window'
        Exit
    }

    Start-Sleep -Milliseconds 50
}