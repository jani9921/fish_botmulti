<#
================================================================================
 AI-FishBot Monitor v2.1
================================================================================
 A v2 stabilizalt, hibajavitott valtozata. Ugyanaz a 17 reteg, valtozatlan
 architekturaval:

   1  Configuration        7  Loot            13 Notification
   2  Logging              8  Price           14 Session/Report
   3  Audio                9  Revenue         15 Monitor
   4  PID selector        10  Target          16 GUI
   5  Client State        11  Metrics         17 Entry Point
   6  Input (Queue!)      12  Anomaly

 A legfontosabb valtozas a 6. retegben van: a korabbi szetszort
 Focus-Client+SendKeys hivasok helyett MINDEN billentyu-kuldes egy kozponti
 Input Queue-n megy at (Queue-Input -> Process-InputQueue -> Invoke-InputAction
 -> Complete-Input). A reszleteket lasd a fajl vegen levo CHANGELOG-ban.

 SZALKEZELES: tovabbra is EGY szalon fut minden (ket Timer, kulon
 intervallummal) - ez maradt a v2-bol, szandekosan nem lett hattterszalas.
================================================================================
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

# ==============================================================================
# 1) CONFIGURATION
# ==============================================================================

$Config = @{

    General = @{
        Retail                            = $true
        AutoStop                          = $false
        AutoStopMinutes                   = 3000
        AutoLogout                        = $false
        UseWindowFocus                    = $true
        FishingRetries                    = 15
        UseWeakAura                       = $false
        CastKey                           = "F6"
        BobberKey                         = "F7"
        LogoutKey                         = "F8"
        LootWaitSeconds                   = 2.0
        NoBiteStreakLimit                 = 10
        ReconnectSecondEnterDelaySeconds  = 30
        MaxReconnectAttempts              = 3
        NoCatchWarningMinutes             = 15
        FishRateDropThresholdPct          = 50
    }

    Client = @{
        BuffsEnabled = @(1)
        Buffs = @{
            1 = @{ Keybind = "F9";  CastTimeSeconds = 1; DurationMinutes = 5 }
            2 = @{ Keybind = "F10"; CastTimeSeconds = 5; DurationMinutes = 30 }
        }
        UsePi       = $false
        PicoComPort = "COM6"
    }

    Audio = @{
        Sensitivity = 1
    }

    Loot = @{
        Enabled            = $false
        ReloadEveryCatches = 100
        HighlightFishName  = "Wyrmfish"
        ReloadSettleSeconds = 3   # /reload utan ennyit var, mielott a SavedVariables fajlt olvasna
    }

    Price = @{
        Region                 = "EU"
        Realm                  = "Ragnaros"
        Item                   = "Wyrmfish"
        RefreshIntervalMinutes = 30
        FallbackPrice          = 62
        # Nincs ismert, megbizhato API - szandekosan nincs kitalalt endpoint.
        # Ide tehetsz egy scriptblockot: param($Region,$Realm,$Item) -> [double] ar vagy $null.
        ProviderScriptBlock    = $null
        ProviderTimeoutSeconds = 8
    }

    Revenue = @{
        GoldPerEuro = 1000000 / 40
        EurToHuf    = 400
    }

    Target = @{
        TargetHuf = 100000
    }

    Gui = @{
        MonitorIntervalMs     = 75
        RefreshIntervalMs     = 750
        ReportIntervalSeconds = 60
        AlertHistoryLimit     = 200
        AlertDisplayCount     = 20
    }

    Notification = @{
        Enabled         = $false
        DiscordWebhook  = $env:AIFISHBOT_DISCORD_WEBHOOK
        OnStart         = $true
        OnStop          = $true
        ThrottleMinutes = 10
        TimeoutSeconds  = 5
    }

    Logging = @{
        Directory = Join-Path $script:scriptDir "logs"
        Debug     = $false
    }
}

$wowPassword = $env:AIFISHBOT_WOW_PASSWORD
if (-not $wowPassword) { $wowPassword = "" }

# ==============================================================================
# 2) LOGGING ENGINE
# ==============================================================================

try {
    if (-not (Test-Path $Config.Logging.Directory)) {
        New-Item -ItemType Directory -Path $Config.Logging.Directory -Force | Out-Null
    }
} catch {
    $Config.Logging.Directory = $script:scriptDir
}
$script:LogFilePath = Join-Path $Config.Logging.Directory ("session_{0}.log" -f (Get-Date -Format "yyyy-MM-dd"))
$script:SessionId = Get-Date -Format "yyyy-MM-dd_HHmm"

function Write-Log {
    param(
        [ValidateSet("INFO", "WARNING", "ERROR", "DEBUG")]
        [string]$Level,
        [string]$Message
    )
    if ($Level -eq "DEBUG" -and -not $Config.Logging.Debug) { return }
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $script:SessionId, $Level, $Message
    try { Add-Content -Path $script:LogFilePath -Value $line -ErrorAction SilentlyContinue } catch { }
}

function Write-LogException {
    param([string]$Context, $ErrorRecord)
    Write-Log -Level ERROR -Message ("{0} | {1}: {2}" -f $Context, $ErrorRecord.Exception.GetType().Name, $ErrorRecord.Exception.Message)
}

# ==============================================================================
# 3) AUDIO ENGINE (NAudio / WASAPI)
# ==============================================================================

function Ensure-NAudio {
    $scriptDir = $script:scriptDir
    $packages = @("NAudio.Core", "NAudio.Wasapi")

    foreach ($pkg in $packages) {
        $dllPath = Join-Path $scriptDir "$pkg.dll"
        if (Test-Path $dllPath) { continue }

        Write-Log -Level INFO -Message "NAudio komponens letoltese: $pkg"
        try {
            $tmpZip = Join-Path $env:TEMP "$pkg.zip"
            $tmpDir = Join-Path $env:TEMP "$($pkg)_extract"
            if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue }
            Invoke-WebRequest -Uri "https://www.nuget.org/api/v2/package/$pkg/2.2.1" -OutFile $tmpZip -UseBasicParsing -TimeoutSec 30
            Expand-Archive -Path $tmpZip -DestinationPath $tmpDir -Force

            $dll = Get-ChildItem -Path $tmpDir -Recurse -Filter "$pkg.dll" -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -match "net472" } | Select-Object -First 1
            if (-not $dll) {
                $dll = Get-ChildItem -Path $tmpDir -Recurse -Filter "$pkg.dll" -ErrorAction SilentlyContinue |
                    Where-Object { $_.FullName -match "netstandard2\.0" } | Select-Object -First 1
            }
            if (-not $dll) {
                $dll = Get-ChildItem -Path $tmpDir -Recurse -Filter "$pkg.dll" -ErrorAction SilentlyContinue | Select-Object -First 1
            }
            if (-not $dll) { throw "Nem talalhato $pkg.dll a letoltott csomagban." }
            Copy-Item $dll.FullName -Destination $dllPath -Force
        } catch {
            Write-LogException -Context "NAudio letoltes ($pkg)" -ErrorRecord $_
            [System.Windows.Forms.MessageBox]::Show(
                "NAudio letoltese sikertelen ($pkg): $($_.Exception.Message)`n`nToltsd le kezzel: https://www.nuget.org/packages/$pkg",
                "AI-FishBot Monitor v2.1", "OK", "Error") | Out-Null
            Exit 1
        }
    }

    try {
        Add-Type -Path (Join-Path $scriptDir "NAudio.Core.dll")
        Add-Type -Path (Join-Path $scriptDir "NAudio.Wasapi.dll")
    } catch {
        Write-LogException -Context "NAudio betoltes (Add-Type)" -ErrorRecord $_
        [System.Windows.Forms.MessageBox]::Show(
            "NAudio betoltese sikertelen: $($_.Exception.Message)`n`nToroljd a script melletti NAudio.Core.dll / NAudio.Wasapi.dll fajlokat es probald ujra.",
            "AI-FishBot Monitor v2.1", "OK", "Error") | Out-Null
        Exit 1
    }

    # Fust-teszt: probaljuk tenylegesen hasznalni, hogy korai, ertheto hibat kapjunk
    # ahelyett hogy csak az elso valodi poll-nal derulne ki.
    try {
        $testEnum = New-Object NAudio.CoreAudioApi.MMDeviceEnumerator
        $null = $testEnum.GetDefaultAudioEndpoint([NAudio.CoreAudioApi.DataFlow]::Render, [NAudio.CoreAudioApi.Role]::Multimedia)
    } catch {
        Write-LogException -Context "NAudio fust-teszt" -ErrorRecord $_
        [System.Windows.Forms.MessageBox]::Show(
            "NAudio betoltodott, de nem hasznalhato: $($_.Exception.Message)`n`nLehet, hogy nincs aktiv lejatszo audio eszkoz.",
            "AI-FishBot Monitor v2.1", "OK", "Warning") | Out-Null
    }
}

$script:AudioDevice = $null

function Get-AudioDeviceCached {
    if (-not $script:AudioDevice) {
        $enumerator = New-Object NAudio.CoreAudioApi.MMDeviceEnumerator
        $script:AudioDevice = $enumerator.GetDefaultAudioEndpoint(
            [NAudio.CoreAudioApi.DataFlow]::Render,
            [NAudio.CoreAudioApi.Role]::Multimedia
        )
    }
    return $script:AudioDevice
}

# SOHA nem dobhat kifele kivetelt - a monitor ciklus stabilitasa ettol fugg.
function Get-ClientAudioPeaks {
    param([uint32[]]$Pids)

    $peakResult = @{}
    if (-not $Pids -or $Pids.Count -eq 0) { return $peakResult }

    try {
        $device = Get-AudioDeviceCached
        $sessions = $device.AudioSessionManager.Sessions
        for ($i = 0; $i -lt $sessions.Count; $i++) {
            try {
                $session = $sessions[$i]
                $sessionPid = [uint32]$session.GetProcessID
                if ($Pids -notcontains $sessionPid) { continue }
                $peakPct = [Math]::Round($session.AudioMeterInformation.MasterPeakValue * 100, 2)
                if (-not $peakResult.ContainsKey($sessionPid) -or $peakResult[$sessionPid] -lt $peakPct) {
                    $peakResult[$sessionPid] = $peakPct
                }
            } catch {
                # egy session hibaja ne allitsa meg a tobbi feldolgozasat
                continue
            }
        }
    } catch {
        # az alapertelmezett eszkoz valtozhatott - dobjuk el a cache-t, kovetkezo hivas ujra probalja
        $script:AudioDevice = $null
        Write-Log -Level DEBUG -Message "Audio device cache torolve: $($_.Exception.Message)"
    }
    return $peakResult
}

# ==============================================================================
# 4) PID SELECTOR GUI
# ==============================================================================

function Show-ClientSelectorDialog {
    $wowProcesses = @(
        Get-Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessName -eq "Wow" } |
        Sort-Object Id
    )

    if ($wowProcesses.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Nem talalhato futo Wow process.", "AI-FishBot Monitor v2.1", "OK", "Warning") | Out-Null
        return @()
    }

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "AI-FishBot Monitor v2.1 - WoW PID valasztas"
    $form.Size = New-Object System.Drawing.Size(560, 500)
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = "Valaszd ki a monitorozni kivant WoW klienseket:"
    $titleLabel.Location = New-Object System.Drawing.Point(20, 20)
    $titleLabel.Size = New-Object System.Drawing.Size(500, 30)
    $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
    $form.Controls.Add($titleLabel)

    $list = New-Object System.Windows.Forms.CheckedListBox
    $list.Location = New-Object System.Drawing.Point(20, 60)
    $list.Size = New-Object System.Drawing.Size(500, 320)
    $list.CheckOnClick = $true
    $list.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    foreach ($process in $wowProcesses) {
        $windowTitle = ""
        try { $windowTitle = $process.MainWindowTitle } catch { $windowTitle = "" }
        if ([string]::IsNullOrWhiteSpace($windowTitle)) { $windowTitle = "World of Warcraft" }
        [void]$list.Items.Add(("PID {0} | {1}" -f $process.Id, $windowTitle))
    }
    $form.Controls.Add($list)

    $okButton = New-Object System.Windows.Forms.Button
    $okButton.Text = "OK"
    $okButton.Location = New-Object System.Drawing.Point(330, 400)
    $okButton.Size = New-Object System.Drawing.Size(90, 35)
    $okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.Controls.Add($okButton)

    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Text = "Megse"
    $cancelButton.Location = New-Object System.Drawing.Point(430, 400)
    $cancelButton.Size = New-Object System.Drawing.Size(90, 35)
    $cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.Controls.Add($cancelButton)

    $form.AcceptButton = $okButton
    $form.CancelButton = $cancelButton

    $result = $form.ShowDialog()
    if ($result -ne [System.Windows.Forms.DialogResult]::OK) { return @() }

    $selected = @()
    foreach ($idx in $list.CheckedIndices) {
        $selected += [uint32]$wowProcesses[$idx].Id
    }
    return @($selected | Select-Object -Unique)
}

# ==============================================================================
# 5) CLIENT STATE
# ==============================================================================

function New-ClientState {
    param([uint32]$WowPid)

    $installDir = $null
    $exePath = $null
    try {
        $proc = Get-Process -Id $WowPid -ErrorAction Stop
        if ($proc.Path) {
            $exePath = $proc.Path
            $installDir = Split-Path $proc.Path -Parent
        }
    } catch { }

    $buffStates = @{}
    foreach ($idx in $Config.Client.BuffsEnabled) {
        $buffStates[$idx] = @{ Phase = "NeedPress"; NextActionTime = (Get-Date) }
    }

    return @{
        PID                     = $WowPid
        InstallDir              = $installDir
        ExePath                 = $exePath

        Phase                   = "NeedCast"
        NextActionTime          = Get-Date
        CastDeadline            = Get-Date
        RangeCount              = 0
        RestartTotal            = 0

        HookCount               = 0
        FishCounts              = @{}
        LastActivity            = Get-Date

        LastLootSyncHookCount   = 0
        LastSavedVarUpdate      = $null
        IsSyncing               = $false
        LootReloadState         = "Idle"
        LootReloadNextCheck     = Get-Date

        Buffs                   = $buffStates

        NoBiteStreak            = 0
        ReconnectAttempts       = 0
        NeedsManualHelp         = $false
        IsRecovering            = $false
        SecondEnterDueTime      = $null

        ActiveTimeSeconds       = 0.0
        PausedTimeSeconds       = 0.0
        ReloadTimeSeconds       = 0.0

        Status                  = "OK"
        StatusReason            = ""
        LastProcessCheck        = Get-Date
        ProcessAlive            = $true
    }
}

$script:Clients = @{}

# ==============================================================================
# 6) INPUT ENGINE (kozponti Input Queue)
# ==============================================================================

$script:WShell = $null
if ($Config.General.UseWindowFocus) {
    try { $script:WShell = New-Object -ComObject wscript.shell }
    catch { Write-LogException -Context "WScript.Shell letrehozas" -ErrorRecord $_ }
}

$script:InputQueue       = New-Object System.Collections.Generic.List[object]
$script:PendingInputKeys = @{}     # "$TargetPid|$Type" -> $true, amig fuggoben van
$script:InputBusy        = $false
$script:MaxInputRetries  = 3

$script:InputPriority = @{
    Recovery = 0
    Bobber   = 1
    Cast     = 2
    Buff     = 3
    Maintenance = 4   # Reload, ChatCommand, Logout
}

# Kozponti process-ellenorzo - mindenhol ezt hasznaljuk, ne szort Get-Process hivasokat.
function Test-ClientProcess {
    param($Client)
    if (-not $Client) { return $false }
    try {
        $proc = Get-Process -Id $Client.PID -ErrorAction Stop
        if ($proc.HasExited) { return $false }
        return $true
    } catch {
        return $false
    }
}

function Focus-Client {
    param([uint32]$TargetPid)
    if ($Config.General.UseWindowFocus -and $script:WShell) {
        try { $script:WShell.AppActivate([int]$TargetPid) | Out-Null } catch { }
        Start-Sleep -Milliseconds 60   # minimalis, szuksegszeru fokusz-beallasi ido
    }
}

function Get-EscapedSendKeys {
    param([string]$Text)
    $special = '+^%~(){}[]'
    $sb = New-Object System.Text.StringBuilder
    foreach ($ch in $Text.ToCharArray()) {
        if ($special.IndexOf($ch) -ge 0) { [void]$sb.Append('{').Append($ch).Append('}') }
        else { [void]$sb.Append($ch) }
    }
    return $sb.ToString()
}

function Send-RawKey {
    param([string]$Key)
    if ($Config.Client.UsePi) {
        if ($script:PicoPort -and $script:PicoPort.IsOpen) {
            try { $script:PicoPort.WriteLine($Key) } catch { Write-LogException -Context "Pi WriteLine" -ErrorRecord $_ }
        }
    } else {
        [System.Windows.Forms.SendKeys]::SendWait("{$Key}")
    }
}

# --- Bekerules a queue-ba: dedup-al, halott klienst elutasit ---
function Queue-Input {
    param(
        [uint32]$TargetPid,
        [string]$Type,
        [hashtable]$Payload = @{},
        [int]$Priority = 4
    )

    $client = $script:Clients[$TargetPid]
    if (-not $client) { return $false }
    if (-not (Test-ClientProcess -Client $client)) { return $false }

    $dedupKey = "$TargetPid|$Type"
    if ($script:PendingInputKeys.ContainsKey($dedupKey)) { return $false }

    $item = @{
        PID       = $TargetPid
        Type      = $Type
        Payload   = $Payload
        Priority  = $Priority
        CreatedAt = Get-Date
        RetryCount = 0
    }
    $script:InputQueue.Add($item) | Out-Null
    $script:PendingInputKeys[$dedupKey] = $true

    $logPayload = if ($Type -like "Recovery*") { "[REDACTED]" } else { ($Payload.Keys -join ",") }
    Write-Log -Level DEBUG -Message "[$TargetPid] Queue-Input: $Type (prio=$Priority, payload=$logPayload)"
    return $true
}

# --- Tenyleges vegrehajtas (fokusz + billentyu) - CSAK ezen a helyen tortenik SendKeys ---
function Invoke-InputAction {
    param($Client, $Item)

    Focus-Client -TargetPid $Client.PID

    switch ($Item.Type) {
        "Cast"   { Send-RawKey -Key $Config.General.CastKey;   return $true }
        "Bobber" { Send-RawKey -Key $Config.General.BobberKey; return $true }
        "Buff"   { Send-RawKey -Key $Item.Payload.Keybind;     return $true }
        "Logout" { Send-RawKey -Key $Config.General.LogoutKey; return $true }

        "ChatCommand" {
            if ($Config.Client.UsePi) { return $false }
            [System.Windows.Forms.SendKeys]::SendWait("{ENTER}$($Item.Payload.Command){ENTER}")
            return $true
        }
        "Reload" {
            if ($Config.Client.UsePi) { return $false }
            [System.Windows.Forms.SendKeys]::SendWait("{ENTER}/reload{ENTER}")
            return $true
        }
        "RecoveryPassword" {
            if ($Config.Client.UsePi) {
                Write-Log -Level ERROR -Message "[$($Client.PID)] Recovery Pi modban nem tamogatott"
                return $false
            }
            if ([string]::IsNullOrEmpty($wowPassword)) {
                Write-Log -Level ERROR -Message "[$($Client.PID)] Nincs beallitva AIFISHBOT_WOW_PASSWORD - recovery nem vegezheto el"
                return $false
            }
            [System.Windows.Forms.SendKeys]::SendWait("^a")
            [System.Windows.Forms.SendKeys]::SendWait("{DEL}")
            $escaped = Get-EscapedSendKeys -Text $wowPassword
            [System.Windows.Forms.SendKeys]::SendWait("$escaped{ENTER}")
            return $true
        }
        "RecoverySecondEnter" {
            if ($Config.Client.UsePi) { return $false }
            [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
            return $true
        }
        default {
            Write-Log -Level WARNING -Message "Ismeretlen input tipus: $($Item.Type)"
            return $false
        }
    }
}

# --- Queue elem lezarasa: allapotgep-atmenetek innen indulnak ---
function Complete-Input {
    param($Item, [bool]$Success)

    $dedupKey = "$($Item.PID)|$($Item.Type)"
    $script:PendingInputKeys.Remove($dedupKey)
    [void]$script:InputQueue.Remove($Item)

    $client = $script:Clients[$Item.PID]
    if (-not $client) { return }
    $now = Get-Date

    if (-not $Success) {
        Write-Log -Level WARNING -Message "[$($Item.PID)] Input sikertelen: $($Item.Type) (retry=$($Item.RetryCount))"
        if ($Item.Type -eq "RecoveryPassword" -or $Item.Type -eq "RecoverySecondEnter") {
            $client.NeedsManualHelp = $true
            $client.IsRecovering = $false
            $client.StatusReason = "Recovery input sikertelen ($($Item.Type))"
        }
        elseif ($Item.Type -eq "Reload") {
            $client.LootReloadState = "Failed"
        }
        return
    }

    switch ($Item.Type) {
        "Cast" {
            $client.Phase = "AwaitingBite"
            $settleSeconds = 2
            $castingTime = if ($Config.General.Retail) { 22 } else { 30 }
            $client.NextActionTime = $now.AddSeconds($settleSeconds)
            $client.CastDeadline   = $now.AddSeconds($settleSeconds + $castingTime)
        }
        "Bobber" {
            $client.LastActivity = $now
            $client.Phase = "PostCatch"
            $lootWaitMs = [int]($Config.General.LootWaitSeconds * 1000)
            $client.NextActionTime = $now.AddMilliseconds($lootWaitMs + (Get-Random -Minimum 0 -Maximum 400))
        }
        "Buff" {
            $idx = $Item.Payload.Index
            $buffCfg = $Config.Client.Buffs[$idx]
            if ($buffCfg -and $client.Buffs.ContainsKey($idx)) {
                $client.Buffs[$idx].Phase = "Casting"
                $client.Buffs[$idx].NextActionTime = $now.AddSeconds([Math]::Max($buffCfg.CastTimeSeconds, 0) + 1)
            }
        }
        "Reload" {
            $client.LootReloadState = "SyncLoot"
            $client.LootReloadNextCheck = $now.AddSeconds($Config.Loot.ReloadSettleSeconds)
        }
        "RecoveryPassword" {
            $client.SecondEnterDueTime = $now.AddSeconds($Config.General.ReconnectSecondEnterDelaySeconds)
        }
        "RecoverySecondEnter" {
            $client.IsRecovering = $false
        }
    }
}

# --- Egy tick alatt LEGFELJEBB EGY elemet dolgoz fel, hogy a GUI ne akadjon meg ---
function Process-InputQueue {
    if ($script:InputBusy) { return }
    if ($script:InputQueue.Count -eq 0) { return }

    $script:InputBusy = $true
    try {
        $sorted = $script:InputQueue | Sort-Object Priority, CreatedAt
        $item = $sorted[0]

        $client = $script:Clients[$item.PID]
        if (-not $client -or -not (Test-ClientProcess -Client $client)) {
            Complete-Input -Item $item -Success $false
            return
        }
        if ($client.NeedsManualHelp -and $item.Type -notlike "Recovery*") {
            Complete-Input -Item $item -Success $false
            return
        }

        $ok = $false
        try {
            $ok = Invoke-InputAction -Client $client -Item $item
        } catch {
            Write-LogException -Context "[$($item.PID)] Invoke-InputAction ($($item.Type))" -ErrorRecord $_
            $ok = $false
        }

        if (-not $ok) {
            $item.RetryCount++
            if ($item.RetryCount -ge $script:MaxInputRetries) {
                Complete-Input -Item $item -Success $false
            }
            # kulonben a queue-ban marad, kovetkezo tick ujraprobalja (nincs while/retry-loop)
        } else {
            Complete-Input -Item $item -Success $true
        }
    } finally {
        $script:InputBusy = $false
    }
}

# --- Buff allapotgep: NeedPress -> (queue-ol) -> Casting -> Active -> NeedPress ---
function Update-ClientBuffs {
    param($Client, [datetime]$Now)

    foreach ($idx in $Config.Client.BuffsEnabled) {
        $buffCfg = $Config.Client.Buffs[$idx]
        if (-not $buffCfg -or -not $buffCfg.Keybind) { continue }
        if (-not $Client.Buffs.ContainsKey($idx)) {
            $Client.Buffs[$idx] = @{ Phase = "NeedPress"; NextActionTime = $Now }
        }
        $buffState = $Client.Buffs[$idx]
        if ($Now -lt $buffState.NextActionTime) { continue }

        switch ($buffState.Phase) {
            "NeedPress" {
                Queue-Input -TargetPid $Client.PID -Type "Buff" -Priority $script:InputPriority.Buff -Payload @{ Index = $idx; Keybind = $buffCfg.Keybind } | Out-Null
                # a Phase valtast a Complete-Input vegzi siker eseten; itt csak elkeruljuk
                # az azonnali ujra-ellenorzest a kovetkezo tick-ig.
            }
            "Casting" {
                # a Complete-Input mar beallitotta a NextActionTime-ot, itt csak varunk
            }
            "Active" {
                $buffState.Phase = "NeedPress"
                $buffState.NextActionTime = $Now
            }
        }
    }
}

# ==============================================================================
# 7) LOOT TRACKER (AIFishLootTracker addon SavedVariables)
# ==============================================================================

function Get-SavedVarFile {
    param([string]$InstallDir)
    if (-not $InstallDir) { return $null }
    $pattern = Join-Path $InstallDir "WTF\Account\*\SavedVariables\AIFishLootTracker.lua"
    try {
        return (
            Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending |
            Select-Object -First 1
        )
    } catch {
        return $null
    }
}

# Csak akkor irja felul a korabbi adatot, ha a parse tenyleg sikerult es ertelmes.
function Update-LootLog {
    param($Client)

    if (-not $Client.InstallDir) { return $false }
    $svFile = Get-SavedVarFile -InstallDir $Client.InstallDir
    if (-not $svFile) {
        Write-Log -Level DEBUG -Message "[$($Client.PID)] Nincs meg AIFishLootTracker.lua"
        return $false
    }
    if ($svFile.Length -eq 0) {
        Write-Log -Level DEBUG -Message "[$($Client.PID)] SavedVariables fajl ures"
        return $false
    }

    try {
        $content = Get-Content -Path $svFile.FullName -Raw -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($content) -or $content -notmatch "AIFishLootDB") {
            Write-Log -Level WARNING -Message "[$($Client.PID)] SavedVariables tartalma nem ertelmezheto - regi adat megtartva"
            return $false
        }

        # Csak az AIFishLootDB blokkon belul keresunk, hogy veletlenul ne fogjunk
        # meg mas Lua tablat ugyanabbol a fajlbol.
        $blockMatch = [regex]::Match($content, 'AIFishLootDB\s*=\s*\{(.*?)\n\}', [System.Text.RegularExpressions.RegexOptions]::Singleline)
        $searchText = if ($blockMatch.Success) { $blockMatch.Groups[1].Value } else { $content }

        $newCounts = @{}
        $matches = [regex]::Matches($searchText, '\["(.+?)"\]\s*=\s*(\d+)')
        foreach ($m in $matches) {
            $newCounts[$m.Groups[1].Value] = [int]$m.Groups[2].Value
        }

        if ($matches.Count -eq 0) {
            Write-Log -Level DEBUG -Message "[$($Client.PID)] SavedVariables parse: 0 talalat, regi adat megtartva"
            return $false
        }

        $Client.FishCounts = $newCounts
        $Client.LastSavedVarUpdate = Get-Date
        Write-Log -Level DEBUG -Message "[$($Client.PID)] Loot sync ok: $($newCounts.Count) fajta"
        return $true
    } catch {
        Write-LogException -Context "[$($Client.PID)] Update-LootLog" -ErrorRecord $_
        return $false
    }
}

function Reset-ClientLootTracker {
    param([uint32]$WowPid)
    Queue-Input -TargetPid $WowPid -Type "ChatCommand" -Priority $script:InputPriority.Maintenance -Payload @{ Command = "/aifishloot reset" } | Out-Null
}

# Nem blokkolo reload allapotgep: Idle -> Requested -> SyncLoot -> Idle/Failed
function Update-LootReloadState {
    param($Client, [datetime]$Now)

    if (-not $Config.Loot.Enabled) { return }
    if ($Client.NeedsManualHelp) { return }

    switch ($Client.LootReloadState) {
        "Idle" {
            if (($Client.HookCount - $Client.LastLootSyncHookCount) -ge $Config.Loot.ReloadEveryCatches) {
                $Client.IsSyncing = $true
                $queued = Queue-Input -TargetPid $Client.PID -Type "Reload" -Priority $script:InputPriority.Maintenance
                if ($queued) { $Client.LootReloadState = "Requested" }
                else { $Client.IsSyncing = $false }
            }
        }
        "Requested" {
            # varunk, amig a Complete-Input at nem allitja SyncLoot-ra (vagy Failed-re hiba eseten)
        }
        "SyncLoot" {
            if ($Now -ge $Client.LootReloadNextCheck) {
                $ok = Update-LootLog -Client $Client
                $Client.LastLootSyncHookCount = $Client.HookCount
                $Client.IsSyncing = $false
                $Client.LootReloadState = "Idle"
                if (-not $ok) { Write-Log -Level WARNING -Message "[$($Client.PID)] Loot sync nem hozott uj adatot" }
            }
        }
        "Failed" {
            $Client.LastLootSyncHookCount = $Client.HookCount
            $Client.IsSyncing = $false
            $Client.LootReloadState = "Idle"
        }
        default { $Client.LootReloadState = "Idle" }
    }
}

# ==============================================================================
# 8) PRICE ENGINE
# ==============================================================================

$script:PriceCache = @{
    Price       = $Config.Price.FallbackPrice
    LastUpdated = $null
    Source      = "FALLBACK"
    Online      = $false
}
$script:LastPriceOfflineNotify = $null

function Test-ValidPrice {
    param($Value)
    if ($null -eq $Value) { return $false }
    try {
        $d = [double]$Value
        if ([double]::IsNaN($d) -or [double]::IsInfinity($d)) { return $false }
        if ($d -le 0) { return $false }
        return $true
    } catch { return $false }
}

function Update-WyrmfishPrice {
    param([datetime]$Now)

    if ($script:PriceCache.LastUpdated -and
        (($Now - $script:PriceCache.LastUpdated).TotalMinutes -lt $Config.Price.RefreshIntervalMinutes)) {
        return
    }

    $result = $null
    if ($Config.Price.ProviderScriptBlock) {
        try {
            $result = & $Config.Price.ProviderScriptBlock $Config.Price.Region $Config.Price.Realm $Config.Price.Item
        } catch {
            Write-LogException -Context "Price provider" -ErrorRecord $_
            $result = $null
        }
    }

    if (Test-ValidPrice $result) {
        $script:PriceCache.Price       = [double]$result
        $script:PriceCache.LastUpdated = $Now
        $script:PriceCache.Source      = "PROVIDER"
        $script:PriceCache.Online      = $true
    } else {
        $wasOnline = $script:PriceCache.Online
        $script:PriceCache.Price       = $Config.Price.FallbackPrice
        $script:PriceCache.LastUpdated = $Now
        $script:PriceCache.Source      = "FALLBACK"
        $script:PriceCache.Online      = $false
        if ($wasOnline -or -not $script:LastPriceOfflineNotify) {
            Send-ThrottledNotification -Key "price-offline" -Message "**AI-FishBot Monitor v2.1** Price source OFFLINE - fallback ar ($($Config.Price.FallbackPrice) gold/db) hasznalva."
            $script:LastPriceOfflineNotify = $Now
        }
    }
}

# ==============================================================================
# 9) REVENUE ENGINE
# ==============================================================================

function ConvertTo-SafeNumber {
    param([double]$Value, [double]$FallbackValue = 0)
    if ([double]::IsNaN($Value) -or [double]::IsInfinity($Value)) { return $FallbackValue }
    return $Value
}

function Get-RevenueStats {
    param([int]$TotalWyrmfish, [double]$ActiveHours)

    $eurPerGold  = if ($Config.Revenue.GoldPerEuro -gt 0) { 1.0 / [double]$Config.Revenue.GoldPerEuro } else { 0 }
    $goldTotal   = $TotalWyrmfish * $script:PriceCache.Price
    $goldPerHour = if ($ActiveHours -gt 0) { $goldTotal / $ActiveHours } else { 0 }
    $eurPerHour  = $goldPerHour * $eurPerGold
    $hufPerHour  = $eurPerHour * $Config.Revenue.EurToHuf
    $hufTotal    = ($goldTotal * $eurPerGold) * $Config.Revenue.EurToHuf

    return [PSCustomObject]@{
        GoldTotal     = ConvertTo-SafeNumber $goldTotal
        GoldPerHour   = ConvertTo-SafeNumber $goldPerHour
        EurPerHour    = ConvertTo-SafeNumber $eurPerHour
        HufPerHour    = ConvertTo-SafeNumber $hufPerHour
        HufTotal      = ConvertTo-SafeNumber $hufTotal
        Projection6h  = ConvertTo-SafeNumber ($hufPerHour * 6)
        Projection12h = ConvertTo-SafeNumber ($hufPerHour * 12)
        Projection24h = ConvertTo-SafeNumber ($hufPerHour * 24)
        Projection7d  = ConvertTo-SafeNumber ($hufPerHour * 24 * 7)
    }
}

# ==============================================================================
# 10) TARGET ENGINE
# ==============================================================================

function Get-TargetProgress {
    param($Revenue)

    $current = $Revenue.HufTotal
    $target  = [Math]::Max($Config.Target.TargetHuf, 0)
    $remaining = [Math]::Max($target - $current, 0)
    $progressPct = if ($target -gt 0) { [Math]::Min(($current / $target) * 100, 100) } else { 0 }

    $hufPerWyrmfish = $script:PriceCache.Price * (1.0 / [Math]::Max([double]$Config.Revenue.GoldPerEuro, 0.0001)) * $Config.Revenue.EurToHuf
    $neededWyrmfish = if ($hufPerWyrmfish -gt 0) { [Math]::Ceiling($remaining / $hufPerWyrmfish) } else { 0 }
    $hasEta = $Revenue.HufPerHour -gt 0
    $etaHours = if ($hasEta) { $remaining / $Revenue.HufPerHour } else { $null }

    return [PSCustomObject]@{
        Target         = $target
        Current        = $current
        Remaining      = $remaining
        ProgressPct    = ConvertTo-SafeNumber $progressPct
        NeededWyrmfish = $neededWyrmfish
        EtaHours       = $etaHours
        HasEta         = $hasEta
    }
}

# ==============================================================================
# 11) METRICS ENGINE
# ==============================================================================

function Update-ClientTimeAccumulators {
    param($Client, [double]$DeltaSeconds)

    # Vedelem hosszabb GUI-akadas / rendszer-alvas utan: ne adjon hozza irrealis idot.
    $DeltaSeconds = [Math]::Min([Math]::Max($DeltaSeconds, 0), 5.0)
    if ($DeltaSeconds -le 0) { return }

    if ($Client.NeedsManualHelp -or $Client.IsRecovering -or -not $Client.ProcessAlive) {
        $Client.PausedTimeSeconds += $DeltaSeconds
    } elseif ($Client.IsSyncing) {
        $Client.ReloadTimeSeconds += $DeltaSeconds
    } else {
        $Client.ActiveTimeSeconds += $DeltaSeconds
    }
}

function Get-ClientMetrics {
    param($Client)

    $activeHours = $Client.ActiveTimeSeconds / 3600.0
    $fishPerHour = if ($activeHours -gt 0) { $Client.HookCount / $activeHours } else { 0 }
    $wyrmCount = 0
    if ($Client.FishCounts.ContainsKey($Config.Loot.HighlightFishName)) {
        $wyrmCount = $Client.FishCounts[$Config.Loot.HighlightFishName]
    }
    $wyrmPerHour = if ($activeHours -gt 0) { $wyrmCount / $activeHours } else { 0 }

    return [PSCustomObject]@{
        ActiveHours     = $activeHours
        FishPerHour     = ConvertTo-SafeNumber $fishPerHour
        WyrmfishCount   = $wyrmCount
        WyrmfishPerHour = ConvertTo-SafeNumber $wyrmPerHour
    }
}

# ==============================================================================
# 12) ANOMALY DETECTOR (a GUI-refresh temposaval fut)
# ==============================================================================

function Add-Alert {
    param([uint32]$TargetPid, [string]$Severity, [string]$Reason)

    $entry = [PSCustomObject]@{
        Timestamp = Get-Date
        PID       = $TargetPid
        Severity  = $Severity
        Reason    = $Reason
    }
    $script:Alerts.Add($entry) | Out-Null
    if ($script:Alerts.Count -gt $Config.Gui.AlertHistoryLimit) {
        $script:Alerts.RemoveRange(0, $script:Alerts.Count - $Config.Gui.AlertHistoryLimit)
    }
}

function Test-ClientAnomalies {
    param($Client, [datetime]$Now, [double]$AvgFishPerHour)

    $Client.ProcessAlive = Test-ClientProcess -Client $Client

    $newStatus = "OK"
    $reason = ""

    if (-not $Client.ProcessAlive) {
        $newStatus = "ERROR"; $reason = "WoW process eltunt"
    }
    elseif ($Client.NeedsManualHelp) {
        $newStatus = "MANUAL"; $reason = "Kezi beavatkozas szukseges (reconnect sikertelen)"
    }
    elseif (($Now - $Client.LastActivity).TotalMinutes -ge $Config.General.NoCatchWarningMinutes) {
        $newStatus = "WARNING"; $reason = "Nincs fogas $($Config.General.NoCatchWarningMinutes) perce"
    }
    else {
        $metrics = Get-ClientMetrics -Client $Client
        if ($metrics.ActiveHours -ge 0.15 -and $AvgFishPerHour -gt 0 -and
            $metrics.FishPerHour -lt ($AvgFishPerHour * ($Config.General.FishRateDropThresholdPct / 100.0))) {
            $newStatus = "WARNING"; $reason = "Fish/hour az atlag alatt"
        }
        elseif ($Config.Loot.Enabled -and $Client.LastSavedVarUpdate -and
                ($Now - $Client.LastSavedVarUpdate).TotalMinutes -ge 60) {
            $newStatus = "WARNING"; $reason = "Loot adat nem frissult 60 perce"
        }
    }

    $prevStatus = $Client.Status
    $Client.Status = $newStatus
    $Client.StatusReason = $reason

    if ($newStatus -ne $prevStatus) {
        if ($newStatus -eq "OK") {
            Write-Log -Level INFO -Message "[$($Client.PID)] Allapot helyreallt: OK"
        }
        elseif ($newStatus -eq "WARNING" -and $prevStatus -eq "OK") {
            Add-Alert -TargetPid $Client.PID -Severity "WARNING" -Reason $reason
            Send-ClientWarningEvent -Client $Client
            Write-Log -Level WARNING -Message "[$($Client.PID)] $reason"
        }
        elseif ($newStatus -eq "ERROR" -or $newStatus -eq "MANUAL") {
            Add-Alert -TargetPid $Client.PID -Severity $newStatus -Reason $reason
            Send-ClientErrorEvent -Client $Client
            Write-Log -Level ERROR -Message "[$($Client.PID)] $reason"
        }
    }
}

$script:Alerts = New-Object System.Collections.Generic.List[object]

# ==============================================================================
# 13) NOTIFICATION ENGINE (Discord, throttle-va)
# ==============================================================================

$script:NotifyThrottle = @{}

function Send-DiscordMessage {
    param([string]$Msg)
    if (-not $Config.Notification.Enabled -or -not $Config.Notification.DiscordWebhook) { return }
    try {
        $headers = @{ "Content-Type" = "application/json" }
        $body = @{ content = $Msg } | ConvertTo-Json
        Invoke-RestMethod -Uri $Config.Notification.DiscordWebhook -Method POST -Headers $headers -Body $body `
            -TimeoutSec $Config.Notification.TimeoutSeconds | Out-Null
    } catch {
        Write-LogException -Context "Discord kuldes" -ErrorRecord $_
    }
}

function Send-ThrottledNotification {
    param([string]$Key, [string]$Message)
    $last = $script:NotifyThrottle[$Key]
    if ($last -and ((Get-Date) - $last).TotalMinutes -lt $Config.Notification.ThrottleMinutes) { return }
    Send-DiscordMessage -Msg $Message
    $script:NotifyThrottle[$Key] = Get-Date
}

function Send-SessionStartedEvent {
    if ($Config.Notification.OnStart) {
        Send-DiscordMessage -Msg "**AI-FishBot Monitor v2.1** Session inditva ($script:SessionId) - $($script:Clients.Count) kliens."
    }
}
function Send-SessionStoppedEvent {
    param([string]$Summary)
    if ($Config.Notification.OnStop) {
        Send-DiscordMessage -Msg "**AI-FishBot Monitor v2.1** Session vege ($script:SessionId).`n$Summary"
    }
}
function Send-ClientWarningEvent {
    param($Client)
    Send-ThrottledNotification -Key "warn-$($Client.PID)" -Message "**AI-FishBot Monitor v2.1** [$($Client.PID)] WARNING: $($Client.StatusReason)"
}
function Send-ClientErrorEvent {
    param($Client)
    Send-ThrottledNotification -Key "err-$($Client.PID)" -Message "**AI-FishBot Monitor v2.1** [$($Client.PID)] $($Client.Status): $($Client.StatusReason)"
}
function Send-TargetReachedEvent {
    Send-ThrottledNotification -Key "target-reached" -Message "**AI-FishBot Monitor v2.1** CEL ELERVE! ($($Config.Target.TargetHuf) Ft)"
}

# ==============================================================================
# 14) SESSION / REPORT ENGINE
# ==============================================================================

$script:SessionStartTime    = Get-Date
$script:MonitoringStartTime = $null
$script:ReportRows          = New-Object System.Collections.Generic.List[object]
$script:CsvPath             = Join-Path $Config.Logging.Directory ("session_{0}.csv" -f $script:SessionId)
$script:JsonPath            = Join-Path $Config.Logging.Directory ("session_{0}.json" -f $script:SessionId)
$script:LastReportTime      = Get-Date

function Add-ReportSnapshot {
    param([datetime]$Now)
    try {
        foreach ($clientPid in $script:Clients.Keys) {
            $client = $script:Clients[$clientPid]
            $metrics = Get-ClientMetrics -Client $client
            $revenue = Get-RevenueStats -TotalWyrmfish $metrics.WyrmfishCount -ActiveHours $metrics.ActiveHours

            $script:ReportRows.Add([PSCustomObject]@{
                Timestamp       = $Now
                Client          = $clientPid
                Fish            = $client.HookCount
                Wyrmfish        = $metrics.WyrmfishCount
                FishPerHour     = [Math]::Round($metrics.FishPerHour, 2)
                WyrmfishPerHour = [Math]::Round($metrics.WyrmfishPerHour, 2)
                Price           = $script:PriceCache.Price
                GoldPerHour     = [Math]::Round($revenue.GoldPerHour, 2)
                EurPerHour      = [Math]::Round($revenue.EurPerHour, 2)
                HufPerHour      = [Math]::Round($revenue.HufPerHour, 2)
            }) | Out-Null
        }
        $script:ReportRows | Export-Csv -Path $script:CsvPath -NoTypeInformation -Force -Encoding UTF8
    } catch {
        Write-LogException -Context "Add-ReportSnapshot" -ErrorRecord $_
    }
}

function Export-SessionJsonSummary {
    try {
        $totalFish = 0
        $totalWyrm = 0
        foreach ($client in $script:Clients.Values) {
            $totalFish += $client.HookCount
            if ($client.FishCounts.ContainsKey($Config.Loot.HighlightFishName)) {
                $totalWyrm += $client.FishCounts[$Config.Loot.HighlightFishName]
            }
        }
        $activeHoursTotal = (($script:Clients.Values | ForEach-Object { $_.ActiveTimeSeconds }) | Measure-Object -Sum).Sum / 3600.0
        $revenue = Get-RevenueStats -TotalWyrmfish $totalWyrm -ActiveHours $activeHoursTotal

        $summary = [PSCustomObject]@{
            SessionId       = $script:SessionId
            SessionStart    = $script:SessionStartTime
            SessionEnd      = Get-Date
            ClientCount     = $script:Clients.Count
            TotalFish       = $totalFish
            TotalWyrmfish   = $totalWyrm
            WyrmfishPerHour = if ($activeHoursTotal -gt 0) { [Math]::Round($totalWyrm / $activeHoursTotal, 2) } else { 0 }
            Price           = $script:PriceCache.Price
            PriceSource     = $script:PriceCache.Source
            RevenueHuf      = [Math]::Round($revenue.HufTotal, 0)
            Warnings        = @($script:Alerts | ForEach-Object { "$($_.Timestamp) [$($_.Severity)] [$($_.PID)] $($_.Reason)" })
        }

        $summary | ConvertTo-Json -Depth 6 | Out-File -FilePath $script:JsonPath -Force -Encoding UTF8
        return $summary
    } catch {
        Write-LogException -Context "Export-SessionJsonSummary" -ErrorRecord $_
        return [PSCustomObject]@{ TotalFish = 0; TotalWyrmfish = 0; RevenueHuf = 0 }
    }
}

# ==============================================================================
# 15) MONITOR ENGINE (gyors tick)
# ==============================================================================

$script:LastMonitorTick = $null
$script:MonitorBusy     = $false

function Invoke-MonitorTick {
    if ($script:MonitorBusy) { return "OK" }
    $script:MonitorBusy = $true

    try {
        $now = Get-Date
        if (-not $script:LastMonitorTick) { $script:LastMonitorTick = $now }
        $delta = ($now - $script:LastMonitorTick).TotalSeconds
        $script:LastMonitorTick = $now

        $activePids = @($script:Clients.Keys)

        foreach ($clientPid in $activePids) {
            $client = $script:Clients[$clientPid]
            try {
                Update-ClientTimeAccumulators -Client $client -DeltaSeconds $delta

                if ($client.NeedsManualHelp) { continue }
                if (-not (Test-ClientProcess -Client $client)) { $client.ProcessAlive = $false; continue }
                $client.ProcessAlive = $true

                # --- masodik Enter (reconnect utokezeles) ---
                if ($client.SecondEnterDueTime -and $now -ge $client.SecondEnterDueTime) {
                    $queued = Queue-Input -TargetPid $clientPid -Type "RecoverySecondEnter" -Priority $script:InputPriority.Recovery
                    if ($queued) { $client.SecondEnterDueTime = $null }
                }

                # --- buffok ---
                Update-ClientBuffs -Client $client -Now $now

                # --- loot reload allapotgep ---
                Update-LootReloadState -Client $client -Now $now

                # --- fazis-allapotgep ---
                if ($now -ge $client.NextActionTime) {
                    switch ($client.Phase) {

                        "NeedCast" {
                            if ($Config.General.UseWeakAura) {
                                # WeakAura mod: retry-logika egy klienesen belul marad, de
                                # mindig max 1 dobas/tick (nincs blokkolo while+Sleep tobbszor).
                                if ($client.RangeCount -ge $Config.General.FishingRetries) {
                                    Write-Log -Level WARNING -Message "[$clientPid] $($Config.General.FishingRetries) sikertelen dobas - kihagyva ebben a korben"
                                    $client.RangeCount = 0
                                    $client.NextActionTime = $now.AddSeconds(3)
                                } else {
                                    $queued = Queue-Input -TargetPid $clientPid -Type "Cast" -Priority $script:InputPriority.Cast
                                    if ($queued) {
                                        $client.RangeCount++
                                        $client.RestartTotal++
                                        $client.NextActionTime = $now.AddMilliseconds((Get-Random -Minimum 1000 -Maximum 1500))
                                    }
                                }
                            } else {
                                Queue-Input -TargetPid $clientPid -Type "Cast" -Priority $script:InputPriority.Cast | Out-Null
                                # Complete-Input allitja at AwaitingBite-ra siker eseten; addig
                                # a dedup megvedi a tobbszoros queue-olastol.
                            }
                        }

                        "AwaitingBite" {
                            if ($now -gt $client.CastDeadline) {
                                $client.Phase = "NeedCast"
                                $client.NextActionTime = $now
                                $client.RangeCount = 0
                                $client.NoBiteStreak++

                                if ($client.NoBiteStreak -ge $Config.General.NoBiteStreakLimit -and -not $client.IsRecovering -and -not $client.SecondEnterDueTime) {
                                    $client.NoBiteStreak = 0
                                    if ($client.ReconnectAttempts -ge $Config.General.MaxReconnectAttempts) {
                                        $client.NeedsManualHelp = $true
                                        $client.StatusReason = "Reconnect sikertelen ($($Config.General.MaxReconnectAttempts)x)"
                                        Write-Log -Level ERROR -Message "[$clientPid] $($Config.General.MaxReconnectAttempts) sikertelen reconnect utan LEALLT"
                                    } else {
                                        $client.ReconnectAttempts++
                                        $client.IsRecovering = $true
                                        Queue-Input -TargetPid $clientPid -Type "RecoveryPassword" -Priority $script:InputPriority.Recovery | Out-Null
                                    }
                                }
                            }
                        }

                        "ClickBobber" {
                            $queued = Queue-Input -TargetPid $clientPid -Type "Bobber" -Priority $script:InputPriority.Bobber
                            if ($queued) {
                                $client.HookCount++
                                $client.NoBiteStreak = 0
                                $client.ReconnectAttempts = 0
                            }
                        }

                        "PostCatch" {
                            $client.Phase = "NeedCast"
                            $client.NextActionTime = $now
                        }

                        default {
                            Write-Log -Level WARNING -Message "[$clientPid] Ismeretlen fazis: $($client.Phase) - visszaallitas NeedCast-ra"
                            $client.Phase = "NeedCast"
                            $client.NextActionTime = $now
                        }
                    }
                }
            } catch {
                Write-LogException -Context "[$clientPid] Client tick" -ErrorRecord $_
                # Egy kliens hibaja ne allitsa le a tobbit - folytatjuk a kovetkezovel.
            }
        }

        # --- kozos harapas-lekerdezes az osszes varakozo kliensre egyszerre ---
        try {
            $awaitingPids = @($activePids | Where-Object {
                $c = $script:Clients[$_]
                (-not $c.NeedsManualHelp) -and $c.ProcessAlive -and $c.Phase -eq "AwaitingBite" -and $now -ge $c.NextActionTime -and $now -le $c.CastDeadline
            })
            if ($awaitingPids.Count -gt 0) {
                $peaks = Get-ClientAudioPeaks -Pids $awaitingPids
                $threshold = $Config.Audio.Sensitivity * 10
                foreach ($clientPid in $awaitingPids) {
                    if ($peaks.ContainsKey($clientPid) -and $peaks[$clientPid] -ge $threshold) {
                        $script:Clients[$clientPid].Phase = "ClickBobber"
                    }
                }
            }
        } catch {
            Write-LogException -Context "Audio poll" -ErrorRecord $_
        }

        # --- input queue feldolgozas: max 1 elem/tick ---
        try { Process-InputQueue } catch { Write-LogException -Context "Process-InputQueue" -ErrorRecord $_ }

        if ($Config.General.AutoStop -and
            (($now - $script:SessionStartTime).TotalMinutes -ge $Config.General.AutoStopMinutes)) {
            return "AUTOSTOP"
        }
        return "OK"
    } finally {
        $script:MonitorBusy = $false
    }
}

# ==============================================================================
# 16) GUI ENGINE
# ==============================================================================

function New-InfoLabel {
    param($Parent, [ref]$Y, [string]$Text, [int]$X = 15)
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $Text
    $lbl.AutoSize = $true
    $lbl.Location = New-Object System.Drawing.Point($X, $Y.Value)
    $lbl.Font = New-Object System.Drawing.Font("Consolas", 9)
    $Parent.Controls.Add($lbl)
    $Y.Value += 20
    return $lbl
}

function Build-MainForm {
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "AI-FishBot Monitor v2.1"
    $form.Size = New-Object System.Drawing.Size(1050, 820)
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedSingle"
    $form.MaximizeBox = $false

    $headerBox = New-Object System.Windows.Forms.GroupBox
    $headerBox.Text = "AI-FishBot Monitor v2.1"
    $headerBox.Location = New-Object System.Drawing.Point(10, 10)
    $headerBox.Size = New-Object System.Drawing.Size(1010, 70)
    $form.Controls.Add($headerBox)
    $y = [ref]20
    $lblRuntime = New-InfoLabel -Parent $headerBox -Y $y -Text "Runtime: 00:00:00"
    $lblClients = New-InfoLabel -Parent $headerBox -Y $y -Text "Clients: 0"
    $lblStatus  = New-InfoLabel -Parent $headerBox -Y $y -Text "Status: RUNNING"
    $lblQueue   = New-Object System.Windows.Forms.Label
    $lblQueue.Text = "Input Queue: 0 | Busy: NO"
    $lblQueue.AutoSize = $true
    $lblQueue.Location = New-Object System.Drawing.Point(300, 20)
    $lblQueue.Font = New-Object System.Drawing.Font("Consolas", 9)
    $headerBox.Controls.Add($lblQueue)

    $totalBox = New-Object System.Windows.Forms.GroupBox
    $totalBox.Text = "Total Statistics"
    $totalBox.Location = New-Object System.Drawing.Point(10, 90)
    $totalBox.Size = New-Object System.Drawing.Size(490, 170)
    $form.Controls.Add($totalBox)
    $y = [ref]20
    $lblTotalFish   = New-InfoLabel -Parent $totalBox -Y $y -Text "Total Fish: 0"
    $lblTotalWyrm   = New-InfoLabel -Parent $totalBox -Y $y -Text "Total Wyrmfish: 0"
    $lblFishPerHour = New-InfoLabel -Parent $totalBox -Y $y -Text "Fish/hour: 0"
    $lblWyrmPerHour = New-InfoLabel -Parent $totalBox -Y $y -Text "Wyrmfish/hour: 0"
    $lblGoldPerHour = New-InfoLabel -Parent $totalBox -Y $y -Text "Gold/hour: 0"
    $lblEurPerHour  = New-InfoLabel -Parent $totalBox -Y $y -Text "EUR/hour: 0"
    $lblHufPerHour  = New-InfoLabel -Parent $totalBox -Y $y -Text "HUF/hour: 0"

    $priceBox = New-Object System.Windows.Forms.GroupBox
    $priceBox.Text = "Wyrmfish / Price"
    $priceBox.Location = New-Object System.Drawing.Point(510, 90)
    $priceBox.Size = New-Object System.Drawing.Size(510, 170)
    $form.Controls.Add($priceBox)
    $y = [ref]20
    $lblPrice        = New-InfoLabel -Parent $priceBox -Y $y -Text "Price: -"
    $lblPriceSource  = New-InfoLabel -Parent $priceBox -Y $y -Text "Source: -  |  Online: -"
    $lblTotalValue   = New-InfoLabel -Parent $priceBox -Y $y -Text "Total value: -"
    $lblProj6h       = New-InfoLabel -Parent $priceBox -Y $y -Text "6h projection: -"
    $lblProj24h      = New-InfoLabel -Parent $priceBox -Y $y -Text "24h projection: -"
    $lblProj7d       = New-InfoLabel -Parent $priceBox -Y $y -Text "7d projection: -"
    $lblPriceUpdated = New-InfoLabel -Parent $priceBox -Y $y -Text "Last updated: -"

    $targetBox = New-Object System.Windows.Forms.GroupBox
    $targetBox.Text = "Target"
    $targetBox.Location = New-Object System.Drawing.Point(10, 270)
    $targetBox.Size = New-Object System.Drawing.Size(490, 150)
    $form.Controls.Add($targetBox)
    $y = [ref]20
    $lblTargetVal  = New-InfoLabel -Parent $targetBox -Y $y -Text ("TARGET: {0} Ft" -f $Config.Target.TargetHuf)
    $lblTargetCur  = New-InfoLabel -Parent $targetBox -Y $y -Text "CURRENT: 0 Ft"
    $lblTargetRem  = New-InfoLabel -Parent $targetBox -Y $y -Text "REMAINING: 0 Ft"
    $lblTargetNeed = New-InfoLabel -Parent $targetBox -Y $y -Text "NEEDED: 0 Wyrmfish"
    $lblTargetEta  = New-InfoLabel -Parent $targetBox -Y $y -Text "ETA: --"
    $targetBar = New-Object System.Windows.Forms.ProgressBar
    $targetBar.Location = New-Object System.Drawing.Point(15, $y.Value)
    $targetBar.Size = New-Object System.Drawing.Size(450, 20)
    $targetBar.Minimum = 0
    $targetBar.Maximum = 100
    $targetBox.Controls.Add($targetBar)

    $sessionBox = New-Object System.Windows.Forms.GroupBox
    $sessionBox.Text = "Session"
    $sessionBox.Location = New-Object System.Drawing.Point(510, 270)
    $sessionBox.Size = New-Object System.Drawing.Size(510, 150)
    $form.Controls.Add($sessionBox)
    $y = [ref]20
    $lblSessStart      = New-InfoLabel -Parent $sessionBox -Y $y -Text "Session start: -"
    $lblSessMonStart   = New-InfoLabel -Parent $sessionBox -Y $y -Text "Monitoring start: -"
    $lblSessActive     = New-InfoLabel -Parent $sessionBox -Y $y -Text "Active time: -"
    $lblSessPaused     = New-InfoLabel -Parent $sessionBox -Y $y -Text "Paused time: -"
    $lblSessReload     = New-InfoLabel -Parent $sessionBox -Y $y -Text "Reload/maintenance time: -"
    $lblSessUpdate     = New-InfoLabel -Parent $sessionBox -Y $y -Text "Last update: -"

    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.Location = New-Object System.Drawing.Point(10, 430)
    $grid.Size = New-Object System.Drawing.Size(1010, 220)
    $grid.ReadOnly = $true
    $grid.AllowUserToAddRows = $false
    $grid.AllowUserToDeleteRows = $false
    $grid.RowHeadersVisible = $false
    $grid.AutoSizeColumnsMode = "Fill"
    [void]$grid.Columns.Add("Client", "PID")
    [void]$grid.Columns.Add("Status", "Status")
    [void]$grid.Columns.Add("Reason", "Reason")
    [void]$grid.Columns.Add("Fish", "Fish")
    [void]$grid.Columns.Add("Wyrm", "Wyrmfish")
    [void]$grid.Columns.Add("FishHour", "Fish/h")
    [void]$grid.Columns.Add("WyrmHour", "Wyrm/h")
    [void]$grid.Columns.Add("RevenueHour", "HUF/h")
    [void]$grid.Columns.Add("ActiveTime", "Active time")
    [void]$grid.Columns.Add("LastActivity", "Last activity")
    [void]$grid.Columns.Add("InputPending", "Input")
    $form.Controls.Add($grid)

    $alertBox = New-Object System.Windows.Forms.GroupBox
    $alertBox.Text = "Alerts"
    $alertBox.Location = New-Object System.Drawing.Point(10, 660)
    $alertBox.Size = New-Object System.Drawing.Size(1010, 110)
    $form.Controls.Add($alertBox)
    $alertList = New-Object System.Windows.Forms.ListBox
    $alertList.Location = New-Object System.Drawing.Point(10, 20)
    $alertList.Size = New-Object System.Drawing.Size(990, 80)
    $alertList.Font = New-Object System.Drawing.Font("Consolas", 9)
    $alertBox.Controls.Add($alertList)

    $script:GuiControls = @{
        Form         = $form
        Runtime      = $lblRuntime
        Clients      = $lblClients
        Status       = $lblStatus
        Queue        = $lblQueue
        TotalFish    = $lblTotalFish
        TotalWyrm    = $lblTotalWyrm
        FishPerHour  = $lblFishPerHour
        WyrmPerHour  = $lblWyrmPerHour
        GoldPerHour  = $lblGoldPerHour
        EurPerHour   = $lblEurPerHour
        HufPerHour   = $lblHufPerHour
        Price        = $lblPrice
        PriceSource  = $lblPriceSource
        TotalValue   = $lblTotalValue
        Proj6h       = $lblProj6h
        Proj24h      = $lblProj24h
        Proj7d       = $lblProj7d
        PriceUpdated = $lblPriceUpdated
        TargetVal    = $lblTargetVal
        TargetCur    = $lblTargetCur
        TargetRem    = $lblTargetRem
        TargetNeed   = $lblTargetNeed
        TargetEta    = $lblTargetEta
        TargetBar    = $targetBar
        SessStart    = $lblSessStart
        SessMonStart = $lblSessMonStart
        SessActive   = $lblSessActive
        SessPaused   = $lblSessPaused
        SessReload   = $lblSessReload
        SessUpdate   = $lblSessUpdate
        Grid         = $grid
        AlertList    = $alertList
    }
    $script:GridRowMap = @{}

    return $form
}

function Format-Huf {
    param([double]$Value)
    return "{0:N0} Ft" -f $Value
}

function Format-Duration {
    param([double]$TotalSeconds)
    $ts = [TimeSpan]::FromSeconds([Math]::Max($TotalSeconds, 0))
    return "{0:D2}:{1:D2}:{2:D2}" -f [int]$ts.TotalHours, $ts.Minutes, $ts.Seconds
}

function Update-ClientGridRow {
    param($Grid, [uint32]$TargetPid, [object[]]$Values, [string]$Status)

    if ($script:GridRowMap.ContainsKey($TargetPid)) {
        $rowIdx = $script:GridRowMap[$TargetPid]
        if ($rowIdx -lt $Grid.Rows.Count) {
            for ($i = 0; $i -lt $Values.Count; $i++) {
                $Grid.Rows[$rowIdx].Cells[$i].Value = $Values[$i]
            }
        } else {
            $rowIdx = $Grid.Rows.Add($Values)
            $script:GridRowMap[$TargetPid] = $rowIdx
        }
    } else {
        $rowIdx = $Grid.Rows.Add($Values)
        $script:GridRowMap[$TargetPid] = $rowIdx
    }

    $color = switch ($Status) {
        "ERROR"   { [System.Drawing.Color]::MistyRose }
        "WARNING" { [System.Drawing.Color]::LightYellow }
        "MANUAL"  { [System.Drawing.Color]::LightGray }
        default   { [System.Drawing.Color]::White }
    }
    $Grid.Rows[$rowIdx].DefaultCellStyle.BackColor = $color
}

$script:TargetReachedNotified = $false
$script:GuiBusy = $false

function Invoke-GuiRefresh {
    if ($script:GuiBusy) { return }
    $script:GuiBusy = $true

    try {
        $now = Get-Date
        $gui = $script:GuiControls

        try { Update-WyrmfishPrice -Now $now } catch { Write-LogException -Context "Update-WyrmfishPrice" -ErrorRecord $_ }

        $totalFish = 0
        $totalWyrm = 0
        $totalActiveHours = 0.0
        $fishPerHourValues = @()

        foreach ($client in $script:Clients.Values) {
            $m = Get-ClientMetrics -Client $client
            $fishPerHourValues += $m.FishPerHour
        }
        $avgFishPerHour = if ($fishPerHourValues.Count -gt 0) { ($fishPerHourValues | Measure-Object -Average).Average } else { 0 }

        foreach ($client in $script:Clients.Values) {
            try { Test-ClientAnomalies -Client $client -Now $now -AvgFishPerHour $avgFishPerHour }
            catch { Write-LogException -Context "[$($client.PID)] Test-ClientAnomalies" -ErrorRecord $_ }

            $totalFish += $client.HookCount
            $totalActiveHours += ($client.ActiveTimeSeconds / 3600.0)
            if ($client.FishCounts.ContainsKey($Config.Loot.HighlightFishName)) {
                $totalWyrm += $client.FishCounts[$Config.Loot.HighlightFishName]
            }
        }

        $totalRevenue = Get-RevenueStats -TotalWyrmfish $totalWyrm -ActiveHours $totalActiveHours
        $target = Get-TargetProgress -Revenue $totalRevenue

        if ($target.ProgressPct -ge 100 -and -not $script:TargetReachedNotified) {
            Send-TargetReachedEvent
            $script:TargetReachedNotified = $true
        }

        $gui.Runtime.Text = "Runtime: " + (Format-Duration -TotalSeconds ($now - $script:SessionStartTime).TotalSeconds)
        $gui.Clients.Text = "Clients: $($script:Clients.Count)"
        $gui.Status.Text  = "Status: RUNNING"
        $gui.Queue.Text   = "Input Queue: $($script:InputQueue.Count) | Busy: " + $(if ($script:InputBusy) { "YES" } else { "NO" })

        $totalFishPerHour = if ($totalActiveHours -gt 0) { $totalFish / $totalActiveHours } else { 0 }
        $totalWyrmPerHour = if ($totalActiveHours -gt 0) { $totalWyrm / $totalActiveHours } else { 0 }
        $gui.TotalFish.Text   = "Total Fish: $totalFish"
        $gui.TotalWyrm.Text   = "Total Wyrmfish: $totalWyrm"
        $gui.FishPerHour.Text = "Fish/hour: {0:N1}" -f (ConvertTo-SafeNumber $totalFishPerHour)
        $gui.WyrmPerHour.Text = "Wyrmfish/hour: {0:N1}" -f (ConvertTo-SafeNumber $totalWyrmPerHour)
        $gui.GoldPerHour.Text = "Gold/hour: {0:N1}" -f $totalRevenue.GoldPerHour
        $gui.EurPerHour.Text  = "EUR/hour: {0:N2}" -f $totalRevenue.EurPerHour
        $gui.HufPerHour.Text  = "HUF/hour: " + (Format-Huf $totalRevenue.HufPerHour)

        $gui.Price.Text        = "Price: {0:N2} gold/db" -f $script:PriceCache.Price
        $gui.PriceSource.Text  = "Source: $($script:PriceCache.Source)  |  Online: " + $(if ($script:PriceCache.Online) { "YES" } else { "NO" })
        $gui.TotalValue.Text   = "Total value: " + (Format-Huf $totalRevenue.HufTotal)
        $gui.Proj6h.Text       = "6h projection: " + (Format-Huf $totalRevenue.Projection6h)
        $gui.Proj24h.Text      = "24h projection: " + (Format-Huf $totalRevenue.Projection24h)
        $gui.Proj7d.Text       = "7d projection: " + (Format-Huf $totalRevenue.Projection7d)
        $gui.PriceUpdated.Text = "Last updated: " + $(if ($script:PriceCache.LastUpdated) { $script:PriceCache.LastUpdated.ToString("HH:mm:ss") } else { "-" })

        $gui.TargetVal.Text  = "TARGET: " + (Format-Huf $target.Target)
        $gui.TargetCur.Text  = "CURRENT: " + (Format-Huf $target.Current)
        $gui.TargetRem.Text  = "REMAINING: " + (Format-Huf $target.Remaining)
        $gui.TargetNeed.Text = "NEEDED: $($target.NeededWyrmfish) Wyrmfish"
        $gui.TargetEta.Text  = "ETA: " + $(if ($target.HasEta) { Format-Duration -TotalSeconds ($target.EtaHours * 3600) } else { "--" })
        $gui.TargetBar.Value = [Math]::Max(0, [Math]::Min(100, [int]$target.ProgressPct))

        $totalPaused = (($script:Clients.Values | ForEach-Object { $_.PausedTimeSeconds }) | Measure-Object -Sum).Sum
        $totalReload = (($script:Clients.Values | ForEach-Object { $_.ReloadTimeSeconds }) | Measure-Object -Sum).Sum
        $gui.SessStart.Text    = "Session start: " + $script:SessionStartTime.ToString("yyyy-MM-dd HH:mm:ss")
        $gui.SessMonStart.Text = "Monitoring start: " + $(if ($script:MonitoringStartTime) { $script:MonitoringStartTime.ToString("yyyy-MM-dd HH:mm:ss") } else { "-" })
        $gui.SessActive.Text   = "Active time: " + (Format-Duration -TotalSeconds ($totalActiveHours * 3600))
        $gui.SessPaused.Text   = "Paused time: " + (Format-Duration -TotalSeconds $totalPaused)
        $gui.SessReload.Text   = "Reload/maintenance time: " + (Format-Duration -TotalSeconds $totalReload)
        $gui.SessUpdate.Text   = "Last update: " + $now.ToString("HH:mm:ss")

        foreach ($clientPid in ($script:Clients.Keys | Sort-Object)) {
            $client = $script:Clients[$clientPid]
            $m = Get-ClientMetrics -Client $client
            $rev = Get-RevenueStats -TotalWyrmfish $m.WyrmfishCount -ActiveHours $m.ActiveHours

            $pendingInput = "-"
            $pendingItem = $script:InputQueue | Where-Object { $_.PID -eq $clientPid } | Select-Object -First 1
            if ($pendingItem) { $pendingInput = "$($pendingItem.Type) pending" }

            $lastActivityStr = if ($client.LastActivity) { $client.LastActivity.ToString("HH:mm:ss") } else { "-" }

            Update-ClientGridRow -Grid $gui.Grid -TargetPid $clientPid -Status $client.Status -Values @(
                $clientPid,
                $client.Status,
                $client.StatusReason,
                $client.HookCount,
                $m.WyrmfishCount,
                ("{0:N1}" -f $m.FishPerHour),
                ("{0:N1}" -f $m.WyrmfishPerHour),
                ("{0:N0}" -f $rev.HufPerHour),
                (Format-Duration -TotalSeconds $client.ActiveTimeSeconds),
                $lastActivityStr,
                $pendingInput
            )
        }

        $gui.AlertList.Items.Clear()
        $recentAlerts = $script:Alerts | Select-Object -Last $Config.Gui.AlertDisplayCount
        foreach ($alert in $recentAlerts) {
            [void]$gui.AlertList.Items.Add(("{0:HH:mm:ss} [{1}] [{2}] {3}" -f $alert.Timestamp, $alert.Severity, $alert.PID, $alert.Reason))
        }

        if (($now - $script:LastReportTime).TotalSeconds -ge $Config.Gui.ReportIntervalSeconds) {
            Add-ReportSnapshot -Now $now
            $script:LastReportTime = $now
        }
    } catch {
        Write-LogException -Context "Invoke-GuiRefresh" -ErrorRecord $_
    } finally {
        $script:GuiBusy = $false
    }
}

# ==============================================================================
# CONFIG VALIDATION
# ==============================================================================

function Test-Configuration {
    $errors = New-Object System.Collections.Generic.List[string]

    if ($Config.Gui.MonitorIntervalMs -lt 20) { $errors.Add("Gui.MonitorIntervalMs tul alacsony (min 20ms)") }
    if ($Config.Gui.RefreshIntervalMs -lt $Config.Gui.MonitorIntervalMs) { $errors.Add("Gui.RefreshIntervalMs nem lehet kisebb, mint MonitorIntervalMs") }
    if ($Config.General.NoBiteStreakLimit -lt 1) { $errors.Add("General.NoBiteStreakLimit legalabb 1 legyen") }
    if ($Config.General.MaxReconnectAttempts -lt 0) { $errors.Add("General.MaxReconnectAttempts nem lehet negativ") }
    if ($Config.Price.FallbackPrice -le 0) { $errors.Add("Price.FallbackPrice legyen pozitiv") }
    if ($Config.Target.TargetHuf -lt 0) { $errors.Add("Target.TargetHuf nem lehet negativ") }
    if ($Config.Revenue.GoldPerEuro -le 0) { $errors.Add("Revenue.GoldPerEuro legyen pozitiv") }
    if ($Config.Revenue.EurToHuf -le 0) { $errors.Add("Revenue.EurToHuf legyen pozitiv") }
    if ($Config.Gui.ReportIntervalSeconds -lt 5) { $errors.Add("Gui.ReportIntervalSeconds tul alacsony (min 5s)") }
    if ($Config.Client.UsePi -and -not $Config.Client.PicoComPort) { $errors.Add("Client.UsePi be van kapcsolva, de nincs PicoComPort") }
    if ($Config.Notification.Enabled -and -not $Config.Notification.DiscordWebhook) {
        Write-Log -Level WARNING -Message "Notification.Enabled=true, de nincs AIFISHBOT_DISCORD_WEBHOOK - a Discord ertesitesek nem fognak menni."
    }
    foreach ($idx in $Config.Client.BuffsEnabled) {
        $b = $Config.Client.Buffs[$idx]
        if (-not $b) { $errors.Add("BuffsEnabled hivatkozik egy nem letezo buff ID-re: $idx") ; continue }
        if (-not $b.Keybind) { $errors.Add("Buff #$idx : hianyzo Keybind") }
        if ($b.CastTimeSeconds -lt 0) { $errors.Add("Buff #$idx : negativ CastTimeSeconds") }
        if ($b.DurationMinutes -le 0) { $errors.Add("Buff #$idx : DurationMinutes legyen pozitiv") }
    }

    if ($errors.Count -gt 0) {
        $msg = "Konfiguracios hiba(k):`n" + ($errors -join "`n")
        Write-Log -Level ERROR -Message $msg
        [System.Windows.Forms.MessageBox]::Show($msg, "AI-FishBot Monitor v2.1 - Config hiba", "OK", "Error") | Out-Null
        return $false
    }
    return $true
}

# ==============================================================================
# CLEAN SHUTDOWN
# ==============================================================================

$script:MonitorStopped = $false

function Stop-Monitor {
    if ($script:MonitorStopped) { return }
    $script:MonitorStopped = $true

    try { $monitorTimer.Stop() } catch { }
    try { $guiTimer.Stop() } catch { }

    try {
        if ($script:PicoPort -and $script:PicoPort.IsOpen) { $script:PicoPort.Close() }
    } catch { Write-LogException -Context "SerialPort close" -ErrorRecord $_ }

    $summaryText = "Total Fish: - | Total Wyrmfish: - | Revenue: -"
    try {
        Add-ReportSnapshot -Now (Get-Date)
    } catch { Write-LogException -Context "Zaro report snapshot" -ErrorRecord $_ }

    try {
        $summary = Export-SessionJsonSummary
        $summaryText = "Total Fish: $($summary.TotalFish) | Total Wyrmfish: $($summary.TotalWyrmfish) | Revenue: $($summary.RevenueHuf) Ft"
    } catch { Write-LogException -Context "Zaro JSON export" -ErrorRecord $_ }

    try { Send-SessionStoppedEvent -Summary $summaryText } catch { Write-LogException -Context "Session stopped notification" -ErrorRecord $_ }

    Write-Log -Level INFO -Message "Monitor leallitva. $summaryText"
}

# ==============================================================================
# 17) ENTRY POINT
# ==============================================================================

if (-not (Test-Configuration)) { Exit 1 }

Ensure-NAudio

if ($Config.Client.UsePi) {
    try {
        $script:PicoPort = New-Object System.IO.Ports.SerialPort $Config.Client.PicoComPort, 115200, None, 8, one
        $script:PicoPort.Open()
    } catch {
        Write-LogException -Context "Pi csatlakozas" -ErrorRecord $_
        [System.Windows.Forms.MessageBox]::Show("Pi csatlakozas sikertelen: $($_.Exception.Message)", "AI-FishBot Monitor v2.1", "OK", "Error") | Out-Null
        Exit 1
    }
}

$selectedPids = Show-ClientSelectorDialog
if ($selectedPids.Count -eq 0) {
    Write-Log -Level INFO -Message "Nincs kivalasztott kliens - kilepes."
    Exit 0
}

foreach ($clientPid in $selectedPids) {
    $script:Clients[$clientPid] = New-ClientState -WowPid $clientPid
}

if ($Config.Loot.Enabled) {
    foreach ($clientPid in $selectedPids) {
        Reset-ClientLootTracker -WowPid $clientPid
    }
}

Write-Log -Level INFO -Message "Session inditva: $script:SessionId, $($script:Clients.Count) kliens"
Send-SessionStartedEvent

$script:MonitoringStartTime = Get-Date

$mainForm = Build-MainForm

$monitorTimer = New-Object System.Windows.Forms.Timer
$monitorTimer.Interval = $Config.Gui.MonitorIntervalMs
$monitorTimer.Add_Tick({
    try {
        $result = Invoke-MonitorTick
        if ($result -eq "AUTOSTOP") {
            Write-Log -Level INFO -Message "AutoStop ido elerve."
            $mainForm.Close()
        }
    } catch {
        Write-LogException -Context "MonitorTimer.Tick" -ErrorRecord $_
    }
})

$guiTimer = New-Object System.Windows.Forms.Timer
$guiTimer.Interval = $Config.Gui.RefreshIntervalMs
$guiTimer.Add_Tick({
    try { Invoke-GuiRefresh }
    catch { Write-LogException -Context "GuiTimer.Tick" -ErrorRecord $_ }
})

$mainForm.Add_FormClosing({ Stop-Monitor })

$monitorTimer.Start()
$guiTimer.Start()

[System.Windows.Forms.Application]::Run($mainForm)

<#
================================================================================
 CHANGELOG (v2 -> v2.1)
================================================================================

JAVÍTVA
- NAudio.Core/Wasapi betöltés: fust-teszt hozzáadva induláskor, hogy korán,
  érthető hibával bukjon el, ne az első valódi poll-nál.
- Get-ClientAudioPeaks: session-enkénti try/catch, egy hibás session többé nem
  akaszthatja meg a teljes hangfigyelést.
- Test-ClientProcess: központi, mindenhonnan ezt hívja a kód (korábban szórt
  Get-Process hívások voltak Anomaly Detectorban és a monitorban).
- CSV/JSON export minden lépése saját try/catch-csel - egy hiba nem akadályozza
  meg a többi mentését, session zárásnál mindig próbálkozik.
- Discord webhook: -TimeoutSec hozzáadva, hiba esetén csak logol, sosem dob
  tovább kivételt.
- Loot parser: kezeli az üres/nemlétező/zárolt fájlt, csak az AIFishLootDB
  blokkon belül keres (nem fog meg véletlenül más Lua táblát), és sikertelen
  parse esetén NEM írja felül a korábbi adatot.
- Reconnect state machine: NoBiteStreak és ReconnectAttempts most már
  garantáltan resetelődik sikeres fogásnál; NeedsManualHelp után egyetlen
  input sem mehet ki a kliensnek (Queue-Input maga is elutasítja).
- Jelszó soha nem kerül logba (a Recovery-típusú input logsorok "[REDACTED]"-et
  írnak ki payload helyett); üres jelszónál a recovery azonnal ERROR/manual-help
  állapotba tesz, nem próbálkozik értelmetlen inputtal.

OPTIMALIZÁLVA
- A régi blokkoló minták (Start-Sleep a state machine-ben, buff 10x1mp-es
  ciklusa, weakAura retry while+Sleep) mind eltűntek - minden input a Queue-n
  megy át, a monitor tick sosem vár SendKeys-re hosszabb ideig, mint egy
  fókusz-váltás (kb. 60ms).
- DataGridView: nem törli és építi újra a sorokat minden frissítésnél -
  helyben frissíti a meglévő sorok celláit (Update-ClientGridRow).
- $script:MonitorBusy / $script:GuiBusy / $script:InputBusy őrök: egy tick
  nem tud saját magába belépni, még akkor sem, ha valamiért elhúzódna.
- Idő-akkumulátor delta maximum 5 másodpercre korlátozva, hogy egy hosszabb
  UI-akadás ne adjon hozzá irreális aktív időt.
- Összesített fish/hour és Wyrmfish/hour a teljes (fish/aktív-óra) hányadosból
  számolódik, nem a kliensenkénti ráták átlagából.

ÚJ VÉDELEM
- Test-Configuration: induláskor ellenőrzi az intervallumokat, buff configot,
  price/target/revenue beállításokat - hibás config esetén érthető
  hibaüzenettel, tisztán leáll, mielőtt bármi elindulna.
- Stop-Monitor: központi, idempotens leállító függvény (timers, serial port,
  riport mentés, Discord értesítés) - a FormClosing csak ezt hívja.
- ConvertTo-SafeNumber: minden revenue/target számítás védett NaN/Infinity
  ellen.
- Alert lista maximum 200 elemre korlátozva (Config.Gui.AlertHistoryLimit),
  a GUI az utolsó 20-at mutatja.
- Anomaly Detector: állapotátmenet-alapú (OK->WARNING, ->ERROR/MANUAL),
  helyreállásnál új figyelmeztetés újra kiküldhető - nincs folyamatos spam.
- Price Engine: Source most "FALLBACK" vagy "PROVIDER" (nem csak "OFFLINE"
  szöveg), külön Online true/false mező is van hozzá.

INPUT QUEUE
- Központi $script:InputQueue + Queue-Input / Process-InputQueue /
  Invoke-InputAction / Complete-Input függvények - MINDEN SendKeys-hívás
  ezen megy át, nincs többé szórt Focus-Client+SendKeys a kódban.
- Duplikációvédelem: $script:PendingInputKeys (kulcs: "PID|Type") - amíg egy
  adott kliensnek adott típusú inputja fut/vár, nem kerül be újabb ugyanolyan.
- Prioritás: Recovery(0) > Bobber(1) > Cast(2) > Buff(3) > Maintenance(4,
  Reload/ChatCommand/Logout) - Sort-Object Priority, CreatedAt dönti el a
  sorrendet.
- Retry: RetryCount mezővel, max 3 próbálkozás (script:MaxInputRetries),
  NINCS retry-loop - a queue elem egyszerűen a queue-ban marad a következő
  tickig.
- Process-InputQueue egy hívásban LEGFELJEBB EGY elemet dolgoz fel, hogy egy
  tick soha ne blokkoljon SendKeys-halmozódás miatt.
- GUI-ban látható: "Input Queue: N | Busy: YES/NO" a fejlécben, és
  kliensenként az "Input" oszlopban (pl. "Cast pending").

ELLENŐRZÖTT KOMPATIBILITÁS
- Windows PowerShell 5.1 (ComObject wscript.shell, System.Windows.Forms,
  System.Drawing, [ref] paraméterek, hashtable-alapú állapotkezelés - nincs
  PS 5.1-ben hiányzó nyelvi elem, pl. nincs osztály/enum használva).
- WinForms: két System.Windows.Forms.Timer, DataGridView in-place frissítés,
  FormClosing -> Stop-Monitor.
- NAudio 2.2.1 (NAudio.Core + NAudio.Wasapi), induláskori fust-teszttel.
================================================================================
#>