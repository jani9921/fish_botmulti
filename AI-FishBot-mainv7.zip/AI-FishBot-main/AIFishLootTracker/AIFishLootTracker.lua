-- AI Fish Loot Tracker
-- Zsakmanyolt targyakat szamolja nev szerint, es SavedVariables-be irja.
-- FONTOS: a SavedVariables fajl a WTF\Account\<Account>\SavedVariables\AIFishLootTracker.lua
-- utvonalra iratik ki, de csak /reload vagy logout/kilepes alkalmaval - ezert a
-- PowerShell bot idoszakosan kuld egy /reload parancsot, hogy friss adatot kapjon.

AIFishLootDB = AIFishLootDB or {}

local function HandleLootMessage(msg)
    -- A |h[Nev]|h resz az itemlink megjelenitett neve - ez a jatek nyelvetol
    -- fuggetlenul mukodik, nem kell angol "You receive loot:" szoveget keresni.
    for itemName in msg:gmatch("|h%[(.-)%]|h") do
        AIFishLootDB[itemName] = (AIFishLootDB[itemName] or 0) + 1
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("CHAT_MSG_LOOT")
frame:SetScript("OnEvent", function(self, event, msg)
    if event == "CHAT_MSG_LOOT" then
        HandleLootMessage(msg)
    end
end)

SLASH_AIFISHLOOT1 = "/aifishloot"
SlashCmdList["AIFISHLOOT"] = function(cmd)
    if cmd == "reset" then
        wipe(AIFishLootDB)
        print("AI-Fishbot: zsakmany szamlalo torolve.")
        return
    end

    print("AI-Fishbot zsakmany szamlalo:")
    local any = false
    for name, count in pairs(AIFishLootDB) do
        any = true
        print(("  %s x%d"):format(name, count))
    end
    if not any then
        print("  (meg nincs semmi rogzitve)")
    end
end
