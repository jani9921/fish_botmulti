# V3 élő acceptance tesztek

Ezek a próbák valódi WoW környezetet igényelnek, ezért az automatizált build nem futtatja őket.

## Egy kliens

1. Indítsd el a publish EXE-t és egy WoW klienst azonos jogosultsági szinten.
2. Kösd a profilt a folyamathoz, nyomj Startot, és ellenőrizd a cast, buff, kapáshang és bobber gomb működését.
3. Ellenőrizd a Diagnosztika lapon az utolsó inputot; hiba esetén annak pontos Win32 oka és a logbejegyzés jelenjen meg.
4. Fogás után ellenőrizd az addon számlálót, az LKG statisztikát, a CSV catch journalt és a session riportot.
5. Pause/Stop után ne érkezzen új fishing input; új Start új sessiont hozzon létre.

## Reconnect

1. Ments DPAPI-val profiljelszót, engedélyezd az automatikus jelszóbeírást és hagyd a no-bite fallbacket kikapcsolva.
2. Valódi hálózati disconnect után a confirm idő lejártáig ne történjen input.
3. Ezután pontosan ez történjen: `Enter → Ctrl+A → jelszó → Enter → 30 s → Enter`.
4. A sorrend ne álljon le akkor sem, ha a TCP kapcsolat a közepén már established; siker után várja meg a stabilizálási időt és folytassa a horgászatot.
5. Telemetriahiba vagy hiányzó jelszó esetén ne gépeljen vakon, hanem álljon `TelemetryPaused` vagy `ManualIntervention` állapotba.
6. Több kliens egyidejű disconnectjénél csak egy használja az inputot, a többi várjon slotra.

## Nyolc kliens és tartósság

1. Hozz létre 8 külön ProfileId-jű profilt külön jelszóval, SavedVariables útvonallal és WoW folyamattal.
2. Ellenőrizd, hogy egyik kliens input/recovery queue-ja sem blokkolja vagy célozza a másikat.
3. Indíts újra egy WoW folyamatot és kösd új PID-hez; a profil titka, targetje és statisztikája maradjon változatlan.
4. Indítsd újra az appot; a profilok, advanced beállítások és egyszer már jelzett target állapota maradjon konzisztens.
5. Zárold vagy írd részlegesen a SavedVariables fájlt; a GUI tartsa meg az utolsó érvényes snapshotot és jelezzen hibát.

## Blizzard árazás

1. Érvényes API kulccsal ellenőrizd a realm feloldást, AH frissítést, cache-t és history-t.
2. API-hiba esetén a kézi ár, majd a konfigurált fallback legyen használható; titok ne jelenjen meg logban.
3. Elegendő history minta után ellenőrizd a percentile/confidence alapú eladási tanácsot.
