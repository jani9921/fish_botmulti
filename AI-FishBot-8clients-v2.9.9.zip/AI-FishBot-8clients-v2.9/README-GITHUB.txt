AI-FishBot V3 - GitHub csomag

Inditas:
  publish-github\AI-FishBot.App.exe

Kovetelmeny:
  Windows x64 es .NET 10 Desktop Runtime.

A csomag a teljes forraskodot, solutiont, teszteket, dokumentaciot,
az AIFishLootTracker addont es a framework-dependent kiadast tartalmazza.

A nagy self-contained publish a 25 MB-os csomagmeret miatt nincs benne.
BootyBayBroker es Discord integracio a projekt scope-ja szerint nincs benne.
