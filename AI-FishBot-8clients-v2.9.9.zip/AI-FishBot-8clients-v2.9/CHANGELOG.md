# Changelog

## V3.0.0

- .NET 10 WPF/MVVM, Generic Host és rétegezett, legfeljebb 8 klienses architektúra.
- `ProfileId` alapú profil- és statisztikakezelés, PID csak runtime binding.
- Kliensenkénti prioritásos/deduplikált input worker, fishing, buff, WeakAura retry és NAudio kapásfigyelés.
- Javított 64 bites Win32 `INPUT` ABI és megbízhatóbb ablakfókusz; inputhiba-diagnosztika.
- A közvetlen F6/F7/buff input előtt a kötött WoW ablak fókusza kötelező, így a Start gomb után nem a FishBot kapja a billentyűt.
- Az ablak nélküli `WowVoiceProxy` többé nem köthető kliensként; az input a PID alapján újra feloldja az időközben létrejött látható WoW-ablakot.
- A V2.9-cel egyezően minden queue-input PID-alapú `AppActivate` fókuszt kap, a Bobber pedig megelőzi a Cast/Buff/Maintenance parancsokat.
- A fókuszátadás a V2 pontos `WScript.Shell.AppActivate` COM-hívását használja, háromszor ellenőrzi a foreground PID-t, és csak igazolt fókusz után küld billentyűt.
- A WoW látható előtérbe hozását `SwitchToThisWindow` és rövid TOPMOST Z-sorrend-emelés biztosítja; Cast és Bobber fókusz külön naplózott.
- A profil-queue-k közös, globális input execution gate-et használnak, így több WoW worker nem válthat fókuszt egy másik kliens billentyűküldése közben.
- TCP-alapú recovery, backoff és schema 4 reconnect terv: `Enter → Ctrl+A → password → Enter → 30 s → Enter`.
- DPAPI profiljelszó és Blizzard credentials, secret-redacted logolás.
- Lua SavedVariables parser, biztonságos útvonal-felderítés, Last Known Good és loot reload/sync.
- Session/lifetime statisztika, revenue, target, anomaly alert, CSV/JSON riport.
- A fő klienslistában PID/profil soronként látható a session-alapú `Gold/óra` és a 12 órás gold-projekció.
- Blizzard OAuth/Auction House ár, cache/history és sell advice.
- Atomikus settings + backup recovery, V2 migráció és advanced Settings GUI.
- Kibővített unit tesztek input ABI-ra, queue-ra, Lua/LKG-ra, izolációra, controllerre, targetre, settings recoveryre, migrációra, DPAPI-ra és SavedVariables felderítésre.
- BootyBayBroker és Discord a felhasználói döntés szerint kihagyva.
