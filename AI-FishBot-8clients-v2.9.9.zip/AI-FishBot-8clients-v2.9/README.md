# AI-FishBot V3

.NET 10/WPF alapú, legfeljebb nyolc WoW-klienst kezelő alkalmazás. A tartós kliensazonosító a `ProfileId`; a PID csak futásidejű kötés, ezért egy WoW-újraindítás nem keverheti össze a profilok jelszavát, targetjét vagy statisztikáját.

## Indítás az elkészült kiadásból

Indítsd a `publish/AI-FishBot.App.exe` fájlt. A teljes `publish` mappát tartsd együtt; az EXE self-contained Windows x64 kiadás, ezért a célgépen nem igényel külön .NET runtime-ot. A közvetlen billentyűinput mindig a profilhoz kötött WoW ablakot aktiválja. Ha a WoW rendszergazdaként fut, az inputhoz a botot is azonos jogosultsági szinten kell indítani.

Az alkalmazás adatai itt készülnek:

- beállítás: `%APPDATA%\AI-FishBot\settings.json` (`.bak` biztonsági mentéssel);
- log: `%APPDATA%\AI-FishBot\logs`;
- riportok és catch journal: `%APPDATA%\AI-FishBot` alatti riportkönyvtárak;
- Blizzard cache és ártörténet: ugyanebben az alkalmazás-adatkönyvtárban.

## Első beállítás

1. Másold a kiadásban található `AIFishLootTracker` mappát a WoW megfelelő `Interface\AddOns` könyvtárába, majd engedélyezd az addont.
2. Hozz létre profilt, állítsd be a cast/hook/exit gombokat, és kösd az egyetlen megfelelő futó WoW folyamathoz.
3. A SavedVariables automatikus felismeréséhez töltsd ki az account- és character-azonosítót. Több találatnál a program szándékosan nem választ találomra.
4. Automatikus reconnecthez ments profiljelszót, és jelöld be az `Automatikus jelszóbeírás` lehetőséget.
5. A reconnect alapértelmezett sorrendje: `Enter`, `Ctrl+A`, jelszó, `Enter`, 30 másodperc várakozás, `Enter`.
6. Blizzard AH árakhoz add meg a régiót, realmet, opcionális Connected Realm ID-t és a Blizzard Client ID/Secret párost. A titkok Windows DPAPI CurrentUser védelemmel tárolódnak.

## Fő funkciók

- kliensenkénti prioritásos, deduplikált input queue és fishing/buff state machine;
- NAudio WASAPI folyamatonkénti kapásfigyelés;
- TCP-alapú disconnect felismerés, soros reconnect és backoff;
- Lua SavedVariables parser, részleges írás elleni Last Known Good állapot és automatikus loot sync;
- session/lifetime statisztika, gold/EUR/HUF bevétel, target és helyi riasztások;
- Blizzard OAuth/Auction House API, cache, history és eladási tanács;
- atomikus JSON-beállítás, CSV/JSON riport, V2 beállításmigráció;
- diagnosztika az utolsó inputtal és pontos Win32 hibával.

BootyBayBroker árazás/import/export és Discord integráció a felhasználói döntés szerint nincs a V3-ban.

## Fejlesztői ellenőrzés

```powershell
dotnet build AI-FishBot.sln -c Release
dotnet test AI-FishBot.sln -c Release --no-build
dotnet publish src/AI-FishBot.App/AI-FishBot.App.csproj -c Release -r win-x64 --self-contained true -o publish
```

Az automatizált teszt nem indítja el a WPF alkalmazást és nem küld valódi billentyűleütést. Az élő WoW-próbák listája az `ACCEPTANCE-TESTS.md` fájlban található.
