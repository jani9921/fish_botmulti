-- AI Fish Loot Tracker v1.3
-- A lootablakot es a loot chatet is figyeli. A ket forras kozotti rovid ideju
-- deduplikacio megakadalyozza, hogy ugyanazt a halat ketszer szamolja.

local ADDON_VERSION = "1.3"

AIFishLootDB = AIFishLootDB or {}
AIFishLootMeta = AIFishLootMeta or {}
AIFishLootMeta.version = ADDON_VERSION
AIFishLootMeta.sourceCounts = AIFishLootMeta.sourceCounts or {}
AIFishLootMeta.itemIds = AIFishLootMeta.itemIds or {}
AIFishLootMeta.duplicateSuppressed = AIFishLootMeta.duplicateSuppressed or 0

local recentByName = {}
local lootSessionActive = false
local lootSessionStarted = 0
local seenLootSlots = {}

local function Now()
    if GetTime then return GetTime() end
    return 0
end

local function NormalizeQuantity(quantity)
    quantity = tonumber(quantity) or 1
    quantity = math.floor(quantity)
    if quantity < 1 then quantity = 1 end
    return quantity
end

local function AddLoot(itemName, quantity, source, itemId)
    if not itemName or itemName == "" then return end
    quantity = NormalizeQuantity(quantity)
    source = source or "UNKNOWN"
    itemId = tonumber(itemId)
    if itemId and itemId > 0 then
        AIFishLootMeta.itemIds[itemName] = math.floor(itemId)
    end

    local now = Now()
    local pending = quantity
    local recent = recentByName[itemName]

    -- A LOOT_OPENED/LOOT_READY es a CHAT_MSG_LOOT ugyanazt az itemet is
    -- jelentheti. A masik forrasbol 3 masodpercen belul erkezo mennyiseget
    -- egymas ellen elszamoljuk, igy csak egyszer kerul az adatbazisba.
    if recent and recent.source ~= source and (now - recent.at) <= 3 then
        local matched = math.min(recent.quantity, pending)
        recent.quantity = recent.quantity - matched
        pending = pending - matched
        AIFishLootMeta.duplicateSuppressed = AIFishLootMeta.duplicateSuppressed + matched
        if recent.quantity <= 0 then recentByName[itemName] = nil end
    end

    if pending <= 0 then return end

    AIFishLootDB[itemName] = (AIFishLootDB[itemName] or 0) + pending
    AIFishLootMeta.totalRecorded = (AIFishLootMeta.totalRecorded or 0) + pending
    AIFishLootMeta.lastItem = itemName
    AIFishLootMeta.lastQuantity = pending
    AIFishLootMeta.lastSource = source
    AIFishLootMeta.lastSeen = time and time() or 0
    AIFishLootMeta.sourceCounts[source] = (AIFishLootMeta.sourceCounts[source] or 0) + pending

    local current = recentByName[itemName]
    if current and current.source == source and (now - current.at) <= 3 then
        current.quantity = current.quantity + pending
        current.at = now
    else
        recentByName[itemName] = { source = source, quantity = pending, at = now }
    end
end

local function HandleLootMessage(msg)
    if not msg or msg == "" then return end

    local foundLink = false
    local searchFrom = 1
    while true do
        local linkStart, linkEnd, itemName = msg:find("|h%[(.-)%]|h", searchFrom)
        if not linkStart then break end
        foundLink = true

        local nextLink = msg:find("|h%[", linkEnd + 1)
        local suffix = msg:sub(linkEnd + 1, (nextLink or (#msg + 1)) - 1)
        local quantity = tonumber(suffix:match("[xX]%s*(%d+)")) or 1
        local linkPrefix = msg:sub(searchFrom, linkStart - 1)
        local itemId = tonumber(linkPrefix:match("|Hitem:(%d+)[^|]*$"))
        AddLoot(itemName, quantity, "CHAT", itemId)
        searchFrom = linkEnd + 1
    end

    -- Egyes sandbox szerverek link nelkul, csak [Item neve] formaban irnak.
    if not foundLink then
        local itemName = msg:match("%[([^%[%]]+)%]")
        if itemName then
            local quantity = tonumber(msg:match("[xX]%s*(%d+)")) or 1
            AddLoot(itemName, quantity, "CHAT_PLAIN", nil)
        end
    end
end

local function StartLootSession(forceNew)
    local now = Now()
    if forceNew or not lootSessionActive or (now - lootSessionStarted) > 2 then
        wipe(seenLootSlots)
        lootSessionStarted = now
    end
    lootSessionActive = true
end

local function CaptureLootSlots()
    if not GetNumLootItems or not GetLootSlotInfo then return end

    local count = GetNumLootItems() or 0
    for slot = 1, count do
        if not seenLootSlots[slot] then
            local hasItem = true
            if LootSlotHasItem then hasItem = LootSlotHasItem(slot) end
            if hasItem then
                local _, itemName, quantity = GetLootSlotInfo(slot)
                local link = nil
                if GetLootSlotLink then link = GetLootSlotLink(slot) end
                if (not itemName or itemName == "") and link then
                    if link then itemName = link:match("|h%[(.-)%]|h") end
                end
                if itemName and itemName ~= "" then
                    local itemId = link and tonumber(link:match("|Hitem:(%d+)")) or nil
                    seenLootSlots[slot] = true
                    AddLoot(itemName, quantity, "LOOT_API", itemId)
                end
            end
        end
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("CHAT_MSG_LOOT")
frame:RegisterEvent("LOOT_OPENED")
frame:RegisterEvent("LOOT_CLOSED")
pcall(frame.RegisterEvent, frame, "LOOT_READY")

frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local addonName = ...
        if addonName == "AIFishLootTracker" then
            AIFishLootMeta.loaded = true
            AIFishLootMeta.version = ADDON_VERSION
        end
    elseif event == "CHAT_MSG_LOOT" then
        HandleLootMessage((...))
    elseif event == "LOOT_READY" then
        StartLootSession(true)
        CaptureLootSlots()
    elseif event == "LOOT_OPENED" then
        StartLootSession(false)
        CaptureLootSlots()
    elseif event == "LOOT_CLOSED" then
        lootSessionActive = false
        wipe(seenLootSlots)
    end
end)

local function PrintStatus()
    local total = 0
    local kinds = 0
    for _, count in pairs(AIFishLootDB) do
        total = total + (tonumber(count) or 0)
        kinds = kinds + 1
    end
    print(("AI-Fishbot addon v%s: %d item / %d fajta"):format(ADDON_VERSION, total, kinds))
    print(("Utolso: %s x%s | forras: %s | dedup: %d"):format(
        tostring(AIFishLootMeta.lastItem or "-"),
        tostring(AIFishLootMeta.lastQuantity or 0),
        tostring(AIFishLootMeta.lastSource or "-"),
        tonumber(AIFishLootMeta.duplicateSuppressed or 0)))
    local lastId = AIFishLootMeta.lastItem and AIFishLootMeta.itemIds[AIFishLootMeta.lastItem] or nil
    print(("Utolso item ID: %s"):format(tostring(lastId or "ismeretlen")))
end

SLASH_AIFISHLOOT1 = "/aifishloot"
SlashCmdList["AIFISHLOOT"] = function(cmd)
    cmd = (cmd or ""):lower():match("^%s*(.-)%s*$")
    if cmd == "reset" then
        wipe(AIFishLootDB)
        AIFishLootMeta.totalRecorded = 0
        AIFishLootMeta.lastItem = nil
        AIFishLootMeta.lastQuantity = nil
        AIFishLootMeta.lastSource = nil
        AIFishLootMeta.duplicateSuppressed = 0
        wipe(AIFishLootMeta.sourceCounts)
        wipe(AIFishLootMeta.itemIds)
        wipe(recentByName)
        print("AI-Fishbot: zsakmany szamlalo torolve.")
        return
    end

    if cmd == "status" or cmd == "debug" then
        PrintStatus()
        return
    end

    print("AI-Fishbot zsakmany szamlalo:")
    local any = false
    for name, count in pairs(AIFishLootDB) do
        any = true
        print(("  %s x%d"):format(name, count))
    end
    if not any then print("  (meg nincs semmi rogzitve)") end
    PrintStatus()
end
