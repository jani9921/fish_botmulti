AI-FishBot Monitor v2.9 - egyseges indito es titkositott profilok
================================================================

Mi volt a regi gepen a hiba?
----------------------------
- A csatolt regi session log 8862 alkalommal ezt irta:
  "Process-InputQueue ... array index evaluated to null".
- Emiatt az egyetlen sorban maradt parancs beragadt, es a loot mentesehez
  szukseges /reload sem futott le. Az Enabled=true ezt nem tudta megjavitani.
- A regi beallitas raadasul csak 100 fogasi esemeny utan olvasta volna be az
  itemneveket. A csatolt futasok 47 es 44 fogasnal alltak meg.
- A regi AI-Fishbot.ps1 fajlt es a regi addon mappat is le kell cserelni;
  nem eleg csak az Enabled erteket atirni.

Telepites
---------
1. Masold az AIFishLootTracker mappat a hasznalt WoW kliens ala:
   <WoW kliens>\Interface\AddOns\AIFishLootTracker

2. Az AddOns listaban legyen bekapcsolva az "AI Fish Loot Tracker".
   Ha a sandbox kliens regi interface-verziot hasznal, kapcsold be a
   "Load out of date AddOns" lehetoseget.

3. Az AI-Fishbot-8clients-v2.9.ps1, NAudio.Core.dll es NAudio.Wasapi.dll maradjon
   ugyanabban a mappaban.

4. Inditsd el a WoW klienseket, lepj be mindegyikkel a karakterig, majd inditsd
   az AI-Fishbot-8clients-v2.9.ps1 fajlt Windows PowerShell 5.1 alatt.

5. A foablak inditopaneljen pipald ki a legfeljebb 8 WoW PID-et. Ugyanitt
   minden klienshez kulon beallithatod a jelszot, dobas, kapas, kilepes es buff
   billentyuit. Ezutan a program egyenkent
   reseteli es /reloadolja a klienseket. Ezzel automatikusan megallapitja,
   melyik PID-hez melyik Account\...\AIFishLootTracker.lua fajl tartozik.
   A parositas alatt az adott kliens nem horgaszik; ez 8 kliensnel nagyjabol
   fel percet vesz igenybe.

Dinamikus billentyuk
--------------------
- A billentyuk nem fixen az F6-F10 gombokhoz vannak kotve.
- Minden kivalasztott PID sajat billentyukiosztast kap.
- Elfogadott pelda: F6, 1, A, CTRL+F6, SHIFT+1, ALT+F2, SPACE.
- A program a valasztasi sorrend szerinti 1-8. slothoz menti a beallitasokat
  a client-keybinds.json fajlba, es a kovetkezo inditasnal visszatolti oket.
- A foablak tablazata mutatja az egyes kliensek Dobas/Kapas billentyuit.
- Ha nem akarod minden inditasnal megjeleniteni a szerkesztot, allitsd ezt:

  ShowKeybindEditorEveryStart = $false

Egyablakos inditas es beallitasmentes
-------------------------------------
- Inditaskor nincs kulon PID-valaszto vagy keybind-popup. Eloszor ugyanaz a
  meretezheto foablak nyilik meg, rajta az inditopanellel.
- A program addig nem inditja el a gyors monitor timert es nem kuld semmilyen
  WoW inputot, amig meg nem nyomod a zold "KIJELÖLT PID-EK... INDITASA" gombot.
- Az 1. fulon a futo WoW PID-ek pipalhatok. Egy sorra kattintva PID-enkent
  kulon szerkesztheto a dobas, kapas, kilepes, maszkolt reconnect jelszo,
  valamint minden buff engedelye, billentyuje, cast ideje es idotartama.
- A 2. fulon tobb mint 100 globalis/advanced ertek szerkesztheto, koztuk a
  Logging.Enabled, loot/reload, recovery, hang, AH, eladasi tanacsado, target,
  atvaltas, GUI, notification es fajlutvonal beallitasok.
- A 3. fulon megadhato a Blizzard Client ID es a maszkolt Client Secret.
- A "BEALLITASOK MENTESE" gomb a globalis ertekeket, a PID-sorrend szerinti
  kliensprofilokat, a Blizzard hitelesitest es a WoW jelszavakat is megjegyzi.
- A Client ID, Client Secret es WoW jelszavak Windows DPAPI CurrentUser
  titkositassal kerulnek az ai-fishbot-settings.json fajlba. Csak ugyanaz a
  Windows-felhasznalo tudja visszafejteni; plaintext titok nincs a fajlban.
- A PID-ek uj Windows/WoW inditasnal valtozhatnak, ezert a profilok a rendezes
  szerinti slotokra toltenek vissza. Inditas elott mindig nezd at, melyik slot
  melyik karakterhez tartozik.
- Egyik jelszo vagy Client Secret sem kerul a program logjaba, session CSV-be,
  catches CSV-be vagy JSON riportba. A mentest az ai-fishbot-settings.json
  torlesevel lehet teljesen elfelejteni.

PID START / PAUSE / STOP es meretezheto ablak
----------------------------------------------
- A kliensracsban kattints arra a PID-sorra, amelyiket vezerelni akarod.
- START: csak a kijelolt PID horgaszatat inditja vagy folytatja.
- PAUSE: szunetelteti a kijelolt PID-et, es torli annak fuggoben levo inputjait.
- STOP: leallitja a kijelolt PID automatizalasat. A tobbi kliens tovabb fut.
- PAUSE/STOP alatt az adott PID-hez dobasi, kapasi, buff, reload es reconnect
  billentyu sem kerul elkuldesre. START tiszta NeedCast allapotbol folytatja.
- A foablak szele es sarkai egerrel huzhatok, maximalhato is. A tablazatok es a
  felso harom oszlop a rendelkezesre allo szelesseghez igazodik.

Kijelolheto itemek es eladasi tanacsado
----------------------------------------
- A "Fogott itemek" fulon minden kifogott item kulon sorban latszik. Kattints
  egy sorra; a jobb felso panel megmutatja az aktualis arat, historikus minimumot,
  maximumot, atlagot, felso 25%-os kuszobot es az altalaban legerosebb hetnapot.
- Minden sikeres Blizzard AH frissites bekerul a blizzard-ah-price-history.csv
  fajlba. A program legfeljebb 120 napot tart meg, ujrainditas utan is tanul tovabb.
- A heti minta napi medianokbol keszul, igy egy hosszan futo nap nem kap
  aranytalanul nagyobb sulyt. A panel a mintak es a kulon napok szamat, valamint
  a becsles bizalmi szintjet is mutatja.
- Legalabb 12 arpont es 3 kulon nap kell az elso jelzeshez. 7-14 kulon nap utan
  mar ertelmesebb a hetnap-osszehasonlitas; az elso napokban ADATGYUJTES latszik.
- "MEHETSZ AZ AH-BA - ELADAS MOST": az aktualis ar a sajat tortenet felso
  tartomanyaban van, illetve nem marad el a historikus atlagtol.
- "TARTSD MEG 1/2 NAPOT": a kovetkezo 1-2 nap egy korabban erosebb hetnap, es
  annak tortenelmi atlaga legalabb 5%-kal magasabb a mostani arnal.
- A szines jelzes statisztikai becsles, nem garancia arra, hogy a targy azon az
  aron es idon belul tenylegesen elkel.

Loot naplozas v2.9
-------------------
- Minden sikeresen elkuldott bobber-kattintas AZONNAL bekerul a logs mappa
  catches_<session>.csv fajljaba. Ez a bot fogasi esemenye, nem meg az itemnev.
- A pontos itemnev es mennyiseg a WoW addon SavedVariables fajljabol erkezik.
  Ehhez a WoW csak /reload vagy kilepes kozben irja ki a memoriaban levo adatot.
- A v2.9 10 uj fogasi esemenynel, de legkesobb 3 perc elmaradasnal sorositott
  /reloadot vegez, majd beolvassa az itemeket.
- A session_<session>.csv percenkent frissul, es tartalmazza a LootSyncState,
  PendingLootHooks, SyncedLootItems es LastLootSync mezoket.
- A GUI Loot sync oszlopa roviden mutatja az allapotot. Pelda:
  "Idle v1.3 p:3 i:27 21:14:05" = jo addonverzio, 3 pending fogas,
  27 szinkronizalt item.
- Az addon v1.3 a lootablak API-jat es a loot chatet is figyeli, majd kiszuri
  a ket forrasbol erkezo duplikaciot. A link nelkuli sandbox chatet is kezeli,
  a normal item linkekbol pedig a Blizzard item ID-t is elmenti.
- Jatekon beluli ellenorzes: /aifishloot status. Ennek v1.3-at, item darabszamot,
  utolso itemet, forrast es item ID-t kell mutatnia.
- A monitor a SavedVariables fajlban is ellenorzi az addon verziot. Ha
  "legacy/unknown" vagy "Regi addon" latszik, a regi addon mappa maradt fenn.

Adaptiv disconnect/reconnect
----------------------------
- A kimarado kapasok szama onmagaban alapbol NEM jelent disconnectet. Emiatt
  a program nem ir jelszot egy meg elo kliens chatablakaba.
- Indulas utan kliensenkent megtanulja a WoW folyamat szerverkapcsolatat.
  A foablak Kapcsolat oszlopa LEARNING, ONLINE vagy OFFLINE allapotot mutat.
- Recovery csak akkor indul, ha a megtanult TCP-kapcsolat legalabb 12
  masodperce folyamatosan hianyzik.
- Minden recovery-lepes utan ujra ellenorzi a kapcsolatot. Ha visszajott,
  az osszes hatralevo billentyut kihagyja, 5 masodperc stabilitas utan pedig
  automatikusan folytatja a horgaszatot.
- Egyszerre csak egy kliens kaphat recovery-inputot. A tobbi kliens sorban
  var, ezert 8 kliens sem gepel egymasra.
- Ha a Windows halozati telemetria atmenetileg hibazik, a recovery
  TelemetryPaused allapotban megall es torli a fuggoben levo recovery-inputot.
  Friss kapcsolatadat nelkul nem folytat vakon semmilyen billentyusorozatot.
- Sikertelen korok utan 15, 30, majd 60 masodperces visszavonulas kovetkezik.
  Harom sikertelen probalkozas utan az adott kliens MANUAL allapotba kerul.
- A recovery lepesek a script elejen levo Recovery.ActionPlan listaban
  modosithatok. A varakozas nem vak kesleltetes: kozben is figyeli a kapcsolatot.
- A jelszobeiras biztonsagi okbol alapbol tiltott:

  AllowPasswordTyping = $false

  Ha a szerver valoban ker jelszot reconnectnel, a 2. fulon tedd az
  AllowPasswordTyping erteket true-ra, majd az 1. fulon add meg kulon-kulon a
  kijelolt PID-ek jelszavat. A GUI-ban mentett jelszavak DPAPI-val titkositva
  tarolodnak es nem kerulnek a logba. Az AIFISHBOT_WOW_PASSWORD kornyezeti
  valtozo megmaradt tartalek megoldasnak: csak azoknal a profiloknal hasznalja,
  amelyekhez nincs kulon jelszo elmentve. Pi modban a jelszolepes mindig
  kimarad.
- Ha 30 masodperc utan is LEARNING marad, a kliens szerverportja valoszinuleg
  80 vagy 443, vagy IPv6-os kapcsolatot hasznal. Biztonsagos megoldaskent az
  auto reconnect ilyenkor nem indul. Ismert IPv4 sandbox-port eseten add meg
  azt a Recovery.ServerPorts listaban, peldaul: @(3724). Az IPv6 kapcsolatot
  ez a kiadas meg nem hasznalja recovery-triggerkent.
- A FallbackToNoBiteOnly alapbol false. True-ra allitva kapcsolatmeres nelkul
  is indulhat recovery, de ez kevesbe megbizhato, ezert jelszobeirassal egyutt
  nem ajanlott.

Automatikus Blizzard Auction House arak (ajanlott)
---------------------------------------------------
- Ez csak a Blizzard altal kiszolgalt hivatalos WoW Retail AH-adatokkal mukodik.
  Privat/sandbox szerver custom itemeihez tovabbra is kezi ar kell.
- Keszits ingyenes API klienst a Battle.net Developer Portalon:
  https://develop.battle.net/access/clients
- A Client ID-t es Client Secretet NE ird bele a scriptbe es ne kuldd el senkinek.
  A foablak 3. fule az ajanlott megoldas: ott add meg, majd nyomd meg a Mentes
  gombot. A Secret maszkolt, es DPAPI-titkositva marad meg.
- Kornyezeti valtozo tovabbra is hasznalhato fallbackkent:

  $env:AIFISHBOT_BLIZZARD_CLIENT_ID = "SAJAT_CLIENT_ID"
  $env:AIFISHBOT_BLIZZARD_CLIENT_SECRET = "SAJAT_CLIENT_SECRET"
  .\AI-Fishbot-8clients-v2.9.ps1

- A bot csak OAuth client-credentials tokent ker; nem jelentkezik be a WoW
  fiokodba, nem ker Battle.net jelszot, es nem olvas karakterprofil-adatot.
- Az addon item ID-it automatikusan osszegyujti. Uj item ID-nel hatterben
  letolti a Ragnaros kapcsolt realm hagyomanyos aukcioit es az EU-regios
  commodity aukciokat, majd csak a kifogott ID-k arai maradnak a cache-ben.
- Alapbol a legolcsobb aktualis darabarat hasznalja. A buyout stack arat
  elosztja a quantity ertekevel; a commodity unit_price mar eleve darabar.
- Normal esetben 60 percenkent frissit. Halozati/API hiba utan 5 perc mulva
  ujraprobalja. A nagy AH-valasz kulon PowerShell-jobban dolgozodik fel, ezert
  nem allitja meg a hangfigyelest vagy a tobbi kliens inputjait.
- A blizzard-ah-price-cache.json nem tartalmaz tokent vagy titkot, csak item
  ID-t, arat, mennyiseget, listingszamot, forrast es lekeresi idopontot.
- A GUI Arforras sora mutatja: BLIZZARD LEKERES FUT, BLIZZARD AH x/y ID,
  BLIZZARD KULCS HIANYZIK, BLIZZARD HIBA vagy BLIZZARD CACHE.
- Alternativ arszamitas a script elejen:

  BlizzardPriceMetric = "WeightedAverage"

  Az alapertelmezett es ajanlott ertek: "MinimumBuyout".

BootyBayBroker/CSV fallback es teljes ertek
-------------------------------------------
- Ha nincs Blizzard API-kulcs vagy egy itemre nincs aktualis AH-listing, a
  program a BootyBayBroker/CSV es a kezi arakat fallbackkent tovabbra is kezeli.
- Minden sikeres loot sync utan frissul a bootybaybroker-catches.json. Ez a
  BootyBayBroker Inventory Price Check oldalan egyben beillesztheto export.
- Nyisd meg ezt az oldalt:
  https://bootybaybroker.com/inventory-price-check
- Illeszd be a bootybaybroker-catches.json teljes tartalmat, valaszd ki a helyes
  jatekverziot/regiot/realmet, majd futtasd az arlekerezest.
- A script alapbeallitasa retail / eu / Ragnaros / Horde. Alliance karakter
  eseten a script elejen a Price.Faction erteket ird at "Alliance"-ra.
- A kapott egysegarakat masold a bootybaybroker-price-import.csv megfelelo
  soraiba. Goldban a UnitPriceGold oszlopot toltsd; ha a nyers ar copperben van,
  akkor a UnitPriceCopper oszlopot. 10 000 copper = 1 gold.
- A bot az arimport fajlt 5 masodpercenkent figyeli. Nem kell ujrainditani:
  mentes utan automatikusan ujraszamolja az osszesitett erteket es target ETA-t.
- Minden ujonnan kifogott targy automatikusan uj ures sort kap az arimport CSV-ben.
- A GUI kiirja, hany itemfajta arazott, es hany darab maradt ar nelkul. Az
  arazatlan tetel nem szamit bele csendben a bevetelebe, hanem kulon latszik.
- A BootyBayBroker csak a nala ismert, hivatalos AH itemeket tudja arazni.
  Link nelkuli vagy custom sandbox itemhez kezi ar adhato meg a script elejen:

  AdditionalItemPrices = @{
      "Masik hal pontos neve" = 12.5
      "Harmadik targy pontos neve" = 4
  }

  A kezi ar elsobbseget elvez az importalt arhoz kepest.
- A Wyrmfish alapertelmezett tartalek ara tovabbra is 62 gold/db.

Target es ETA
-------------
- A teljes gold, HUF, gold/ora, HUF/ora es minden 6h/24h/7d projekcio az OSSZES
  arazott kifogott tetel darabszam x egysegar osszegebol keszul.
- A target CURRENT erteke ugyanez az osszesitett HUF ertek.
- A REMAINING a meg hianyzo forint, a NEEDED VALUE a meg hianyzo gold-ertek.
- Az ETA a teljes arazott loot eddigi HUF/ora tempojabol szamolja ki, mikor
  erheto el a target. Ha meg nincs aktiv ido vagy arazott fogas, az ETA "--".
- Ha van arazatlan tetel, a kijelzett ertek es ETA konzervativ: csak a biztosan
  ismert arakat hasznalja.

Naplok
------
- A GUI masodpercenkent frissul.
- A session CSV alapbol percenkent kap 1 snapshotot kliensenkent.
- A catches CSV minden bobber-kattintasnal azonnal bovul.
- Leallitaskor mindig keszul egy utolso snapshot es JSON osszesito.
- A session CSV/JSON tartalmazza az item ID-kat, az egysegarakat, az arazott es
  arazatlan fajtaszamot, valamint az arazatlan tetelek nevet is.
- A fajlok a script melletti logs mappaba kerulnek.

Fontos javitasok
---------------
- Javítva az egyetlen queue elemnel jelentkezo null index hiba.
- Kliensenkenti, automatikus SavedVariables-parositas.
- A reloadok sorban, legalabb 8 masodperces eltéréssel futnak.
- Processz-ellenorzes cache-elve, audio polling 10 Hz-re korlatozva.
- A CSV bovul (append), nem irja ujra minden alkalommal a teljes elozo fajlt.
- Azonos hibauzenet legfeljebb 30 masodpercenkent kerul a naploba.
- Stackelt loot (xN) helyes mennyiseggel kerul az addon adatbazisaba.
- A fogasszamlalo csak sikeresen elkuldott bobber-input utan no.
- Kliensenkenti, indulaskor szerkesztheto es megjegyzett billentyukiosztas.
- Valodi halozati allapotra visszacsatolt, sorositott disconnect/reconnect.
- Gyors Windows TCP-tabla olvasas; a 2 masodperces halozati poll nem blokkolja
  a 10 Hz-es hangfigyelest.
- Telemetriahiba eseten biztonsagos recovery-szunet, fuggoben levo inputok
  torlesevel.
- Jelszobeiras alapbol tiltva, no-bite eseten nincs vak reconnect.
- Loot item sync 10 fogasnal vagy legkesobb 3 perc utan; sikertelen olvasasnal
  a pending fogasok megmaradnak es 60 masodperc mulva ujraprobalja.

Ha a loot parositas sikertelen
------------------------------
- Ellenorizd, hogy az addon mind a 8 accountnal engedelyezve van.
- A karakterek legyenek teljesen belepve a vilagba a program inditasa elott.
- A /aifishloot parancsnak a chatben ki kell irnia a szamlalo tartalmat.
- Ne indits ket monitorpeldanyt ugyanarra a WoW kliensre.
