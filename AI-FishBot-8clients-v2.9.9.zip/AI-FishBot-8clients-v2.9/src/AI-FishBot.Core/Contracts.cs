namespace AIFishBot.Core;
public interface IProfileStore { Task<ApplicationSettings> LoadAsync(CancellationToken token = default); Task SaveAsync(ApplicationSettings settings, CancellationToken token = default); }
public interface ISecretProtector { string Protect(string clearText); string Unprotect(string protectedValue); }
public interface IClientProfileManager { IReadOnlyCollection<ClientProfile> Profiles { get; } Task LoadProfilesAsync(CancellationToken token = default); Task CreateProfileAsync(ClientProfile profile, CancellationToken token = default); Task UpdateProfileAsync(ClientProfile profile, CancellationToken token = default); Task DeleteProfileAsync(Guid profileId, CancellationToken token = default); void BindRuntimeProcess(Guid profileId, int pid, nint windowHandle = 0); void UnbindRuntimeProcess(Guid profileId); }
public interface IClientController { Task StartAsync(Guid profileId, CancellationToken token = default); Task PauseAsync(Guid profileId, CancellationToken token = default); Task StopAsync(Guid profileId, CancellationToken token = default); Task ResetAsync(Guid profileId, CancellationToken token = default); Task RecoverAsync(Guid profileId, CancellationToken token = default); }
public interface IInputQueue : IAsyncDisposable { int Count { get; } ValueTask EnqueueAsync(InputCommand command, CancellationToken token = default); ValueTask RequeueAsync(InputCommand command, CancellationToken token = default); Task<InputCommand?> DequeueAsync(CancellationToken token); void Complete(InputCommand command); void ClearFishing(); void ClearAll(); }
public interface ISavedVariablesReader { Task<LootSnapshot?> ReadAsync(string path, CancellationToken token = default); }
public interface ISavedVariablesLocator { IReadOnlyList<string> FindCandidates(ClientProfile profile, string wowExecutablePath); }
public interface ILootDataParser { LootSnapshot Parse(string source, DateTimeOffset? writeTime = null); }
public interface IStatisticsService { ClientStatistics GetClientStatistics(Guid profileId); GlobalStatistics GetGlobalStatistics(); void UpdateLoot(Guid profileId, LootSnapshot snapshot); }
public interface ISettingsService : IAsyncDisposable { ApplicationSettings Current { get; } Task<ApplicationSettings> LoadAsync(CancellationToken token = default); Task SaveAsync(CancellationToken token = default); void ScheduleSave(); }
public interface ISettingsValidator { IReadOnlyList<string> Validate(ApplicationSettings settings); }
public interface IV2MigrationService { Task<bool> TryMigrateAsync(string v2SettingsPath, string backupDirectory, ApplicationSettings target, CancellationToken token = default); }
public interface IProcessDiscoveryService { IReadOnlyList<ProcessCandidate> FindWowProcesses(); }
public interface IProfileBindingService { IReadOnlyList<ProcessCandidate> UnboundProcesses { get; } void RefreshBindings(); bool Bind(Guid profileId, int pid); void Unbind(Guid profileId); }
public interface IInputExecutor { Task ExecuteAsync(ClientRuntime runtime, ClientProfile profile, InputCommand command, CancellationToken token); }
public interface ISerialInputSender : IDisposable { void Send(string portName, string command); }
public interface IClientInputQueueFactory { IInputQueue Get(Guid profileId); ValueTask RemoveAsync(Guid profileId); }
public interface IAudioPeakService { IReadOnlyDictionary<int, float> GetPeaks(IEnumerable<int> processIds); }
public interface INetworkMonitor { IReadOnlyDictionary<int, IReadOnlyList<string>> GetEstablishedEndpoints(IEnumerable<int> processIds, RecoveryConfiguration settings); }
public interface IPriceService { IReadOnlyDictionary<int, ItemPrice> Prices { get; } Task RefreshAsync(IEnumerable<int> itemIds, CancellationToken token = default); decimal? GetUnitPriceGold(LootItem item); PriceAnalysis Analyze(int itemId); }
public interface IRevenueService { ClientStatistics Calculate(ClientStatistics statistics, double activeHours); TargetProgress GetTargetProgress(ClientProfile profile, ClientStatistics statistics); bool TryMarkTargetReached(ClientProfile profile, TargetProgress progress); }
public interface IReportService { Task WriteCatchAsync(ClientProfile profile, ClientRuntime runtime, CancellationToken token = default); Task WriteSnapshotAsync(ApplicationState state, CancellationToken token = default); Task WriteFinalSummaryAsync(ApplicationState state, CancellationToken token = default); }
