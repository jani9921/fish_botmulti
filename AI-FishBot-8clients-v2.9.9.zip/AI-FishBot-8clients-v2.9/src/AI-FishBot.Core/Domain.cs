using System.Collections.ObjectModel;

namespace AIFishBot.Core;

public enum FishingState { Stopped, Starting, Running, Paused, Stopping, Recovering }
public enum FishingPhase { Idle, NeedCast, Casting, AwaitingBite, ClickBobber, PostCatch }
public enum ConnectionState { Unknown, Learning, Connected, SuspectedDisconnect, Disconnected, Recovering, Waiting, ManualIntervention }
public enum HealthState { Healthy, Warning, Error, Offline, Unbound }
public enum InputPriority { Maintenance = 10, Buff = 20, Cast = 30, Fishing = Cast, Bobber = 40, Recovery = 100 }
public enum RecoveryState { Idle, Learning, Monitoring, SuspectedDisconnect, WaitingSlot, Recovering, Waiting, Backoff, Stabilizing, TelemetryPaused, ManualIntervention }
public enum PriceMetric { MinimumBuyout, WeightedAverage }
public enum SellSignal { CollectingData, SellNow, HoldOneOrTwoDays, Neutral }

// Persistent: ProfileId is the only durable identity. RuntimePid is intentionally absent.
public sealed class ClientProfile {
    public Guid ProfileId { get; init; } = Guid.NewGuid();
    public string DisplayName { get; set; } = "New client";
    public string WindowTitlePattern { get; set; } = "World of Warcraft";
    public string? AccountIdentifier { get; set; }
    public string? CharacterIdentifier { get; set; }
    public string? SavedVariablesPath { get; set; }
    public string? EncryptedPassword { get; set; }
    public string? ExecutablePathPattern { get; set; }
    public bool AutoBindEnabled { get; set; } = true;
    public bool StartAutomatically { get; set; }
    public KeybindConfiguration Keybinds { get; set; } = new();
    public BuffConfiguration Buffs { get; set; } = BuffConfiguration.CreateDefault();
    public TargetConfiguration Target { get; set; } = new();
    public ClientStatistics LifetimeStatistics { get; set; } = new();
}
public sealed class ClientRuntime {
    public Guid ProfileId { get; init; }
    public int? RuntimePid { get; set; }
    public nint WindowHandle { get; set; }
    public DateTimeOffset LastSeen { get; set; }
    public FishingState FishingState { get; set; } = FishingState.Stopped;
    public FishingPhase FishingPhase { get; set; } = FishingPhase.Idle;
    public ConnectionState ConnectionState { get; set; } = ConnectionState.Unknown;
    public HealthState Health { get; set; } = HealthState.Unbound;
    public LootSnapshot? LastValidLootSnapshot { get; set; }
    public DateTimeOffset? LastSuccessfulLootRead { get; set; }
    public string? LastLootReadError { get; set; }
    public int InputQueueLength { get; set; }
    public DateTimeOffset LastStateTransition { get; set; } = DateTimeOffset.UtcNow;
    public ClientSession? Session { get; set; }
    public string? LastError { get; set; }
    public string? LastInputError { get; set; }
    public string? LastInputAction { get; set; }
    public DateTimeOffset? LastInputAt { get; set; }
    public string? WindowTitle { get; set; }
    public string? ExecutablePath { get; set; }
    public DateTimeOffset? LastLootWriteTime { get; set; }
    public DateTimeOffset? LastActivity { get; set; }
    public DateTimeOffset? FirstUnsyncedCatchAt { get; set; }
    public int NoBiteStreak { get; set; }
    public int CastRetryCount { get; set; }
    public DateTimeOffset NextActionAt { get; set; }
    public DateTimeOffset CastDeadline { get; set; }
    public bool IsLootSyncing { get; set; }
    public int PendingLootHooks { get; set; }
    public string LootSyncState { get; set; } = "Idle";
    public string LootAddonVersion { get; set; } = "-";
    public HashSet<string> NetworkBaseline { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public bool? NetworkTelemetryAvailable { get; set; }
    public DateTimeOffset? NetworkLostSince { get; set; }
    public DateTimeOffset? NetworkStableSince { get; set; }
    public RecoveryState RecoveryState { get; set; } = RecoveryState.Idle;
    public RecoveryAttempt Recovery { get; set; } = new();
}
public sealed class ClientSession { public Guid SessionId { get; init; } = Guid.NewGuid(); public Guid ProfileId { get; init; } public int? RuntimePid { get; set; } public DateTimeOffset StartedAt { get; init; } = DateTimeOffset.UtcNow; public DateTimeOffset? StoppedAt { get; set; } public ClientStatistics Statistics { get; set; } = new(); public FishingState State { get; set; } = FishingState.Starting; public double ActiveTimeSeconds { get; set; } public double PausedTimeSeconds { get; set; } public double ReloadTimeSeconds { get; set; } public long HookCount { get; set; } }
public sealed class ClientStatistics { public Dictionary<string, long> Items { get; set; } = new(StringComparer.OrdinalIgnoreCase); public Dictionary<string, long> SessionItems { get; set; } = new(StringComparer.OrdinalIgnoreCase); public Dictionary<string, long> LastSnapshotCounts { get; set; } = new(StringComparer.OrdinalIgnoreCase); public Dictionary<string, int> ItemIds { get; set; } = new(StringComparer.OrdinalIgnoreCase); public long LifetimeWyrmfish { get; set; } public long SessionWyrmfish { get; set; } public long LifetimeLoot { get; set; } public long SessionLoot { get; set; } public decimal RevenueGold { get; set; } public decimal RevenueEur { get; set; } public decimal RevenueHuf { get; set; } public decimal GoldPerHour { get; set; } public decimal HufPerHour { get; set; } public DateTimeOffset? SessionStartedAt { get; set; } public double ActiveTimeSeconds { get; set; } public double WyrmfishPerHour => SessionWyrmfish / Math.Max(ActiveTimeSeconds / 3600d, 0.0001); public double LootPerHour => SessionLoot / Math.Max(ActiveTimeSeconds / 3600d, 0.0001); }
public sealed class GlobalStatistics { public long Wyrmfish { get; init; } public long TotalLoot { get; init; } public decimal RevenueGold { get; init; } public decimal RevenueEur { get; init; } public decimal RevenueHuf { get; init; } public decimal GoldPerHour { get; init; } public decimal HufPerHour { get; init; } }
public sealed class LootSnapshot { public Dictionary<string, LootItem> Items { get; init; } = new(StringComparer.OrdinalIgnoreCase); public DateTimeOffset ReadAt { get; init; } = DateTimeOffset.UtcNow; public DateTimeOffset? SourceWriteTime { get; init; } public string AddonVersion { get; init; } = "unknown"; public long DuplicateSuppressed { get; init; } public bool IsValid { get; init; } = true; }
public sealed class LootItem { public string Name { get; init; } = ""; public long Count { get; init; } public int? ItemId { get; init; } }
public sealed class InputCommand { public Guid CommandId { get; init; } = Guid.NewGuid(); public Guid ProfileId { get; init; } public InputPriority Priority { get; init; } public required string Action { get; init; } public string? Key { get; init; } public string? Text { get; init; } public int WaitAfterSeconds { get; init; } public DateTimeOffset Timestamp { get; init; } = DateTimeOffset.UtcNow; public int RetryCount { get; set; } public int RetryLimit { get; init; } = 3; public TimeSpan Timeout { get; init; } = TimeSpan.FromSeconds(5); public CancellationToken CancellationToken { get; init; } }
public sealed class TargetConfiguration { public bool Enabled { get; set; } public decimal TargetAmount { get; set; } public string Currency { get; set; } = "HUF"; public bool NotifyOnReached { get; set; } = true; public bool StopOnReached { get; set; } public bool ReachedNotified { get; set; } public decimal LastNotifiedTargetAmount { get; set; } }
public sealed class KeybindConfiguration { public string Cast { get; set; } = "F6"; public string Hook { get; set; } = "F7"; public string Exit { get; set; } = "F8"; public string Reload { get; set; } = "F9"; }
public sealed class BuffConfiguration { public List<BuffDefinition> Entries { get; set; } = []; public static BuffConfiguration CreateDefault() => new() { Entries = [new BuffDefinition { Id = 1, Name = "Buff 1", Key = "F9", Enabled = true, CastTime = TimeSpan.FromSeconds(1), Duration = TimeSpan.FromMinutes(5) }, new BuffDefinition { Id = 2, Name = "Buff 2", Key = "F10", CastTime = TimeSpan.FromSeconds(5), Duration = TimeSpan.FromMinutes(30) }] }; }
public sealed class BuffDefinition { public int Id { get; set; } public string Name { get; set; } = ""; public string Key { get; set; } = ""; public bool Enabled { get; set; } public TimeSpan CastTime { get; set; } public TimeSpan Duration { get; set; } }
public sealed class RecoveryAttempt { public int AttemptCount { get; set; } public int StepIndex { get; set; } public DateTimeOffset? LastAttempt { get; set; } public DateTimeOffset? NextAttempt { get; set; } public DateTimeOffset? Deadline { get; set; } public string? FailureReason { get; set; } }
public sealed class ApplicationSettings { public int SchemaVersion { get; set; } = 4; public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow; public List<ClientProfile> Profiles { get; set; } = []; public decimal HufPerGold { get; set; } = 1; public string? V2SettingsPath { get; set; } public bool V2MigrationCompleted { get; set; } public GeneralConfiguration General { get; set; } = new(); public AudioConfiguration Audio { get; set; } = new(); public RecoveryConfiguration Recovery { get; set; } = new(); public LootConfiguration Loot { get; set; } = new(); public PriceConfiguration Price { get; set; } = new(); public RevenueConfiguration Revenue { get; set; } = new(); public GuiConfiguration Gui { get; set; } = new(); public LoggingConfiguration Logging { get; set; } = new(); public BlizzardCredentialConfiguration BlizzardCredentials { get; set; } = new(); }
public sealed class ApplicationState { public object SyncRoot { get; } = new(); public ObservableCollection<ClientRuntime> Clients { get; } = []; public ObservableCollection<AlertEntry> Alerts { get; } = []; public Guid? SelectedProfileId { get; set; } public int? SelectedRuntimePid { get; set; } public ApplicationSettings Settings { get; set; } = new(); public GlobalStatistics GlobalStatistics { get; set; } = new(); public ClientRuntime[] GetClientsSnapshot() { lock (SyncRoot) return Clients.ToArray(); } public AlertEntry[] GetAlertsSnapshot() { lock (SyncRoot) return Alerts.ToArray(); } public void AddAlert(AlertEntry alert) { lock (SyncRoot) Alerts.Add(alert); } public void TrimAlerts(int maximum) { lock (SyncRoot) while (Alerts.Count > maximum) Alerts.RemoveAt(0); } }
