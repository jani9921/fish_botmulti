using System.Collections.Concurrent;
using AIFishBot.Core;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace AIFishBot.Application;

public sealed class InputWorkerHostedService(ApplicationState state, IClientProfileManager profiles, IClientInputQueueFactory queues, IInputExecutor executor, IReportService reports, ILogger<InputWorkerHostedService> logger) : BackgroundService {
    private readonly ConcurrentDictionary<Guid, Task> _workers = new();
    private readonly ConcurrentDictionary<Guid, CancellationTokenSource> _workerTokens = new();
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
        while (!stoppingToken.IsCancellationRequested) {
            var current = profiles.Profiles.Select(x => x.ProfileId).ToHashSet();
            foreach (var profileId in current) _ = _workers.GetOrAdd(profileId, id => { var linked = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken); _workerTokens[id] = linked; return RunClientAsync(id, linked.Token); });
            foreach (var removed in _workers.Keys.Where(id => !current.Contains(id)).ToArray()) { if (_workerTokens.TryRemove(removed, out var linked)) { linked.Cancel(); linked.Dispose(); } if (_workers.TryRemove(removed, out var worker)) { try { await worker; } catch (OperationCanceledException) { logger.LogDebug("Input worker canceled for removed ProfileId={ProfileId}", removed); } await queues.RemoveAsync(removed); } }
            await Task.Delay(250, stoppingToken);
        }
        foreach (var source in _workerTokens.Values) source.Cancel();
        try { await Task.WhenAll(_workers.Values); } catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { logger.LogDebug("Input workers stopped."); }
        foreach (var source in _workerTokens.Values) source.Dispose(); _workerTokens.Clear();
    }
    private async Task RunClientAsync(Guid profileId, CancellationToken token) {
        var queue = queues.Get(profileId);
        while (!token.IsCancellationRequested) {
            InputCommand? command = null;
            try {
                command = await queue.DequeueAsync(token); if (command is null) continue;
                var runtime = state.GetClientsSnapshot().FirstOrDefault(x => x.ProfileId == profileId); var profile = profiles.Profiles.FirstOrDefault(x => x.ProfileId == profileId);
                if (runtime is null || profile is null || runtime.FishingState is FishingState.Stopped or FishingState.Paused) { queue.Complete(command); continue; }
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token, command.CancellationToken); timeout.CancelAfter(command.Timeout);
                await executor.ExecuteAsync(runtime, profile, command, timeout.Token); Complete(runtime, command, true); queue.Complete(command); if (command.Action == "Bobber") try { await reports.WriteCatchAsync(profile, runtime, token); } catch (Exception reportError) { logger.LogWarning(reportError, "Catch journal write failed for ProfileId={ProfileId}", profileId); }
            } catch (OperationCanceledException) when (token.IsCancellationRequested) { break; }
            catch (Exception error) {
                if (token.IsCancellationRequested) break;
                if (command is not null && command.RetryCount++ < command.RetryLimit) { try { await Task.Delay(250, token); await queue.RequeueAsync(command, token); } catch (OperationCanceledException) when (token.IsCancellationRequested) { queue.Complete(command); break; } }
                else { var runtime = state.GetClientsSnapshot().FirstOrDefault(x => x.ProfileId == profileId); if (runtime is not null) Complete(runtime, command, false, error); if (command is not null) queue.Complete(command); logger.LogError(error, "Input failed for ProfileId={ProfileId}, Action={Action}, Reason={Reason}", profileId, command?.Action, error.Message); }
            } finally { var runtime = state.GetClientsSnapshot().FirstOrDefault(x => x.ProfileId == profileId); if (runtime is not null) runtime.InputQueueLength = queue.Count; }
        }
    }
    private void Complete(ClientRuntime runtime, InputCommand? command, bool success, Exception? error = null) {
        if (command is null) return; var now = DateTimeOffset.UtcNow;
        runtime.LastInputAction = command.Action; runtime.LastInputAt = now;
        if (!success) { runtime.LastInputError = $"{command.Action}: {error?.Message ?? "input failed"}"; if (command.Action == "Reload") { runtime.LootSyncState = "Failed"; runtime.IsLootSyncing = false; } if (command.Action is "Cast" or "Bobber") { runtime.FishingPhase = FishingPhase.NeedCast; runtime.NextActionAt = now.AddSeconds(1); } return; }
        runtime.LastInputError = null;
        switch (command.Action) {
            case "Cast": runtime.FishingPhase = FishingPhase.AwaitingBite; runtime.NextActionAt = now.AddSeconds(2); runtime.CastDeadline = now.AddSeconds(2 + (state.Settings.General.Retail ? 22 : 30)); break;
            case "Bobber": runtime.LastActivity = now; runtime.FirstUnsyncedCatchAt ??= now; runtime.NoBiteStreak = 0; runtime.CastRetryCount = 0; runtime.FishingPhase = FishingPhase.PostCatch; runtime.NextActionAt = now.AddSeconds(state.Settings.General.LootWaitSeconds + Random.Shared.NextDouble() * .4); if (runtime.Session is not null) { runtime.Session.HookCount++; runtime.PendingLootHooks++; } break;
            case "Reload": runtime.LootSyncState = "SyncLoot"; runtime.NextActionAt = now.AddSeconds(state.Settings.Loot.ReloadSettleSeconds); break;
            case "BindLoot": runtime.LootSyncState = "Binding"; break;
            case "Password" or "Key": if (runtime.NetworkTelemetryAvailable != true) runtime.RecoveryState = RecoveryState.TelemetryPaused; else { runtime.RecoveryState = RecoveryState.Waiting; runtime.Recovery.Deadline = now.AddSeconds(Math.Max(command.WaitAfterSeconds, 1)); } break;
        }
    }
}

public sealed class LootMonitorHostedService(ApplicationState state, IClientProfileManager profiles, ISavedVariablesReader reader, IStatisticsService statistics, ISettingsService settings, IClientInputQueueFactory queues, ILogger<LootMonitorHostedService> logger) : BackgroundService {
    private DateTimeOffset _nextReloadAllowed;
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
        while (!stoppingToken.IsCancellationRequested) {
            var now = DateTimeOffset.UtcNow;
            if (!state.Settings.Loot.Enabled) { await Task.Delay(1000, stoppingToken); continue; }
            foreach (var profile in profiles.Profiles) {
                var runtime = state.GetClientsSnapshot().FirstOrDefault(x => x.ProfileId == profile.ProfileId); if (runtime is null || string.IsNullOrWhiteSpace(profile.SavedVariablesPath)) continue;
                try { await TickAsync(profile, runtime, now, stoppingToken); } catch (Exception error) { runtime.LastLootReadError = error.Message; runtime.Health = HealthState.Warning; logger.LogWarning(error, "Loot monitor failed for ProfileId={ProfileId}", profile.ProfileId); }
            }
            state.GlobalStatistics = statistics.GetGlobalStatistics(); await Task.Delay(1000, stoppingToken);
        }
    }
    private async Task TickAsync(ClientProfile profile, ClientRuntime runtime, DateTimeOffset now, CancellationToken token) {
        var path = profile.SavedVariablesPath!; if (!File.Exists(path)) { runtime.LastLootReadError = "SavedVariables file does not exist."; runtime.Health = HealthState.Warning; return; }
        var writeTime = File.GetLastWriteTimeUtc(path); var hasNewFileData = runtime.LastLootWriteTime is null || writeTime > runtime.LastLootWriteTime;
        if (runtime.LootSyncState == "SyncLoot" && now >= runtime.NextActionAt) hasNewFileData = true;
        if (hasNewFileData) {
            var snapshot = await reader.ReadAsync(path, token);
            if (snapshot is not null && snapshot.IsValid) {
                // IMPORTANT: /reload után a WoW-nak előbb ténylegesen ki kell írnia az új
                // SavedVariables snapshotot. Ugyanazt a régi fájlt nem szabad új loot
                // szinkronként elfogadni, mert az nullázza a PendingLootHooks számlálót.
                var previousWriteTime = runtime.LastLootWriteTime;
                var hasNewWrite = previousWriteTime is null
                    || snapshot.SourceWriteTime is null
                    || snapshot.SourceWriteTime > previousWriteTime;

                if (!hasNewWrite) {
                    runtime.LastLootReadError = null;
                    if (runtime.IsLootSyncing || runtime.PendingLootHooks > 0)
                        runtime.LootSyncState = "WaitingForSavedVariables";
                    return;
                }

                runtime.LastValidLootSnapshot = snapshot;
                runtime.LastSuccessfulLootRead = now;
                runtime.LastLootWriteTime = snapshot.SourceWriteTime;
                runtime.LastLootReadError = null;
                runtime.LootAddonVersion = snapshot.AddonVersion;
                runtime.LootSyncState = "Idle";
                runtime.IsLootSyncing = false;
                runtime.PendingLootHooks = 0;
                runtime.FirstUnsyncedCatchAt = null;
                runtime.Health = snapshot.AddonVersion == state.Settings.Loot.RequiredAddonVersion
                    ? HealthState.Healthy
                    : HealthState.Warning;
                statistics.UpdateLoot(profile.ProfileId, snapshot);
                profile.LifetimeStatistics = statistics.GetClientStatistics(profile.ProfileId);
                settings.ScheduleSave();
            }
            else {
                runtime.LastLootReadError = "SavedVariables is locked, empty, or partially written; last valid loot retained.";
                runtime.LootSyncState = "ReadRetry";
                runtime.NextActionAt = now.AddSeconds(60);
            }
        }
        if (runtime.FishingState != FishingState.Running || runtime.IsLootSyncing || runtime.PendingLootHooks <= 0 || now < _nextReloadAllowed) return;
        var countDue = runtime.PendingLootHooks >= state.Settings.Loot.ReloadEveryCatches; var timeDue = runtime.FirstUnsyncedCatchAt is { } first && (now - first).TotalMinutes >= state.Settings.Loot.MaxUnsyncedMinutes;
        if (!countDue && !timeDue) return;
        await queues.Get(profile.ProfileId).EnqueueAsync(new InputCommand { ProfileId = profile.ProfileId, Priority = InputPriority.Maintenance, Action = "Reload", Timeout = TimeSpan.FromSeconds(10) }, token);
        runtime.IsLootSyncing = true; runtime.LootSyncState = "Requested"; _nextReloadAllowed = now.AddSeconds(state.Settings.Loot.ReloadSpacingSeconds);
    }
}

public sealed class ProcessMonitorHostedService(IProfileBindingService binding, ApplicationState state, ILogger<ProcessMonitorHostedService> logger) : BackgroundService {
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
        while (!stoppingToken.IsCancellationRequested) {
            try { binding.RefreshBindings(); foreach (var runtime in state.GetClientsSnapshot()) { if (runtime.RuntimePid is null) { runtime.Health = HealthState.Unbound; runtime.ConnectionState = ConnectionState.Unknown; } else { runtime.LastSeen = DateTimeOffset.UtcNow; if (runtime.Health is HealthState.Unbound or HealthState.Offline) runtime.Health = HealthState.Healthy; } } }
            catch (Exception error) { logger.LogError(error, "Process discovery failed"); }
            await Task.Delay(TimeSpan.FromSeconds(Math.Max(1, state.Settings.General.ProcessCheckIntervalSeconds)), stoppingToken);
        }
    }
}

public sealed class RecoveryHostedService(ApplicationState state, IClientProfileManager profiles, IClientInputQueueFactory queues, INetworkMonitor network, ILogger<RecoveryHostedService> logger) : BackgroundService {
    private Guid? _owner;
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
        while (!stoppingToken.IsCancellationRequested) {
            if (!state.Settings.Recovery.Enabled) { _owner = null; await Task.Delay(TimeSpan.FromSeconds(Math.Max(1, state.Settings.Recovery.NetworkPollSeconds)), stoppingToken); continue; }
            var now = DateTimeOffset.UtcNow; var active = state.GetClientsSnapshot().Where(x => x.RuntimePid.HasValue && x.FishingState is FishingState.Running or FishingState.Recovering).ToArray(); if (_owner is { } owner && active.All(x => x.ProfileId != owner)) _owner = null;
            try { var snapshot = network.GetEstablishedEndpoints(active.Select(x => x.RuntimePid!.Value), state.Settings.Recovery); foreach (var runtime in active) UpdateTelemetry(runtime, snapshot.GetValueOrDefault(runtime.RuntimePid!.Value) ?? [], now); foreach (var runtime in active) await AdvanceAsync(runtime, now, stoppingToken); }
            catch (Exception error) { foreach (var runtime in active) { runtime.NetworkTelemetryAvailable = false; runtime.RecoveryState = RecoveryState.TelemetryPaused; queues.Get(runtime.ProfileId).ClearAll(); } logger.LogError(error, "Network telemetry unavailable; recovery paused"); }
            await Task.Delay(TimeSpan.FromSeconds(Math.Max(1, state.Settings.Recovery.NetworkPollSeconds)), stoppingToken);
        }
    }
    private void UpdateTelemetry(ClientRuntime runtime, IReadOnlyList<string> endpoints, DateTimeOffset now) {
        runtime.NetworkTelemetryAvailable = true;
        if (runtime.NetworkBaseline.Count == 0) { if (endpoints.Count == 0) { runtime.ConnectionState = ConnectionState.Learning; runtime.RecoveryState = RecoveryState.Learning; return; } foreach (var endpoint in endpoints) runtime.NetworkBaseline.Add(endpoint); runtime.ConnectionState = ConnectionState.Connected; runtime.RecoveryState = RecoveryState.Monitoring; runtime.NetworkStableSince = now; return; }
        var connected = endpoints.Any(endpoint => runtime.NetworkBaseline.Contains(endpoint) || runtime.NetworkBaseline.Any(known => known.Split('|')[^1] == endpoint.Split('|')[^1]));
        if (connected) { foreach (var endpoint in endpoints) runtime.NetworkBaseline.Add(endpoint); runtime.ConnectionState = ConnectionState.Connected; runtime.NetworkLostSince = null; runtime.NetworkStableSince ??= now; }
        else { runtime.NetworkStableSince = null; runtime.NetworkLostSince ??= now; runtime.ConnectionState = ConnectionState.SuspectedDisconnect; }
    }
    private async Task AdvanceAsync(ClientRuntime runtime, DateTimeOffset now, CancellationToken token) {
        if (!state.Settings.Recovery.Enabled) return; var settings = state.Settings.Recovery;
        var confirmedLoss = runtime.NetworkLostSince is { } lost && (now - lost).TotalSeconds >= settings.DisconnectConfirmSeconds;
        var fallback = settings.FallbackToNoBiteOnly && runtime.NetworkBaseline.Count == 0 && runtime.NoBiteStreak >= state.Settings.General.NoBiteStreakLimit;
        if (runtime.RecoveryState is RecoveryState.Monitoring or RecoveryState.Learning && (confirmedLoss || fallback)) { runtime.RecoveryState = RecoveryState.WaitingSlot; runtime.ConnectionState = ConnectionState.Disconnected; queues.Get(runtime.ProfileId).ClearFishing(); }
        var actionPlanComplete = runtime.Recovery.StepIndex >= settings.ActionPlan.Count;
        if (runtime.ConnectionState == ConnectionState.Connected && runtime.RecoveryState is not RecoveryState.Monitoring and not RecoveryState.Learning && (runtime.FishingState != FishingState.Recovering || actionPlanComplete)) { runtime.RecoveryState = RecoveryState.Stabilizing; runtime.NetworkStableSince ??= now; }
        switch (runtime.RecoveryState) {
            case RecoveryState.WaitingSlot:
                if (_owner is null) { _owner = runtime.ProfileId; runtime.Recovery.AttemptCount++; runtime.Recovery.StepIndex = 0; runtime.Recovery.LastAttempt = now; runtime.RecoveryState = RecoveryState.Recovering; runtime.FishingState = FishingState.Recovering; }
                break;
            case RecoveryState.Recovering:
                if (_owner != runtime.ProfileId) { runtime.RecoveryState = RecoveryState.WaitingSlot; break; }
                if (runtime.Recovery.StepIndex >= settings.ActionPlan.Count) { BackoffOrManual(runtime, now); break; }
                var step = settings.ActionPlan[runtime.Recovery.StepIndex]; var profile = profiles.Profiles.First(x => x.ProfileId == runtime.ProfileId);
                if (step.Type.Equals("Password", StringComparison.OrdinalIgnoreCase) && (!settings.AllowPasswordTyping || state.Settings.General.UseSerialInput || string.IsNullOrWhiteSpace(profile.EncryptedPassword) && string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("AIFISHBOT_WOW_PASSWORD")))) { if (_owner == runtime.ProfileId) _owner = null; runtime.RecoveryState = RecoveryState.ManualIntervention; runtime.ConnectionState = ConnectionState.ManualIntervention; runtime.Health = HealthState.Error; runtime.LastError = "Automatic reconnect needs password typing enabled and a saved profile password."; break; }
                await queues.Get(runtime.ProfileId).EnqueueAsync(new InputCommand { ProfileId = runtime.ProfileId, Priority = InputPriority.Recovery, Action = step.Type.Equals("Password", StringComparison.OrdinalIgnoreCase) ? "Password" : "Key", Key = step.Key, WaitAfterSeconds = step.WaitForConnectionSeconds }, token);
                runtime.RecoveryState = RecoveryState.Waiting; runtime.Recovery.Deadline = now.AddSeconds(Math.Max(step.WaitForConnectionSeconds, 1)); break;
            case RecoveryState.Waiting:
                if (runtime.Recovery.Deadline is { } deadline && now >= deadline) { runtime.Recovery.StepIndex++; runtime.RecoveryState = RecoveryState.Recovering; }
                break;
            case RecoveryState.Backoff:
                if (runtime.Recovery.NextAttempt is { } retry && now >= retry) runtime.RecoveryState = RecoveryState.WaitingSlot;
                break;
            case RecoveryState.Stabilizing:
                if (runtime.NetworkStableSince is { } stable && (now - stable).TotalSeconds >= settings.StableConnectionSeconds) { runtime.RecoveryState = RecoveryState.Monitoring; runtime.ConnectionState = ConnectionState.Connected; runtime.Recovery = new RecoveryAttempt(); runtime.FishingState = FishingState.Running; runtime.FishingPhase = FishingPhase.NeedCast; runtime.NextActionAt = now.AddSeconds(1); if (_owner == runtime.ProfileId) _owner = null; }
                break;
            case RecoveryState.TelemetryPaused:
                if (runtime.NetworkTelemetryAvailable == true) runtime.RecoveryState = runtime.ConnectionState == ConnectionState.Connected ? RecoveryState.Stabilizing : RecoveryState.WaitingSlot;
                break;
        }
    }
    private void BackoffOrManual(ClientRuntime runtime, DateTimeOffset now) {
        if (_owner == runtime.ProfileId) _owner = null;
        if (runtime.Recovery.AttemptCount >= state.Settings.Recovery.MaxAttempts) { runtime.RecoveryState = RecoveryState.ManualIntervention; runtime.ConnectionState = ConnectionState.ManualIntervention; runtime.Health = HealthState.Error; runtime.LastError = $"Reconnect failed after {runtime.Recovery.AttemptCount} attempts."; return; }
        var index = Math.Min(runtime.Recovery.AttemptCount - 1, state.Settings.Recovery.BackoffSeconds.Length - 1); var delay = index >= 0 ? state.Settings.Recovery.BackoffSeconds[index] : 15; runtime.Recovery.NextAttempt = now.AddSeconds(delay); runtime.RecoveryState = RecoveryState.Backoff;
    }
}

public sealed class FishingEngineHostedService(ApplicationState state, IClientProfileManager profiles, IClientInputQueueFactory queues, IAudioPeakService audio, ILogger<FishingEngineHostedService> logger) : BackgroundService {
    private readonly Dictionary<(Guid ProfileId, int BuffId), DateTimeOffset> _nextBuff = [];
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
        while (!stoppingToken.IsCancellationRequested) {
            var now = DateTimeOffset.UtcNow; var active = state.GetClientsSnapshot().Where(x => x.RuntimePid.HasValue && x.FishingState == FishingState.Running && !x.IsLootSyncing).ToArray();
            var awaiting = active.Where(x => x.FishingPhase == FishingPhase.AwaitingBite && now >= x.NextActionAt && now <= x.CastDeadline).ToArray();
            var peaks = !state.Settings.Audio.Enabled || awaiting.Length == 0 ? new Dictionary<int, float>() : audio.GetPeaks(awaiting.Select(x => x.RuntimePid!.Value));
            foreach (var runtime in active) try { await TickAsync(runtime, peaks, now, stoppingToken); } catch (Exception error) { runtime.LastError = error.Message; logger.LogError(error, "Fishing tick failed for ProfileId={ProfileId}", runtime.ProfileId); }
            await Task.Delay(Math.Max(20, state.Settings.Audio.Enabled ? state.Settings.Audio.PollIntervalMilliseconds : state.Settings.Gui.MonitorIntervalMilliseconds), stoppingToken);
        }
    }
    private async Task TickAsync(ClientRuntime runtime, IReadOnlyDictionary<int, float> peaks, DateTimeOffset now, CancellationToken token) {
        var profile = profiles.Profiles.First(x => x.ProfileId == runtime.ProfileId); var queue = queues.Get(runtime.ProfileId);
        await UpdateBuffs(profile, queue, now, token);
        if (now < runtime.NextActionAt) return;
        switch (runtime.FishingPhase) {
            case FishingPhase.NeedCast: await queue.EnqueueAsync(new InputCommand { ProfileId = runtime.ProfileId, Priority = InputPriority.Cast, Action = "Cast" }, token); runtime.FishingPhase = FishingPhase.Casting; break;
            case FishingPhase.AwaitingBite:
                if (state.Settings.Audio.Enabled && runtime.RuntimePid is { } pid && peaks.TryGetValue(pid, out var peak) && peak >= state.Settings.Audio.Sensitivity * 10) runtime.FishingPhase = FishingPhase.ClickBobber;
                else if (now > runtime.CastDeadline) { runtime.NoBiteStreak++; runtime.CastRetryCount++; runtime.FishingPhase = FishingPhase.NeedCast; if (state.Settings.General.UseWeakAura && runtime.CastRetryCount >= state.Settings.General.FishingRetries) { runtime.CastRetryCount = 0; runtime.NextActionAt = now.AddSeconds(3); } else runtime.NextActionAt = now; }
                break;
            case FishingPhase.ClickBobber: runtime.FishingPhase = FishingPhase.Casting; await queue.EnqueueAsync(new InputCommand { ProfileId = runtime.ProfileId, Priority = InputPriority.Bobber, Action = "Bobber" }, token); break;
            case FishingPhase.PostCatch: runtime.FishingPhase = FishingPhase.NeedCast; runtime.NextActionAt = now; break;
        }
    }
    private async Task UpdateBuffs(ClientProfile profile, IInputQueue queue, DateTimeOffset now, CancellationToken token) {
        foreach (var buff in profile.Buffs.Entries.Where(x => x.Enabled && !string.IsNullOrWhiteSpace(x.Key))) { var key = (profile.ProfileId, buff.Id); if (_nextBuff.TryGetValue(key, out var next) && next > now) continue; await queue.EnqueueAsync(new InputCommand { ProfileId = profile.ProfileId, Priority = InputPriority.Buff, Action = "Buff", Key = buff.Key }, token); _nextBuff[key] = now + buff.CastTime + buff.Duration; }
    }
}
