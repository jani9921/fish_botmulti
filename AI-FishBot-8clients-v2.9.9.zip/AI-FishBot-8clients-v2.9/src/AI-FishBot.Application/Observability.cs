using AIFishBot.Core;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace AIFishBot.Application;

public sealed class ReportHostedService(ApplicationState state, IReportService reports, ILogger<ReportHostedService> logger) : BackgroundService {
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) { try { while (!stoppingToken.IsCancellationRequested) { await reports.WriteSnapshotAsync(state, stoppingToken); await Task.Delay(TimeSpan.FromSeconds(Math.Max(5, state.Settings.Gui.ReportIntervalSeconds)), stoppingToken); } } catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { logger.LogDebug("Report service cancellation received"); } finally { await reports.WriteFinalSummaryAsync(state); logger.LogInformation("Final session report written"); } }
}

public sealed class AnomalyHostedService(ApplicationState state, IClientProfileManager profiles) : BackgroundService {
    private readonly Dictionary<string, DateTimeOffset> _lastAlert = new(StringComparer.Ordinal);
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
        while (!stoppingToken.IsCancellationRequested) {
            var now = DateTimeOffset.UtcNow; var runtimes = state.GetClientsSnapshot(); var rates = runtimes.Where(x => x.Session is { ActiveTimeSeconds: >= 540 }).Select(x => x.Session!.HookCount / Math.Max(x.Session.ActiveTimeSeconds / 3600d, .0001)).Where(x => x > 0).ToArray(); var averageRate = rates.Length == 0 ? 0 : rates.Average();
            foreach (var runtime in runtimes) {
                var profile = profiles.Profiles.FirstOrDefault(x => x.ProfileId == runtime.ProfileId); if (profile is null) continue;
                if (runtime.RuntimePid is null) Alert(runtime.ProfileId, "Offline", "A profil nincs futó WoW processzhez kötve.", now, 60);
                if (runtime.LastActivity is { } activity && runtime.FishingState == FishingState.Running && (now - activity).TotalMinutes >= state.Settings.General.NoCatchWarningMinutes) Alert(runtime.ProfileId, "Warning", $"Nincs fogási esemény {(now - activity).TotalMinutes:N0} perce.", now, 10);
                if (runtime.LastLootReadError is not null) Alert(runtime.ProfileId, "Warning", runtime.LastLootReadError, now, 10);
                if (runtime.LootAddonVersion is not "-" && runtime.LootAddonVersion != state.Settings.Loot.RequiredAddonVersion) Alert(runtime.ProfileId, "Warning", $"Loot addon verzió: {runtime.LootAddonVersion}; szükséges: {state.Settings.Loot.RequiredAddonVersion}.", now, 60);
                if (runtime.RecoveryState == RecoveryState.Learning && runtime.Session is { } learningSession && (now - learningSession.StartedAt).TotalSeconds >= state.Settings.Recovery.NetworkLearnTimeoutSeconds) Alert(runtime.ProfileId, "Warning", "A WoW szerverkapcsolata nem tanulható meg; az automatikus recovery biztonságosan tiltva marad.", now, 60);
                if (runtime.FirstUnsyncedCatchAt is { } unsynced && (now - unsynced).TotalMinutes >= state.Settings.Loot.MaxUnsyncedMinutes + 2) Alert(runtime.ProfileId, "Warning", $"Loot sync késik; {runtime.PendingLootHooks} esemény vár feldolgozásra.", now, 10);
                if (runtime.LastSuccessfulLootRead is { } lastLoot && (now - lastLoot).TotalMinutes >= 60) Alert(runtime.ProfileId, "Warning", "A loot SavedVariables legalább 60 perce nem frissült.", now, 60);
                if (averageRate > 0 && runtime.Session is { ActiveTimeSeconds: >= 540 } session) { var rate = session.HookCount / Math.Max(session.ActiveTimeSeconds / 3600d, .0001); if (rate < averageRate * state.Settings.General.FishRateDropThresholdPercent / 100d) Alert(runtime.ProfileId, "Warning", "A fish/hour érték a többklienses átlag alatt van.", now, 10); }
                runtime.Health = runtime.RuntimePid is null ? HealthState.Unbound : runtime.LastError is not null || runtime.LastInputError is not null ? HealthState.Error : runtime.LastLootReadError is not null || runtime.RecoveryState is RecoveryState.Backoff or RecoveryState.TelemetryPaused ? HealthState.Warning : HealthState.Healthy;
            }
            await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
        }
    }
    private void Alert(Guid profileId, string severity, string message, DateTimeOffset now, int throttleMinutes) { var key = $"{profileId}|{message}"; if (_lastAlert.TryGetValue(key, out var last) && (now - last).TotalMinutes < throttleMinutes) return; _lastAlert[key] = now; state.AddAlert(new AlertEntry { ProfileId = profileId, Severity = severity, Message = message }); }
}
