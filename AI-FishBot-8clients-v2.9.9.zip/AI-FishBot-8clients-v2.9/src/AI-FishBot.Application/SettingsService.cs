using AIFishBot.Core;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace AIFishBot.Application;

public sealed class SettingsService(IProfileStore store, ILogger<SettingsService>? logger = null) : ISettingsService {
    private readonly SemaphoreSlim _saveGate = new(1, 1);
    private CancellationTokenSource? _debounce;
    public ApplicationSettings Current { get; private set; } = new();
    public async Task<ApplicationSettings> LoadAsync(CancellationToken token = default) {
        Current = await store.LoadAsync(token);
        if (Current.SchemaVersion < 4) {
            Current.Recovery.ActionPlan = RecoveryConfiguration.CreateDefaultActionPlan();
            Current.SchemaVersion = 4;
            await store.SaveAsync(Current, token);
            logger?.LogInformation("Settings upgraded to schema 4 with the deterministic reconnect input sequence.");
        }
        return Current;
    }
    public async Task SaveAsync(CancellationToken token = default) { await _saveGate.WaitAsync(token); try { await store.SaveAsync(CreateSnapshot(), token); } finally { _saveGate.Release(); } }
    public void ScheduleSave() { var next = new CancellationTokenSource(); var previous = Interlocked.Exchange(ref _debounce, next); previous?.Cancel(); previous?.Dispose(); _ = DebouncedSaveAsync(next.Token); }
    private async Task DebouncedSaveAsync(CancellationToken token) { try { await Task.Delay(TimeSpan.FromSeconds(1), token); await SaveAsync(token); } catch (OperationCanceledException) when (token.IsCancellationRequested) { logger?.LogDebug("Debounced settings save was superseded or canceled"); } catch (Exception error) { logger?.LogError(error, "Debounced settings save failed"); } }
    public async ValueTask DisposeAsync() { var pending = Interlocked.Exchange(ref _debounce, null); pending?.Cancel(); pending?.Dispose(); await SaveAsync(); _saveGate.Dispose(); }
    private ApplicationSettings CreateSnapshot() { var statistics = Current.Profiles.Select(x => x.LifetimeStatistics).Distinct().OrderBy(x => System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(x)).ToArray(); foreach (var item in statistics) Monitor.Enter(item); try { var bytes = JsonSerializer.SerializeToUtf8Bytes(Current); return JsonSerializer.Deserialize<ApplicationSettings>(bytes) ?? throw new InvalidDataException("Settings snapshot serialization returned null."); } finally { for (var index = statistics.Length - 1; index >= 0; index--) Monitor.Exit(statistics[index]); } }
}
