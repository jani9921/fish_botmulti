using AIFishBot.Core;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace AIFishBot.Application;

public sealed class RevenueService(ApplicationState state, IPriceService prices) : IRevenueService {
    public ClientStatistics Calculate(ClientStatistics statistics, double activeHours) {
        lock (statistics) { decimal gold = 0; decimal sessionGold = 0; foreach (var pair in statistics.Items) { statistics.ItemIds.TryGetValue(pair.Key, out var id); var unit = prices.GetUnitPriceGold(new LootItem { Name = pair.Key, Count = pair.Value, ItemId = id > 0 ? id : null }); if (unit is { } amount) gold += amount * pair.Value; } foreach (var pair in statistics.SessionItems) { statistics.ItemIds.TryGetValue(pair.Key, out var id); var unit = prices.GetUnitPriceGold(new LootItem { Name = pair.Key, Count = pair.Value, ItemId = id > 0 ? id : null }); if (unit is { } amount) sessionGold += amount * pair.Value; } var euro = state.Settings.Revenue.GoldPerEuro > 0 ? gold / state.Settings.Revenue.GoldPerEuro : 0; var huf = euro * state.Settings.Revenue.EurToHuf; var sessionHuf = state.Settings.Revenue.GoldPerEuro > 0 ? sessionGold / state.Settings.Revenue.GoldPerEuro * state.Settings.Revenue.EurToHuf : 0; statistics.RevenueGold = gold; statistics.RevenueEur = euro; statistics.RevenueHuf = huf; statistics.GoldPerHour = activeHours > 0 ? sessionGold / (decimal)activeHours : 0; statistics.HufPerHour = activeHours > 0 ? sessionHuf / (decimal)activeHours : 0; return statistics; }
    }
    public TargetProgress GetTargetProgress(ClientProfile profile, ClientStatistics statistics) { var target = Math.Max(profile.Target.TargetAmount, 0); var current = profile.Target.Currency.Equals("GOLD", StringComparison.OrdinalIgnoreCase) ? statistics.RevenueGold : statistics.RevenueHuf; var remaining = Math.Max(target - current, 0); var hourly = profile.Target.Currency.Equals("GOLD", StringComparison.OrdinalIgnoreCase) ? statistics.GoldPerHour : statistics.HufPerHour; return new TargetProgress { Current = current, Target = target, Remaining = remaining, Percent = target > 0 ? (double)Math.Min(current / target * 100, 100) : 0, Eta = hourly > 0 ? TimeSpan.FromHours((double)(remaining / hourly)) : null, Reached = profile.Target.Enabled && target > 0 && current >= target }; }
    public bool TryMarkTargetReached(ClientProfile profile, TargetProgress progress) { if (profile.Target.LastNotifiedTargetAmount != profile.Target.TargetAmount) { profile.Target.ReachedNotified = false; profile.Target.LastNotifiedTargetAmount = profile.Target.TargetAmount; } if (!progress.Reached || profile.Target.ReachedNotified) return false; profile.Target.ReachedNotified = true; return true; }
}

public sealed class PriceHostedService(ApplicationState state, IClientProfileManager profiles, IPriceService prices, ILogger<PriceHostedService> logger) : BackgroundService {
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
        while (!stoppingToken.IsCancellationRequested) {
            try { var ids = profiles.Profiles.SelectMany(x => x.LifetimeStatistics.ItemIds.Values).Where(x => x > 0).Distinct(); await prices.RefreshAsync(ids, stoppingToken); }
            catch (Exception error) { logger.LogWarning(error, "Blizzard price refresh failed"); }
            await Task.Delay(TimeSpan.FromMinutes(Math.Max(1, state.Settings.Price.BlizzardRetryMinutes)), stoppingToken);
        }
    }
}

public sealed class MetricsHostedService(ApplicationState state, IClientProfileManager profiles, IRevenueService revenue, IClientController controller, IClientInputQueueFactory queues, ISettingsService settings, ILogger<MetricsHostedService> logger) : BackgroundService {
    private DateTimeOffset _lastTick = DateTimeOffset.UtcNow;
    protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
        while (!stoppingToken.IsCancellationRequested) {
            var now = DateTimeOffset.UtcNow; var delta = Math.Clamp((now - _lastTick).TotalSeconds, 0, 5); _lastTick = now;
            foreach (var profile in profiles.Profiles) {
                var runtime = state.GetClientsSnapshot().FirstOrDefault(x => x.ProfileId == profile.ProfileId); if (runtime?.Session is not { } session) continue;
                if (runtime.FishingState is FishingState.Paused or FishingState.Stopped or FishingState.Recovering || runtime.Health is HealthState.Offline or HealthState.Error) session.PausedTimeSeconds += delta; else if (runtime.IsLootSyncing) session.ReloadTimeSeconds += delta; else session.ActiveTimeSeconds += delta;
                profile.LifetimeStatistics.ActiveTimeSeconds = session.ActiveTimeSeconds; session.Statistics.ActiveTimeSeconds = session.ActiveTimeSeconds; profile.LifetimeStatistics = revenue.Calculate(profile.LifetimeStatistics, session.ActiveTimeSeconds / 3600d); var target = revenue.GetTargetProgress(profile, profile.LifetimeStatistics);
                if (revenue.TryMarkTargetReached(profile, target)) { if (profile.Target.NotifyOnReached) state.AddAlert(new AlertEntry { ProfileId = profile.ProfileId, Severity = "Info", Message = $"Target reached: {target.Current:N0} {profile.Target.Currency}" }); settings.ScheduleSave(); if (profile.Target.StopOnReached) await controller.StopAsync(profile.ProfileId, stoppingToken); }
                if (state.Settings.General.AutoStop && (now - session.StartedAt).TotalMinutes >= state.Settings.General.AutoStopMinutes) { if (state.Settings.General.AutoLogout) { await queues.Get(profile.ProfileId).EnqueueAsync(new InputCommand { ProfileId = profile.ProfileId, Priority = InputPriority.Maintenance, Action = "Logout" }, stoppingToken); await Task.Delay(250, stoppingToken); } await controller.StopAsync(profile.ProfileId, stoppingToken); }
            }
            state.TrimAlerts(state.Settings.Gui.AlertHistoryLimit); await Task.Delay(1000, stoppingToken);
        }
        logger.LogInformation("Metrics service stopped cleanly");
    }
}
