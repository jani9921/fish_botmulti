using System.IO;
using System.Net.Http;
using System.Windows;
using AIFishBot.Application;
using AIFishBot.Core;
using AIFishBot.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace AIFishBot.App;

public partial class App : System.Windows.Application {
    private IHost? _host;
    protected override async void OnStartup(StartupEventArgs e) {
        base.OnStartup(e);
        var dataDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AI-FishBot");
        _host = Host.CreateDefaultBuilder().ConfigureLogging((_, logging) => logging.ClearProviders()).ConfigureServices(services => {
            services.AddSingleton<ApplicationState>(); services.AddSingleton<IProfileStore>(provider => new JsonProfileStore(dataDirectory, provider.GetRequiredService<ILogger<JsonProfileStore>>())); services.AddSingleton<ISecretProtector, DpapiSecretProtector>(); services.AddSingleton<ISettingsService, SettingsService>(); services.AddSingleton<IV2MigrationService, V2MigrationService>();
            services.AddSingleton<ISettingsValidator, SettingsValidator>(); services.AddSingleton<IClientProfileManager>(provider => new ClientProfileManager(provider.GetRequiredService<ISettingsService>(), provider.GetRequiredService<ApplicationState>())); services.AddSingleton<IProcessDiscoveryService, WindowsProcessDiscoveryService>(); services.AddSingleton<IProfileBindingService, ProfileBindingService>(); services.AddSingleton<IClientInputQueueFactory, ClientInputQueueFactory>(); services.AddSingleton<ISerialInputSender, SerialInputSender>(); services.AddSingleton<IInputExecutor, WindowsInputExecutor>();
            services.AddSingleton<IAudioPeakService, NAudioPeakService>(); services.AddSingleton<INetworkMonitor, WindowsNetworkMonitor>(); services.AddSingleton<ISavedVariablesLocator, SavedVariablesLocator>(); services.AddSingleton<ILootDataParser, LuaSavedVariablesParser>(); services.AddSingleton<ISavedVariablesReader>(provider => (LuaSavedVariablesParser)provider.GetRequiredService<ILootDataParser>()); services.AddSingleton<IStatisticsService, StatisticsEngine>(); services.AddSingleton<IClientController, ClientController>();
            services.AddHttpClient("Blizzard"); services.AddSingleton<IPriceService>(provider => new BlizzardPriceService(provider.GetRequiredService<IHttpClientFactory>().CreateClient("Blizzard"), provider.GetRequiredService<ApplicationState>(), provider.GetRequiredService<ISecretProtector>(), provider.GetRequiredService<ILogger<BlizzardPriceService>>())); services.AddSingleton<IRevenueService, RevenueService>(); services.AddSingleton<IReportService, ReportService>(); services.AddSingleton<ILoggerProvider, JsonFileLoggerProvider>();
            services.AddHostedService<ProcessMonitorHostedService>(); services.AddHostedService<InputWorkerHostedService>(); services.AddHostedService<FishingEngineHostedService>(); services.AddHostedService<LootMonitorHostedService>(); services.AddHostedService<RecoveryHostedService>(); services.AddHostedService<PriceHostedService>(); services.AddHostedService<MetricsHostedService>(); services.AddHostedService<AnomalyHostedService>(); services.AddHostedService<ReportHostedService>();
            services.AddSingleton<MainViewModel>(); services.AddSingleton<MainWindow>();
        }).Build();
        try {
            var settings = _host.Services.GetRequiredService<ISettingsService>(); var loaded = await settings.LoadAsync(); var state = _host.Services.GetRequiredService<ApplicationState>(); state.Settings = loaded;
            var v2Path = FindV2Settings(); if (v2Path is not null) { var migrated = await _host.Services.GetRequiredService<IV2MigrationService>().TryMigrateAsync(v2Path, Path.Combine(dataDirectory, "backup"), loaded); if (migrated) await settings.SaveAsync(); }
            await _host.Services.GetRequiredService<IClientProfileManager>().LoadProfilesAsync(); var validationErrors = _host.Services.GetRequiredService<ISettingsValidator>().Validate(state.Settings); if (validationErrors.Count > 0) throw new InvalidDataException(string.Join(Environment.NewLine, validationErrors)); _host.Services.GetRequiredService<IProfileBindingService>().RefreshBindings();
            await _host.StartAsync(); var controller = _host.Services.GetRequiredService<IClientController>(); var startupLogger = _host.Services.GetRequiredService<ILogger<App>>(); foreach (var profile in _host.Services.GetRequiredService<IClientProfileManager>().Profiles.Where(x => x.StartAutomatically)) { try { await controller.StartAsync(profile.ProfileId); } catch (InvalidOperationException error) { startupLogger.LogWarning(error, "Automatic start skipped for ProfileId={ProfileId}", profile.ProfileId); } } var window = _host.Services.GetRequiredService<MainWindow>(); MainWindow = window; window.Show();
        } catch (Exception error) { MessageBox.Show($"Az AI-FishBot nem indítható:\n{error.Message}", "AI-FishBot V3", MessageBoxButton.OK, MessageBoxImage.Error); Shutdown(1); }
    }
    protected override async void OnExit(ExitEventArgs e) { if (_host is not null) { await _host.StopAsync(TimeSpan.FromSeconds(10)); if (_host is IAsyncDisposable asynchronousHost) await asynchronousHost.DisposeAsync(); else _host.Dispose(); } base.OnExit(e); }
    private static string? FindV2Settings() { var names = new[] { Path.Combine(AppContext.BaseDirectory, "ai-fishbot-settings.json"), Path.Combine(Environment.CurrentDirectory, "ai-fishbot-settings.json"), Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "ai-fishbot-settings.json")) }; return names.FirstOrDefault(File.Exists); }
}
