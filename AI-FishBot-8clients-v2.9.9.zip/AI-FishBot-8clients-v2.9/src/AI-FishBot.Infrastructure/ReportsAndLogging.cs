using System.Collections.Concurrent;
using System.Globalization;
using System.Text;
using System.Text.Json;
using AIFishBot.Core;
using Microsoft.Extensions.Logging;

namespace AIFishBot.Infrastructure;

public sealed class ReportService : IReportService {
    private readonly ApplicationState _state; private readonly string _sessionId = DateTimeOffset.Now.ToString("yyyy-MM-dd_HHmmss", CultureInfo.InvariantCulture); private readonly SemaphoreSlim _gate = new(1, 1);
    public ReportService(ApplicationState state) { _state = state; }
    public async Task WriteCatchAsync(ClientProfile profile, ClientRuntime runtime, CancellationToken token = default) { if (!_state.Settings.Logging.Enabled || !_state.Settings.Loot.CatchJournalEnabled) return; var row = new[] { DateTimeOffset.Now.ToString("O"), profile.ProfileId.ToString(), runtime.RuntimePid?.ToString(CultureInfo.InvariantCulture) ?? "", "BobberClick", runtime.Session?.HookCount.ToString(CultureInfo.InvariantCulture) ?? "0", runtime.PendingLootHooks.ToString(CultureInfo.InvariantCulture), runtime.LootSyncState }; await AppendCsvAsync(PathFor($"catches_{_sessionId}.csv"), "Timestamp,ProfileId,RuntimePid,Event,SessionHooks,PendingHooks,LootSyncState", row, token); }
    public async Task WriteSnapshotAsync(ApplicationState state, CancellationToken token = default) { if (!state.Settings.Logging.Enabled) return; foreach (var runtime in state.GetClientsSnapshot()) { var profile = state.Settings.Profiles.FirstOrDefault(x => x.ProfileId == runtime.ProfileId); if (profile is null) continue; var stats = profile.LifetimeStatistics; var row = new[] { DateTimeOffset.Now.ToString("O"), profile.ProfileId.ToString(), runtime.RuntimePid?.ToString(CultureInfo.InvariantCulture) ?? "", runtime.FishingState.ToString(), runtime.ConnectionState.ToString(), runtime.RecoveryState.ToString(), runtime.Health.ToString(), runtime.LootSyncState, runtime.LootAddonVersion, runtime.PendingLootHooks.ToString(CultureInfo.InvariantCulture), stats.SessionLoot.ToString(CultureInfo.InvariantCulture), stats.SessionWyrmfish.ToString(CultureInfo.InvariantCulture), stats.WyrmfishPerHour.ToString(CultureInfo.InvariantCulture), stats.RevenueGold.ToString(CultureInfo.InvariantCulture), stats.RevenueHuf.ToString(CultureInfo.InvariantCulture), stats.HufPerHour.ToString(CultureInfo.InvariantCulture) }; await AppendCsvAsync(PathFor($"session_{_sessionId}.csv"), "Timestamp,ProfileId,RuntimePid,FishingState,ConnectionState,RecoveryState,Health,LootSyncState,LootAddonVersion,PendingHooks,SessionLoot,SessionWyrmfish,WyrmfishPerHour,RevenueGold,RevenueHuf,HufPerHour", row, token); } }
    public async Task WriteFinalSummaryAsync(ApplicationState state, CancellationToken token = default) { if (!state.Settings.Logging.Enabled) return; var summary = new { SessionId = _sessionId, SessionEnd = DateTimeOffset.Now, Global = state.GlobalStatistics, Clients = state.GetClientsSnapshot().Select(runtime => { var profile = state.Settings.Profiles.FirstOrDefault(x => x.ProfileId == runtime.ProfileId); return new { runtime.ProfileId, profile?.DisplayName, runtime.RuntimePid, runtime.FishingState, runtime.ConnectionState, runtime.RecoveryState, runtime.Health, runtime.LootSyncState, runtime.LootAddonVersion, runtime.LastSuccessfulLootRead, runtime.LastLootReadError, Statistics = profile?.LifetimeStatistics, Session = runtime.Session }; }), Alerts = state.GetAlertsSnapshot() }; await AtomicWriteAsync(PathFor($"session_{_sessionId}.json"), JsonSerializer.Serialize(summary, new JsonSerializerOptions { WriteIndented = true }), token); }
    private string PathFor(string name) { var configured = _state.Settings.Logging.Directory; var directory = Path.IsPathRooted(configured) ? configured : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AI-FishBot", configured); Directory.CreateDirectory(directory); return Path.Combine(directory, name); }
    private async Task AppendCsvAsync(string path, string header, IEnumerable<string> values, CancellationToken token) { await _gate.WaitAsync(token); try { var exists = File.Exists(path); await using var stream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read, 4096, FileOptions.Asynchronous); await using var writer = new StreamWriter(stream, new UTF8Encoding(false)); if (!exists) await writer.WriteLineAsync(header.AsMemory(), token); await writer.WriteLineAsync(string.Join(',', values.Select(Escape)).AsMemory(), token); } finally { _gate.Release(); } }
    private static string Escape(string value) => value.IndexOfAny([',', '"', '\r', '\n']) < 0 ? value : $"\"{value.Replace("\"", "\"\"")}\"";
    private static async Task AtomicWriteAsync(string path, string content, CancellationToken token) { var temp = path + ".tmp"; await File.WriteAllTextAsync(temp, content, new UTF8Encoding(false), token); File.Move(temp, path, true); }
}

public sealed class JsonFileLoggerProvider(ApplicationState state) : ILoggerProvider {
    private readonly ConcurrentDictionary<string, JsonFileLogger> _loggers = new();
    public ILogger CreateLogger(string categoryName) => _loggers.GetOrAdd(categoryName, category => new JsonFileLogger(category, state));
    public void Dispose() => _loggers.Clear();
    private sealed class JsonFileLogger(string category, ApplicationState state) : ILogger {
        private static readonly object Gate = new();
        private static readonly ConcurrentDictionary<string, DateTimeOffset> LastError = new(StringComparer.Ordinal);
        public IDisposable? BeginScope<TState>(TState stateValue) where TState : notnull => null;
        public bool IsEnabled(LogLevel logLevel) => state.Settings.Logging.Enabled && (state.Settings.Logging.Debug || logLevel >= LogLevel.Information);
        public void Log<TState>(LogLevel level, EventId eventId, TState value, Exception? exception, Func<TState, Exception?, string> formatter) {
            if (!IsEnabled(level)) return; var message = formatter(value, exception); if (message.Contains("password", StringComparison.OrdinalIgnoreCase) || message.Contains("secret", StringComparison.OrdinalIgnoreCase)) message = "[REDACTED SENSITIVE LOG MESSAGE]"; if (level >= LogLevel.Error) { var key = $"{category}|{exception?.GetType().FullName}|{message}"; var now = DateTimeOffset.UtcNow; if (LastError.TryGetValue(key, out var last) && (now - last).TotalSeconds < state.Settings.Logging.ErrorThrottleSeconds) return; LastError[key] = now; }
            var entry = JsonSerializer.Serialize(new { Timestamp = DateTimeOffset.Now, Level = level.ToString(), Module = category, EventId = eventId.Id, Message = message, Exception = exception?.GetType().Name }); var configured = state.Settings.Logging.Directory; var directory = Path.IsPathRooted(configured) ? configured : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AI-FishBot", configured); Directory.CreateDirectory(directory); lock (Gate) File.AppendAllText(Path.Combine(directory, $"session_{DateTime.Now:yyyy-MM-dd}.log"), entry + Environment.NewLine, new UTF8Encoding(false));
        }
    }
}
