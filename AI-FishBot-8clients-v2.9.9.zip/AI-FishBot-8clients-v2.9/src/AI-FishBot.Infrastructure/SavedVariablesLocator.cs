using AIFishBot.Core;

namespace AIFishBot.Infrastructure;

public sealed class SavedVariablesLocator : ISavedVariablesLocator {
    public IReadOnlyList<string> FindCandidates(ClientProfile profile, string wowExecutablePath) {
        if (string.IsNullOrWhiteSpace(wowExecutablePath)) return [];
        var clientDirectory = Path.GetDirectoryName(Path.GetFullPath(wowExecutablePath)); if (clientDirectory is null) return [];
        var accountRoot = Path.Combine(clientDirectory, "WTF", "Account"); if (!Directory.Exists(accountRoot)) return [];
        var candidates = Directory.GetFiles(accountRoot, "AIFishLootTracker.lua", SearchOption.AllDirectories).OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToArray();
        if (candidates.Length <= 1) return candidates;
        var filtered = candidates.AsEnumerable(); var constrained = false;
        if (!string.IsNullOrWhiteSpace(profile.AccountIdentifier)) { constrained = true; filtered = filtered.Where(x => HasPathSegment(x, profile.AccountIdentifier)); }
        if (!string.IsNullOrWhiteSpace(profile.CharacterIdentifier)) { constrained = true; filtered = filtered.Where(x => HasPathSegment(x, profile.CharacterIdentifier)); }
        var matches = filtered.ToArray(); return constrained ? matches : candidates;
    }
    private static bool HasPathSegment(string path, string identifier) => path.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar).Any(segment => segment.Equals(identifier.Trim(), StringComparison.OrdinalIgnoreCase));
}
