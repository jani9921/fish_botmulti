using System.Collections.Concurrent;
using AIFishBot.Core;

namespace AIFishBot.Infrastructure;

public sealed class ClientInputQueue : IInputQueue {
    private readonly PriorityQueue<InputCommand, int> _queue = new(); private readonly SemaphoreSlim _signal = new(0); private readonly HashSet<string> _pending = new(StringComparer.Ordinal); private readonly HashSet<string> _queued = new(StringComparer.Ordinal); private readonly object _gate = new(); private bool _disposed;
    public int Count { get { lock (_gate) return _queue.Count; } }
    public ValueTask EnqueueAsync(InputCommand command, CancellationToken token = default) { token.ThrowIfCancellationRequested(); if (_disposed) throw new ObjectDisposedException(nameof(ClientInputQueue)); var key = DedupeKey(command); lock (_gate) { if (!_pending.Add(key)) return ValueTask.CompletedTask; _queued.Add(key); _queue.Enqueue(command, -(int)command.Priority); } _signal.Release(); return ValueTask.CompletedTask; }
    public ValueTask RequeueAsync(InputCommand command, CancellationToken token = default) { token.ThrowIfCancellationRequested(); if (_disposed) throw new ObjectDisposedException(nameof(ClientInputQueue)); lock (_gate) { var key = DedupeKey(command); if (!_pending.Contains(key)) return EnqueueAsync(command, token); if (!_queued.Add(key)) return ValueTask.CompletedTask; _queue.Enqueue(command, -(int)command.Priority); } _signal.Release(); return ValueTask.CompletedTask; }
    public async Task<InputCommand?> DequeueAsync(CancellationToken token) { await _signal.WaitAsync(token); lock (_gate) { if (!_queue.TryDequeue(out var command, out _)) return null; _queued.Remove(DedupeKey(command)); return command; } }
    public void Complete(InputCommand command) { lock (_gate) _pending.Remove(DedupeKey(command)); }
    public void ClearFishing() { lock (_gate) { var retained = new List<InputCommand>(); var removed = 0; while (_queue.TryDequeue(out var command, out _)) { if (command.Action is "Cast" or "Bobber" || command.Priority is InputPriority.Fishing or InputPriority.Bobber) { removed++; var key = DedupeKey(command); _queued.Remove(key); _pending.Remove(key); } else retained.Add(command); } foreach (var command in retained) _queue.Enqueue(command, -(int)command.Priority); for (var i = 0; i < removed; i++) _ = _signal.Wait(0); } }
    public void ClearAll() { lock (_gate) { var removed = _queue.Count; while (_queue.TryDequeue(out var command, out _)) { var key = DedupeKey(command); _queued.Remove(key); _pending.Remove(key); } for (var i = 0; i < removed; i++) _ = _signal.Wait(0); } }
    public ValueTask DisposeAsync() { _disposed = true; _signal.Dispose(); return ValueTask.CompletedTask; }
    private static string DedupeKey(InputCommand command) => $"{command.Action}|{command.Priority}|{command.Key}|{command.Text}";
}

public sealed class ClientInputQueueFactory : IClientInputQueueFactory, IAsyncDisposable {
    private readonly ConcurrentDictionary<Guid, ClientInputQueue> _queues = new();
    public IInputQueue Get(Guid profileId) => _queues.GetOrAdd(profileId, _ => new ClientInputQueue());
    public async ValueTask RemoveAsync(Guid profileId) { if (_queues.TryRemove(profileId, out var queue)) await queue.DisposeAsync(); }
    public async ValueTask DisposeAsync() { foreach (var id in _queues.Keys) await RemoveAsync(id); }
}
