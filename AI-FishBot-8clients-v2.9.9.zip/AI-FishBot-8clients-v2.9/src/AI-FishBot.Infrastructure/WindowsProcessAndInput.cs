using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.IO.Ports;
using AIFishBot.Core;
using Microsoft.Extensions.Logging;

namespace AIFishBot.Infrastructure;

public sealed class WindowsProcessDiscoveryService(ILogger<WindowsProcessDiscoveryService> logger) : IProcessDiscoveryService {
    public IReadOnlyList<ProcessCandidate> FindWowProcesses() {
        var candidates = new List<ProcessCandidate>();
        foreach (var process in Process.GetProcesses()) {
            using (process) {
                try {
                    if (!process.ProcessName.Equals("Wow", StringComparison.OrdinalIgnoreCase) && !process.ProcessName.StartsWith("Wow", StringComparison.OrdinalIgnoreCase)) continue;
                    var handle = process.MainWindowHandle; var title = process.MainWindowTitle;
                    if (handle == 0 || string.IsNullOrWhiteSpace(title)) continue;
                    candidates.Add(new ProcessCandidate { Pid = process.Id, WindowHandle = handle, WindowTitle = title, ExecutablePath = process.MainModule?.FileName });
                } catch (InvalidOperationException error) { logger.LogDebug(error, "Process disappeared during WoW discovery"); } catch (System.ComponentModel.Win32Exception error) { logger.LogDebug(error, "WoW process details were inaccessible"); }
            }
        }
        return candidates.OrderBy(x => x.Pid).ToArray();
    }
}

public sealed class ProfileBindingService(ApplicationState state, IClientProfileManager profiles, IProcessDiscoveryService discovery) : IProfileBindingService {
    private readonly List<ProcessCandidate> _unbound = [];
    public IReadOnlyList<ProcessCandidate> UnboundProcesses => _unbound;
    public void RefreshBindings() {
        var running = discovery.FindWowProcesses();
        var claimed = new HashSet<int>();
        foreach (var runtime in state.GetClientsSnapshot().Where(x => x.RuntimePid.HasValue)) {
            var found = running.FirstOrDefault(x => x.Pid == runtime.RuntimePid);
            if (found is null) profiles.UnbindRuntimeProcess(runtime.ProfileId); else { runtime.WindowHandle = found.WindowHandle; runtime.WindowTitle = found.WindowTitle; runtime.ExecutablePath = found.ExecutablePath; runtime.LastSeen = found.SeenAt; claimed.Add(found.Pid); }
        }
        foreach (var profile in profiles.Profiles.Where(x => x.AutoBindEnabled && state.GetClientsSnapshot().All(r => r.ProfileId != x.ProfileId || r.RuntimePid is null))) {
            var matches = running.Where(candidate => !claimed.Contains(candidate.Pid) && StableMatch(profile, candidate)).ToArray();
            if (matches.Length != 1) continue;
            profiles.BindRuntimeProcess(profile.ProfileId, matches[0].Pid, matches[0].WindowHandle); var runtime = state.GetClientsSnapshot().First(x => x.ProfileId == profile.ProfileId); runtime.WindowTitle = matches[0].WindowTitle; runtime.ExecutablePath = matches[0].ExecutablePath; claimed.Add(matches[0].Pid);
        }
        _unbound.Clear(); _unbound.AddRange(running.Where(x => !claimed.Contains(x.Pid)));
    }
    public bool Bind(Guid profileId, int pid) { var candidate = discovery.FindWowProcesses().FirstOrDefault(x => x.Pid == pid); if (candidate is null || state.GetClientsSnapshot().Any(x => x.ProfileId != profileId && x.RuntimePid == pid)) return false; profiles.BindRuntimeProcess(profileId, pid, candidate.WindowHandle); var runtime = state.GetClientsSnapshot().First(x => x.ProfileId == profileId); runtime.WindowTitle = candidate.WindowTitle; runtime.ExecutablePath = candidate.ExecutablePath; RefreshBindings(); return true; }
    public void Unbind(Guid profileId) { profiles.UnbindRuntimeProcess(profileId); RefreshBindings(); }
    private static bool StableMatch(ClientProfile profile, ProcessCandidate candidate) {
        if (!string.IsNullOrWhiteSpace(profile.ExecutablePathPattern) && !PathsEqual(profile.ExecutablePathPattern, candidate.ExecutablePath)) return false;
        if (!string.IsNullOrWhiteSpace(profile.WindowTitlePattern) && !candidate.WindowTitle.Contains(profile.WindowTitlePattern, StringComparison.OrdinalIgnoreCase)) return false;
        if (!string.IsNullOrWhiteSpace(profile.CharacterIdentifier) && !candidate.WindowTitle.Contains(profile.CharacterIdentifier, StringComparison.OrdinalIgnoreCase)) return false;
        if (!string.IsNullOrWhiteSpace(profile.AccountIdentifier) && !candidate.WindowTitle.Contains(profile.AccountIdentifier, StringComparison.OrdinalIgnoreCase)) return false;
        return !string.IsNullOrWhiteSpace(profile.ExecutablePathPattern) || !string.IsNullOrWhiteSpace(profile.CharacterIdentifier) || !string.IsNullOrWhiteSpace(profile.AccountIdentifier) || !string.IsNullOrWhiteSpace(profile.WindowTitlePattern);
    }
    private static bool PathsEqual(string configured, string? actual) { if (string.IsNullOrWhiteSpace(actual)) return false; try { return string.Equals(Path.GetFullPath(configured), Path.GetFullPath(actual), StringComparison.OrdinalIgnoreCase); } catch (Exception error) when (error is ArgumentException or NotSupportedException or PathTooLongException) { return false; } }
}

public sealed class SerialInputSender : ISerialInputSender {
    private SerialPort? _port;
    public void Send(string portName, string command) { if (_port is null || !_port.IsOpen || !_port.PortName.Equals(portName, StringComparison.OrdinalIgnoreCase)) { _port?.Dispose(); _port = new SerialPort(portName, 115200) { NewLine = "\n" }; _port.Open(); } _port.WriteLine(command); }
    public void Dispose() { if (_port?.IsOpen == true) _port.Close(); _port?.Dispose(); }
}

public sealed class WindowsInputExecutor(ApplicationState state, ISecretProtector secrets, ISerialInputSender serial, ILogger<WindowsInputExecutor> logger) : IInputExecutor {
    private readonly SemaphoreSlim _executionGate = new(1, 1);
    public static int NativeInputSize => Marshal.SizeOf<INPUT>();
    public async Task ExecuteAsync(ClientRuntime runtime, ClientProfile profile, InputCommand command, CancellationToken token) {
        await _executionGate.WaitAsync(token);
        try { await ExecuteExclusiveAsync(runtime, profile, command, token); }
        finally { _executionGate.Release(); }
    }
    private async Task ExecuteExclusiveAsync(ClientRuntime runtime, ClientProfile profile, InputCommand command, CancellationToken token) {
        if (runtime.RuntimePid is null || !ProcessExists(runtime.RuntimePid.Value)) throw new InvalidOperationException("The bound WoW process is not running.");
        if (state.Settings.General.UseSerialInput) {
            var key = command.Action switch { "Cast" => profile.Keybinds.Cast, "Bobber" => profile.Keybinds.Hook, "Logout" => profile.Keybinds.Exit, "Buff" or "Key" => command.Key, _ => null };
            if (string.IsNullOrWhiteSpace(key)) throw new InvalidOperationException($"Action {command.Action} is not supported by serial input.");
            serial.Send(state.Settings.General.SerialPort, key); await Task.Delay(50, token); return;
        }
        var windowHandle = ResolveMainWindow(runtime);
        if (windowHandle == 0) throw new InvalidOperationException($"The bound WoW process (PID {runtime.RuntimePid}) has no usable visible window.");
        var foregroundBefore = ForegroundProcessId();
        await FocusAndVerifyAsync(windowHandle, runtime.RuntimePid.Value, token);
        if (command.Action is "Cast" or "Bobber") logger.LogInformation("{Action} focus verified for ProfileId={ProfileId}, TargetPid={TargetPid}, ForegroundBefore={ForegroundBefore}, ForegroundAfter={ForegroundAfter}, Hwnd={Hwnd}", command.Action, profile.ProfileId, runtime.RuntimePid, foregroundBefore, ForegroundProcessId(), windowHandle);
        switch (command.Action) {
            case "Cast": SendKeySpec(profile.Keybinds.Cast); break;
            case "Bobber": SendKeySpec(profile.Keybinds.Hook); break;
            case "Logout": SendKeySpec(profile.Keybinds.Exit); break;
            case "Buff": SendKeySpec(command.Key ?? throw new InvalidOperationException("Buff key is missing.")); break;
            case "Key":
                if (command.Priority == InputPriority.Recovery && (runtime.NetworkTelemetryAvailable != true || runtime.FishingState != FishingState.Recovering)) return;
                SendKeySpec(command.Key ?? throw new InvalidOperationException("Key is missing.")); break;
            case "Reload": SendChatCommand("/reload"); break;
            case "BindLoot": SendChatCommand("/aifishloot reset"); await Task.Delay(150, token); SendChatCommand("/reload"); break;
            case "ChatCommand": SendChatCommand(command.Text ?? ""); break;
            case "Password":
                if (!state.Settings.Recovery.AllowPasswordTyping || runtime.NetworkTelemetryAvailable != true || runtime.FishingState != FishingState.Recovering) return;
                var password = !string.IsNullOrWhiteSpace(profile.EncryptedPassword) ? secrets.Unprotect(profile.EncryptedPassword) : Environment.GetEnvironmentVariable("AIFISHBOT_WOW_PASSWORD"); if (string.IsNullOrEmpty(password)) return;
                try { SendUnicode(password); } finally { password = string.Empty; }
                break;
            default: throw new InvalidOperationException($"Unknown input action: {command.Action}");
        }
        await Task.Delay(Math.Max(50, state.Settings.General.FocusSettleMilliseconds), token);
    }
    private static bool ProcessExists(int pid) { try { using var process = Process.GetProcessById(pid); return !process.HasExited; } catch (ArgumentException) { return false; } }
    private static nint ResolveMainWindow(ClientRuntime runtime) {
        if (runtime.WindowHandle != 0 && IsWindow(runtime.WindowHandle) && IsWindowVisible(runtime.WindowHandle)) return runtime.WindowHandle;
        if (runtime.RuntimePid is not { } pid) return 0;
        try { using var process = Process.GetProcessById(pid); process.Refresh(); var handle = process.MainWindowHandle; if (handle == 0 || !IsWindow(handle) || !IsWindowVisible(handle)) handle = FindVisibleTopLevelWindow(pid); runtime.WindowHandle = handle; return handle; }
        catch (Exception error) when (error is ArgumentException or InvalidOperationException or System.ComponentModel.Win32Exception) { return 0; }
    }
    private static nint FindVisibleTopLevelWindow(int pid) { nint match = 0; _ = EnumWindows((handle, parameter) => { _ = parameter; _ = GetWindowThreadProcessId(handle, out var ownerPid); if (ownerPid == (uint)pid && IsWindowVisible(handle)) { match = handle; return false; } return true; }, 0); return match; }
    private async Task FocusAndVerifyAsync(nint windowHandle, int pid, CancellationToken token) {
        for (var attempt = 1; attempt <= 3; attempt++) {
            RequestWindowActivation(windowHandle, pid);
            await Task.Delay(Math.Max(state.Settings.General.FocusSettleMilliseconds, 35) + (attempt - 1) * 40, token);
            if (ForegroundBelongsTo(pid)) return;
        }
        throw new InvalidOperationException($"WoW focus verification failed: target PID={pid}, HWND={windowHandle}, foreground PID={ForegroundProcessId()}, foreground HWND={GetForegroundWindow()}.");
    }
    private static void RequestWindowActivation(nint windowHandle, int pid) {
        if (windowHandle == 0) return; _ = ShowWindowAsync(windowHandle, 9);
        _ = TryWScriptAppActivate(pid);
        _ = SetForegroundWindow(windowHandle);
        var foreground = GetForegroundWindow(); var currentThread = GetCurrentThreadId(); var foregroundThread = foreground == 0 ? 0u : GetWindowThreadProcessId(foreground, out _); var targetThread = GetWindowThreadProcessId(windowHandle, out _); var attachedForeground = false; var attachedTarget = false;
        try { if (foregroundThread != 0 && foregroundThread != currentThread) attachedForeground = AttachThreadInput(currentThread, foregroundThread, true); if (targetThread != 0 && targetThread != currentThread) attachedTarget = AttachThreadInput(currentThread, targetThread, true); _ = BringWindowToTop(windowHandle); _ = SetForegroundWindow(windowHandle); }
        finally { if (attachedTarget) _ = AttachThreadInput(currentThread, targetThread, false); if (attachedForeground) _ = AttachThreadInput(currentThread, foregroundThread, false); }
        SwitchToThisWindow(windowHandle, true);
        _ = SetWindowPos(windowHandle, new nint(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040);
        _ = BringWindowToTop(windowHandle); _ = SetForegroundWindow(windowHandle);
        _ = SetWindowPos(windowHandle, new nint(-2), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040);
    }
    private static bool TryWScriptAppActivate(int pid) {
        object? shell = null;
        try { var shellType = Type.GetTypeFromProgID("WScript.Shell"); if (shellType is null) return false; shell = Activator.CreateInstance(shellType); if (shell is null) return false; var result = shellType.InvokeMember("AppActivate", System.Reflection.BindingFlags.InvokeMethod, null, shell, [pid]); return result is true; }
        catch (Exception error) when (error is ArgumentException or InvalidOperationException or System.Reflection.TargetInvocationException or System.Runtime.InteropServices.COMException) { _ = error; return false; }
        finally { if (shell is not null && Marshal.IsComObject(shell)) _ = Marshal.FinalReleaseComObject(shell); }
    }
    private static uint ForegroundProcessId() { var foreground = GetForegroundWindow(); if (foreground == 0) return 0; _ = GetWindowThreadProcessId(foreground, out var ownerPid); return ownerPid; }
    private static bool ForegroundBelongsTo(int pid) => ForegroundProcessId() == (uint)pid;
    private static void SendChatCommand(string command) { SendKey(0x0D); SendUnicode(command); SendKey(0x0D); }
    public static void SendKeySpec(string spec) {
        var pieces = spec.Split('+', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries); if (pieces.Length == 0) throw new FormatException("Empty key specification.");
        var modifiers = pieces[..^1].Select(ParseVirtualKey).ToArray(); var key = ParseVirtualKey(pieces[^1]);
        foreach (var modifier in modifiers) KeyEvent(modifier, false); KeyEvent(key, false); KeyEvent(key, true); for (var i = modifiers.Length - 1; i >= 0; i--) KeyEvent(modifiers[i], true);
    }
    private static void SendKey(ushort key) { KeyEvent(key, false); KeyEvent(key, true); }
    private static ushort ParseVirtualKey(string key) {
        var upper = key.Trim().ToUpperInvariant();
        if (upper.Length == 1 && char.IsLetterOrDigit(upper[0])) return upper[0];
        if (upper.StartsWith('F') && int.TryParse(upper[1..], out var function) && function is >= 1 and <= 24) return (ushort)(0x70 + function - 1);
        return upper switch { "CTRL" or "CONTROL" => 0x11, "SHIFT" => 0x10, "ALT" => 0x12, "ENTER" => 0x0D, "SPACE" => 0x20, "ESC" or "ESCAPE" => 0x1B, "TAB" => 0x09, "BACKSPACE" => 0x08, "DELETE" or "DEL" => 0x2E, "UP" => 0x26, "DOWN" => 0x28, "LEFT" => 0x25, "RIGHT" => 0x27, _ => throw new FormatException($"Unsupported key: {key}") };
    }
    private static void SendUnicode(string text) { foreach (var rune in text.EnumerateRunes()) foreach (var character in rune.ToString()) { SendKeyboardInput(new KEYBDINPUT { ScanCode = character, Flags = 0x0004 }); SendKeyboardInput(new KEYBDINPUT { ScanCode = character, Flags = 0x0004 | 0x0002 }); } }
    private static void KeyEvent(ushort key, bool up) => SendKeyboardInput(new KEYBDINPUT { VirtualKey = key, Flags = up ? 0x0002u : 0 });
    private static void SendKeyboardInput(KEYBDINPUT keyboard) { var input = new INPUT { Type = 1, U = new InputUnion { Keyboard = keyboard } }; if (SendInput(1, [input], Marshal.SizeOf<INPUT>()) != 1) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(), $"SendInput failed (INPUT size={Marshal.SizeOf<INPUT>()})."); }
    [DllImport("user32.dll")] private static extern bool SetForegroundWindow(nint windowHandle);
    [DllImport("user32.dll")] private static extern bool IsWindow(nint windowHandle);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(nint windowHandle);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsCallback callback, nint parameter);
    [DllImport("user32.dll")] private static extern nint GetForegroundWindow();
    [DllImport("user32.dll")] private static extern bool BringWindowToTop(nint windowHandle);
    [DllImport("user32.dll")] private static extern void SwitchToThisWindow(nint windowHandle, bool altTab);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool SetWindowPos(nint windowHandle, nint insertAfter, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll")] private static extern bool ShowWindowAsync(nint windowHandle, int command);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(nint windowHandle, out uint processId);
    [DllImport("kernel32.dll")] private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] private static extern bool AttachThreadInput(uint sourceThread, uint targetThread, bool attach);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint count, INPUT[] inputs, int size);
    private delegate bool EnumWindowsCallback(nint windowHandle, nint parameter);
    [StructLayout(LayoutKind.Sequential)] private struct INPUT { public uint Type; public InputUnion U; }
    [StructLayout(LayoutKind.Explicit)] private struct InputUnion { [FieldOffset(0)] public MOUSEINPUT Mouse; [FieldOffset(0)] public KEYBDINPUT Keyboard; [FieldOffset(0)] public HARDWAREINPUT Hardware; }
    [StructLayout(LayoutKind.Sequential)] private struct KEYBDINPUT { public ushort VirtualKey; public ushort ScanCode; public uint Flags; public uint Time; public nint ExtraInfo; }
    [StructLayout(LayoutKind.Sequential)] private struct MOUSEINPUT { public int Dx; public int Dy; public uint MouseData; public uint Flags; public uint Time; public nint ExtraInfo; }
    [StructLayout(LayoutKind.Sequential)] private struct HARDWAREINPUT { public uint Message; public ushort ParameterLow; public ushort ParameterHigh; }
}
