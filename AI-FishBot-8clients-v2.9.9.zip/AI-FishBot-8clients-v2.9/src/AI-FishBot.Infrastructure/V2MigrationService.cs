using System.Globalization;
using System.Text.Json;
using AIFishBot.Core;

namespace AIFishBot.Infrastructure;

public sealed class V2MigrationService : IV2MigrationService {
    public async Task<bool> TryMigrateAsync(string v2SettingsPath, string backupDirectory, ApplicationSettings target, CancellationToken token = default) {
        if (target.V2MigrationCompleted || !File.Exists(v2SettingsPath)) return false;
        Directory.CreateDirectory(backupDirectory);
        File.Copy(v2SettingsPath, Path.Combine(backupDirectory, "v2-settings-backup.json"), true);
        await using var stream = File.OpenRead(v2SettingsPath);
        using var document = await JsonDocument.ParseAsync(stream, cancellationToken: token);
        var root = document.RootElement;
        if (root.TryGetProperty("BlizzardClientIdProtected", out var id) && !string.IsNullOrWhiteSpace(id.GetString())) target.BlizzardCredentials.EncryptedClientId = id.GetString();
        if (root.TryGetProperty("BlizzardClientSecretProtected", out var secret) && !string.IsNullOrWhiteSpace(secret.GetString())) target.BlizzardCredentials.EncryptedClientSecret = secret.GetString();
        if (root.TryGetProperty("ClientProfiles", out var profiles) && profiles.ValueKind == JsonValueKind.Array) {
            var index = 1;
            foreach (var old in profiles.EnumerateArray()) {
                var profile = new ClientProfile { DisplayName = ReadString(old, "WindowTitle") ?? $"Migrated client {index}", WindowTitlePattern = ReadString(old, "WindowTitle") ?? "World of Warcraft", StartAutomatically = ReadBool(old, "Selected") };
                profile.Keybinds.Cast = ReadString(old, "Cast") ?? "F6"; profile.Keybinds.Hook = ReadString(old, "Bobber") ?? "F7"; profile.Keybinds.Exit = ReadString(old, "Logout") ?? "F8";
                if (old.TryGetProperty("PasswordProtected", out var password) && !string.IsNullOrWhiteSpace(password.GetString())) profile.EncryptedPassword = password.GetString();
                if (old.TryGetProperty("SavedVariablesPath", out var savedPath)) profile.SavedVariablesPath = savedPath.GetString();
                if (old.TryGetProperty("Buffs", out var buffs) && buffs.ValueKind == JsonValueKind.Array) profile.Buffs.Entries = buffs.EnumerateArray().Select(ParseBuff).ToList();
                target.Profiles.Add(profile); index++;
            }
        }
        ApplyConfig(root, target);
        target.Recovery.ActionPlan = RecoveryConfiguration.CreateDefaultActionPlan();
        target.V2MigrationCompleted = true; target.V2SettingsPath = v2SettingsPath; target.SchemaVersion = 4;
        return true;
    }
    private static BuffDefinition ParseBuff(JsonElement item) => new() { Id = ReadInt(item, "Id", 0), Name = $"Buff {ReadInt(item, "Id", 0)}", Enabled = ReadBool(item, "Enabled"), Key = ReadString(item, "Keybind") ?? "", CastTime = TimeSpan.FromSeconds(ReadDouble(item, "CastTimeSeconds", 0)), Duration = TimeSpan.FromMinutes(ReadDouble(item, "DurationMinutes", 1)) };
    private static void ApplyConfig(JsonElement root, ApplicationSettings target) {
        if (!root.TryGetProperty("Config", out var rows) || rows.ValueKind != JsonValueKind.Array) return;
        foreach (var row in rows.EnumerateArray()) { var path = ReadString(row, "Path"); var value = ReadString(row, "Value"); if (path is null || value is null) continue; ApplyValue(path, value, target); }
    }
    private static void ApplyValue(string path, string value, ApplicationSettings s) {
        var invariant = CultureInfo.InvariantCulture; bool Bool() => value.Equals("true", StringComparison.OrdinalIgnoreCase) || value == "1" || value.Equals("igen", StringComparison.OrdinalIgnoreCase); double Double() => double.Parse(value.Replace(',', '.'), invariant); int Int() => int.Parse(value, invariant); int[] IntArray() => value.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).Select(x => int.Parse(x, invariant)).ToArray();
        switch (path) {
            case "General.Retail": s.General.Retail = Bool(); break; case "General.AutoStop": s.General.AutoStop = Bool(); break; case "General.AutoStopMinutes": s.General.AutoStopMinutes = Int(); break; case "General.AutoLogout": s.General.AutoLogout = Bool(); break; case "General.UseWindowFocus": s.General.UseWindowFocus = Bool(); break; case "General.FishingRetries": s.General.FishingRetries = Int(); break; case "General.UseWeakAura": s.General.UseWeakAura = Bool(); break; case "General.LootWaitSeconds": s.General.LootWaitSeconds = Double(); break; case "General.NoBiteStreakLimit": s.General.NoBiteStreakLimit = Int(); break; case "General.NoCatchWarningMinutes": s.General.NoCatchWarningMinutes = Double(); break; case "General.FishRateDropThresholdPct": s.General.FishRateDropThresholdPercent = Double(); break; case "General.MaxClients": s.General.MaxClients = Int(); break; case "General.ProcessCheckIntervalSeconds": s.General.ProcessCheckIntervalSeconds = Double(); break; case "General.FocusSettleMilliseconds": s.General.FocusSettleMilliseconds = Int(); break;
            case "Audio.Sensitivity": s.Audio.Sensitivity = Double(); break; case "Audio.PollIntervalMs": s.Audio.PollIntervalMilliseconds = Int(); break;
            case "Client.UsePi": s.General.UseSerialInput = Bool(); break; case "Client.PicoComPort": s.General.SerialPort = value; break;
            case "Recovery.Enabled": s.Recovery.Enabled = Bool(); break; case "Recovery.NetworkPollSeconds": s.Recovery.NetworkPollSeconds = Double(); break; case "Recovery.NetworkLearnTimeoutSeconds": s.Recovery.NetworkLearnTimeoutSeconds = Double(); break; case "Recovery.DisconnectConfirmSeconds": s.Recovery.DisconnectConfirmSeconds = Double(); break; case "Recovery.StableConnectionSeconds": s.Recovery.StableConnectionSeconds = Double(); break; case "Recovery.MaxAttempts": s.Recovery.MaxAttempts = Int(); break; case "Recovery.BackoffSeconds": s.Recovery.BackoffSeconds = IntArray(); break; case "Recovery.AllowPasswordTyping": s.Recovery.AllowPasswordTyping = Bool(); break; case "Recovery.FallbackToNoBiteOnly": s.Recovery.FallbackToNoBiteOnly = Bool(); break; case "Recovery.ServerPorts": s.Recovery.ServerPorts = IntArray(); break; case "Recovery.IgnoreRemotePorts": s.Recovery.IgnoreRemotePorts = IntArray(); break;
            case "Loot.Enabled": s.Loot.Enabled = Bool(); break; case "Loot.ReloadEveryCatches": s.Loot.ReloadEveryCatches = Int(); break; case "Loot.MaxUnsyncedMinutes": s.Loot.MaxUnsyncedMinutes = Double(); break; case "Loot.CatchJournalEnabled": s.Loot.CatchJournalEnabled = Bool(); break; case "Loot.RequiredAddonVersion": s.Loot.RequiredAddonVersion = value; break; case "Loot.HighlightFishName": s.Loot.HighlightFishName = value; break; case "Loot.ReloadSettleSeconds": s.Loot.ReloadSettleSeconds = Double(); break; case "Loot.ReloadSpacingSeconds": s.Loot.ReloadSpacingSeconds = Double(); break; case "Loot.BindTimeoutSeconds": s.Loot.BindTimeoutSeconds = Double(); break; case "Loot.BindMaxRetries": s.Loot.BindMaxRetries = Int(); break;
            case "Price.GameVersion": s.Price.GameVersion = value; break; case "Price.Region": s.Price.Region = value; break; case "Price.Realm": s.Price.Realm = value; break; case "Price.Faction": s.Price.Faction = value; break; case "Price.FallbackPrice": s.Price.FallbackWyrmfishPriceGold = (decimal)Double(); break; case "Price.BlizzardEnabled": s.Price.BlizzardEnabled = Bool(); break; case "Price.ConnectedRealmId": s.Price.ConnectedRealmId = string.IsNullOrWhiteSpace(value) ? null : Int(); break; case "Price.BlizzardRefreshMinutes": s.Price.BlizzardRefreshMinutes = Double(); break; case "Price.BlizzardRetryMinutes": s.Price.BlizzardRetryMinutes = Double(); break; case "Price.BlizzardTimeoutSeconds": s.Price.BlizzardTimeoutSeconds = Int(); break; case "Price.BlizzardPriceMetric": s.Price.BlizzardPriceMetric = Enum.TryParse<PriceMetric>(value, true, out var metric) ? metric : PriceMetric.MinimumBuyout; break; case "Price.PriceHistoryMaxDays": s.Price.PriceHistoryMaxDays = Int(); break; case "Price.SellMinimumSamples": s.Price.SellMinimumSamples = Int(); break; case "Price.SellMinimumDistinctDays": s.Price.SellMinimumDistinctDays = Int(); break; case "Price.SellNowPercentile": s.Price.SellNowPercentile = Double(); break; case "Price.SellExpectedRisePct": s.Price.SellExpectedRisePercent = Double(); break; case "Price.AdditionalItemPrices": s.Price.ManualItemPricesGold = ParsePriceMap(value); break;
            case "Revenue.GoldPerEuro": s.Revenue.GoldPerEuro = (decimal)Double(); break; case "Revenue.EurToHuf": s.Revenue.EurToHuf = (decimal)Double(); break; case "Target.TargetHuf": foreach (var profile in s.Profiles) { profile.Target.TargetAmount = (decimal)Double(); profile.Target.Currency = "HUF"; profile.Target.Enabled = profile.Target.TargetAmount > 0; } break;
            case "Gui.MonitorIntervalMs": s.Gui.MonitorIntervalMilliseconds = Int(); break; case "Gui.RefreshIntervalMs": s.Gui.RefreshIntervalMilliseconds = Int(); break; case "Gui.ReportIntervalSeconds": s.Gui.ReportIntervalSeconds = Int(); break; case "Gui.AlertHistoryLimit": s.Gui.AlertHistoryLimit = Int(); break; case "Gui.AlertDisplayCount": s.Gui.AlertDisplayCount = Int(); break; case "Logging.Enabled": s.Logging.Enabled = Bool(); break; case "Logging.Directory": s.Logging.Directory = value; break; case "Logging.Debug": s.Logging.Debug = Bool(); break; case "Logging.ErrorThrottleSeconds": s.Logging.ErrorThrottleSeconds = Int(); break;
            default: ApplyStructuredPath(path, value, s); break;
        }
    }
    private static void ApplyStructuredPath(string path, string value, ApplicationSettings settings) {
        var parts = path.Split('.'); if (parts.Length != 4 || !int.TryParse(parts[2], out var index)) return;
        if (parts[0] == "Recovery" && parts[1] == "ActionPlan") { while (settings.Recovery.ActionPlan.Count <= index) settings.Recovery.ActionPlan.Add(new RecoveryStep()); var step = settings.Recovery.ActionPlan[index]; switch (parts[3]) { case "Name": step.Name = value; break; case "Type": step.Type = value; break; case "Key": step.Key = value; break; case "WaitForConnectionSeconds": step.WaitForConnectionSeconds = (int)Math.Round(double.Parse(value.Replace(',', '.'), CultureInfo.InvariantCulture)); break; } }
    }
    private static Dictionary<string, decimal> ParsePriceMap(string value) { var result = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase); foreach (var part in value.Split(';', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)) { var pair = part.Split('=', 2, StringSplitOptions.TrimEntries); if (pair.Length == 2 && decimal.TryParse(pair[1].Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out var price) && price > 0) result[pair[0]] = price; } return result; }
    private static string? ReadString(JsonElement value, string name) => value.TryGetProperty(name, out var item) ? item.GetString() : null;
    private static bool ReadBool(JsonElement value, string name) => value.TryGetProperty(name, out var item) && item.ValueKind is JsonValueKind.True;
    private static int ReadInt(JsonElement value, string name, int fallback) => value.TryGetProperty(name, out var item) && item.TryGetInt32(out var parsed) ? parsed : fallback;
    private static double ReadDouble(JsonElement value, string name, double fallback) => value.TryGetProperty(name, out var item) && item.TryGetDouble(out var parsed) ? parsed : fallback;
}
