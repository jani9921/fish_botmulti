using System.Net;
using System.ComponentModel;
using System.Runtime.InteropServices;
using AIFishBot.Core;
using Microsoft.Extensions.Logging;
using NAudio.CoreAudioApi;

namespace AIFishBot.Infrastructure;

public sealed class NAudioPeakService(ILogger<NAudioPeakService> logger) : IAudioPeakService, IDisposable {
    private readonly object _gate = new(); private MMDeviceEnumerator? _enumerator; private MMDevice? _device;
    public IReadOnlyDictionary<int, float> GetPeaks(IEnumerable<int> processIds) {
        var wanted = processIds.ToHashSet(); var result = new Dictionary<int, float>(); if (wanted.Count == 0) return result;
        lock (_gate) try {
            _enumerator ??= new MMDeviceEnumerator(); _device ??= _enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia); var sessions = _device.AudioSessionManager.Sessions;
            for (var i = 0; i < sessions.Count; i++) { using var session = sessions[i]; var pid = unchecked((int)session.GetProcessID); if (!wanted.Contains(pid)) continue; var peak = session.AudioMeterInformation.MasterPeakValue * 100; if (!result.TryGetValue(pid, out var old) || peak > old) result[pid] = peak; }
        } catch (Exception error) { logger.LogWarning(error, "Per-process audio peak collection failed; audio device cache cleared"); _device?.Dispose(); _device = null; }
        return result;
    }
    public void Dispose() { lock (_gate) { _device?.Dispose(); _enumerator?.Dispose(); _device = null; _enumerator = null; } }
}

public sealed class WindowsNetworkMonitor : INetworkMonitor {
    public IReadOnlyDictionary<int, IReadOnlyList<string>> GetEstablishedEndpoints(IEnumerable<int> processIds, RecoveryConfiguration settings) {
        var wanted = processIds.ToHashSet(); var result = wanted.ToDictionary(x => x, _ => (IReadOnlyList<string>)Array.Empty<string>()); if (wanted.Count == 0) return result;
        var bufferSize = 0; var first = GetExtendedTcpTable(IntPtr.Zero, ref bufferSize, false, 2, 5); if (first != 122 || bufferSize <= 0) throw new Win32Exception(unchecked((int)first), "GetExtendedTcpTable sizing failed.");
        var buffer = Marshal.AllocHGlobal(bufferSize);
        try {
            var status = GetExtendedTcpTable(buffer, ref bufferSize, false, 2, 5); if (status != 0) throw new Win32Exception(unchecked((int)status), "GetExtendedTcpTable read failed."); var count = Marshal.ReadInt32(buffer); var rowSize = Marshal.SizeOf<MibTcpRowOwnerPid>(); var pointer = IntPtr.Add(buffer, sizeof(uint)); var mutable = wanted.ToDictionary(x => x, _ => new List<string>());
            for (var i = 0; i < count; i++) { var row = Marshal.PtrToStructure<MibTcpRowOwnerPid>(pointer); pointer = IntPtr.Add(pointer, rowSize); var pid = unchecked((int)row.OwningPid); if (row.State != 5 || !wanted.Contains(pid) || row.RemoteAddress == 0) continue; var portBytes = BitConverter.GetBytes(row.RemotePort); var port = (portBytes[0] << 8) + portBytes[1]; if (settings.ServerPorts.Length > 0 ? !settings.ServerPorts.Contains(port) : settings.IgnoreRemotePorts.Contains(port)) continue; var address = new IPAddress(BitConverter.GetBytes(row.RemoteAddress)).ToString(); if (address is "127.0.0.1" or "0.0.0.0") continue; mutable[pid].Add($"{address}|{port}"); }
            return mutable.ToDictionary(x => x.Key, x => (IReadOnlyList<string>)x.Value);
        } finally { Marshal.FreeHGlobal(buffer); }
    }
    [DllImport("iphlpapi.dll", SetLastError = true)] private static extern uint GetExtendedTcpTable(IntPtr table, ref int size, bool order, int ipVersion, int tableClass, uint reserved = 0);
    [StructLayout(LayoutKind.Sequential)] private struct MibTcpRowOwnerPid { public uint State; public uint LocalAddress; public uint LocalPort; public uint RemoteAddress; public uint RemotePort; public uint OwningPid; }
}
