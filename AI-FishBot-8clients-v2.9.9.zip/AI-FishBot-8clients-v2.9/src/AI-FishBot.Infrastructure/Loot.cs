using System.Globalization;
using System.Text;
using AIFishBot.Core;

namespace AIFishBot.Infrastructure;

public sealed class LuaSavedVariablesParser : ILootDataParser, ISavedVariablesReader {
    public LootSnapshot Parse(string source, DateTimeOffset? writeTime = null) {
        if (string.IsNullOrWhiteSpace(source)) return new LootSnapshot { SourceWriteTime = writeTime, IsValid = false };
        var globals = new LuaReader(source).ReadAssignments();
        if (!globals.TryGetValue("AIFishLootDB", out var databaseValue) || databaseValue is not Dictionary<string, object?> database) return new LootSnapshot { SourceWriteTime = writeTime, IsValid = false };
        globals.TryGetValue("AIFishLootMeta", out var metaValue); var meta = metaValue as Dictionary<string, object?>;
        var ids = meta is not null && meta.TryGetValue("itemIds", out var idValue) ? idValue as Dictionary<string, object?> : null;
        var items = new Dictionary<string, LootItem>(StringComparer.OrdinalIgnoreCase);
        foreach (var pair in database) {
            if (!TryLong(pair.Value, out var count) || count < 0 || string.IsNullOrWhiteSpace(pair.Key)) continue;
            int? itemId = ids is not null && ids.TryGetValue(pair.Key, out var itemIdValue) && TryLong(itemIdValue, out var id) && id is > 0 and <= int.MaxValue ? (int)id : null;
            items[pair.Key.Trim()] = new LootItem { Name = pair.Key.Trim(), Count = count, ItemId = itemId };
        }
        var version = meta is not null && meta.TryGetValue("version", out var versionValue) ? Convert.ToString(versionValue, CultureInfo.InvariantCulture) ?? "unknown" : "unknown";
        var duplicateSuppressed = meta is not null && meta.TryGetValue("duplicateSuppressed", out var duplicateValue) && TryLong(duplicateValue, out var duplicate) ? duplicate : 0;
        return new LootSnapshot { Items = items, SourceWriteTime = writeTime, AddonVersion = version, DuplicateSuppressed = duplicateSuppressed, IsValid = true };
    }
    public async Task<LootSnapshot?> ReadAsync(string path, CancellationToken token = default) {
        for (var attempt = 0; attempt < 4; attempt++) {
            try {
                var before = new FileInfo(path); if (!before.Exists || before.Length == 0) return null; var beforeWrite = before.LastWriteTimeUtc;
                await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 64 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
                using var reader = new StreamReader(stream, Encoding.UTF8, true); var text = await reader.ReadToEndAsync(token); var after = new FileInfo(path);
                if (before.Length != after.Length || beforeWrite != after.LastWriteTimeUtc) throw new IOException("SavedVariables changed while being read.");
                var snapshot = Parse(text, after.LastWriteTimeUtc); return snapshot.IsValid ? snapshot : null;
            } catch (Exception error) when (attempt < 3 && (error is IOException || error is UnauthorizedAccessException || error is FormatException)) { await Task.Delay(TimeSpan.FromMilliseconds(150 * (attempt + 1)), token); }
        }
        return null;
    }
    private static bool TryLong(object? value, out long result) { if (value is long number) { result = number; return true; } return long.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), NumberStyles.Integer, CultureInfo.InvariantCulture, out result); }

    private sealed class LuaReader(string source) {
        private int _index;
        public Dictionary<string, object?> ReadAssignments() {
            var result = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            while (true) { SkipTrivia(); if (End) return result; var name = ReadIdentifier(); SkipTrivia(); Expect('='); result[name] = ReadValue(); SkipTrivia(); if (!End && Peek == ';') _index++; }
        }
        private object? ReadValue() {
            SkipTrivia(); if (End) throw Error("Unexpected end of input.");
            if (Peek == '{') return ReadTable(); if (Peek is '"' or '\'') return ReadString(); if (Peek == '-' || char.IsDigit(Peek)) return ReadNumber();
            var identifier = ReadIdentifier(); return identifier.ToLowerInvariant() switch { "true" => true, "false" => false, "nil" => null, _ => identifier };
        }
        private Dictionary<string, object?> ReadTable() {
            Expect('{'); var table = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase); var position = 1;
            while (true) {
                SkipTrivia(); if (End) throw Error("Unclosed Lua table."); if (Peek == '}') { _index++; return table; }
                string key; object? value;
                if (Peek == '[') { _index++; var keyValue = ReadValue(); SkipTrivia(); Expect(']'); SkipTrivia(); Expect('='); key = Convert.ToString(keyValue, CultureInfo.InvariantCulture) ?? position.ToString(CultureInfo.InvariantCulture); value = ReadValue(); }
                else {
                    var saved = _index; if (IsIdentifierStart(Peek)) { var candidate = ReadIdentifier(); SkipTrivia(); if (!End && Peek == '=') { _index++; key = candidate; value = ReadValue(); } else { _index = saved; key = position++.ToString(CultureInfo.InvariantCulture); value = ReadValue(); } }
                    else { key = position++.ToString(CultureInfo.InvariantCulture); value = ReadValue(); }
                }
                table[key] = value; SkipTrivia(); if (!End && Peek is ',' or ';') _index++;
            }
        }
        private object ReadNumber() {
            var start = _index; if (Peek == '-') _index++; while (!End && char.IsDigit(Peek)) _index++; var floating = false;
            if (!End && Peek == '.') { floating = true; _index++; while (!End && char.IsDigit(Peek)) _index++; }
            var text = source[start.._index]; if (!floating && long.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var integer)) return integer; if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var number)) return number; throw Error("Invalid number.");
        }
        private string ReadString() {
            var quote = Peek; _index++; var builder = new StringBuilder();
            while (!End) { var character = source[_index++]; if (character == quote) return builder.ToString(); if (character == '\\') { if (End) throw Error("Invalid escape."); var escaped = source[_index++]; builder.Append(escaped switch { 'n' => '\n', 'r' => '\r', 't' => '\t', '\\' => '\\', '"' => '"', '\'' => '\'', _ => escaped }); } else builder.Append(character); }
            throw Error("Unclosed string.");
        }
        private string ReadIdentifier() { SkipTrivia(); if (End || !IsIdentifierStart(Peek)) throw Error("Identifier expected."); var start = _index++; while (!End && (char.IsLetterOrDigit(Peek) || Peek == '_')) _index++; return source[start.._index]; }
        private void SkipTrivia() { while (!End) { if (char.IsWhiteSpace(Peek)) { _index++; continue; } if (Peek == '-' && _index + 1 < source.Length && source[_index + 1] == '-') { _index += 2; while (!End && Peek is not '\r' and not '\n') _index++; continue; } break; } }
        private void Expect(char expected) { SkipTrivia(); if (End || Peek != expected) throw Error($"'{expected}' expected."); _index++; }
        private static bool IsIdentifierStart(char value) => char.IsLetter(value) || value == '_';
        private FormatException Error(string message) => new($"{message} Position: {_index}.");
        private bool End => _index >= source.Length; private char Peek => source[_index];
    }
}
