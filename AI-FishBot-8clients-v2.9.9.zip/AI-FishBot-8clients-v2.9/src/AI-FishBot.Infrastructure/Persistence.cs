using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using AIFishBot.Core;
using Microsoft.Extensions.Logging;

namespace AIFishBot.Infrastructure;

public sealed class DpapiSecretProtector : ISecretProtector {
    public string Protect(string clearText) => Convert.ToBase64String(Transform(Encoding.UTF8.GetBytes(clearText), protect: true));
    public string Unprotect(string protectedValue) => Encoding.UTF8.GetString(Transform(Convert.FromBase64String(protectedValue), protect: false));
    private static byte[] Transform(byte[] input, bool protect) {
        var source = new DataBlob(input); DataBlob result = default;
        try {
            var success = protect ? CryptProtectData(ref source, null, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0, out result) : CryptUnprotectData(ref source, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0, out result);
            if (!success) throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows DPAPI operation failed.");
            var bytes = new byte[result.Size]; Marshal.Copy(result.Data, bytes, 0, result.Size); return bytes;
        } finally { source.Dispose(); result.Dispose(fromDpapi: true); }
    }
    [StructLayout(LayoutKind.Sequential)] private struct DataBlob {
        public int Size; public IntPtr Data;
        public DataBlob(byte[] bytes) { Size = bytes.Length; Data = Marshal.AllocHGlobal(Size); Marshal.Copy(bytes, 0, Data, Size); }
        public readonly void Dispose(bool fromDpapi = false) { if (Data != IntPtr.Zero) { if (fromDpapi) _ = LocalFree(Data); else Marshal.FreeHGlobal(Data); } }
    }
    [DllImport("crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)] private static extern bool CryptProtectData(ref DataBlob input, string? description, IntPtr optionalEntropy, IntPtr reserved, IntPtr prompt, int flags, out DataBlob output);
    [DllImport("crypt32.dll", SetLastError = true)] private static extern bool CryptUnprotectData(ref DataBlob input, IntPtr description, IntPtr optionalEntropy, IntPtr reserved, IntPtr prompt, int flags, out DataBlob output);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
}
public sealed class JsonProfileStore(string directory, ILogger<JsonProfileStore>? logger = null) : IProfileStore {
    private static readonly JsonSerializerOptions Json = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    private string SettingsPath => Path.Combine(directory, "settings.json"); private string BackupPath => Path.Combine(directory, "settings.json.bak");
    public async Task<ApplicationSettings> LoadAsync(CancellationToken token = default) { Directory.CreateDirectory(directory); if (!File.Exists(SettingsPath) && !File.Exists(BackupPath)) return new ApplicationSettings(); var primary = await TryRead(SettingsPath, token); if (primary is not null) return primary; var backup = await TryRead(BackupPath, token); return backup ?? throw new InvalidDataException("A settings.json és a settings.json.bak is sérült vagy olvashatatlan."); }
    public async Task SaveAsync(ApplicationSettings settings, CancellationToken token = default) { if (settings is null) throw new ArgumentNullException(nameof(settings)); if (settings.Profiles is null) throw new InvalidDataException("Profiles collection cannot be null."); Directory.CreateDirectory(directory); settings.UpdatedAt = DateTimeOffset.UtcNow; var temp = SettingsPath + ".tmp"; await using (var stream = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, 64 * 1024, FileOptions.WriteThrough)) await JsonSerializer.SerializeAsync(stream, settings, Json, token); _ = await TryRead(temp, token) ?? throw new InvalidDataException("Serialized settings validation failed."); if (File.Exists(SettingsPath)) File.Copy(SettingsPath, BackupPath, true); File.Move(temp, SettingsPath, true); }
    private async Task<ApplicationSettings?> TryRead(string path, CancellationToken token) { if (!File.Exists(path)) return null; try { await using var stream = File.OpenRead(path); var settings = await JsonSerializer.DeserializeAsync<ApplicationSettings>(stream, Json, token); if (!IsStructurallyValid(settings)) throw new JsonException("Settings structure contains null required objects."); return settings; } catch (JsonException error) { logger?.LogError(error, "Settings JSON is invalid: {Path}", path); return null; } catch (IOException error) { logger?.LogError(error, "Settings file cannot be read: {Path}", path); return null; } }
    private static bool IsStructurallyValid(ApplicationSettings? value) => value is not null && value.Profiles is not null && value.General is not null && value.Audio is not null && value.Recovery is not null && value.Loot is not null && value.Price is not null && value.Revenue is not null && value.Gui is not null && value.Logging is not null && value.BlizzardCredentials is not null && value.Profiles.All(x => x is not null && x.Keybinds is not null && x.Buffs?.Entries is not null && x.Target is not null && x.LifetimeStatistics is not null);
}
