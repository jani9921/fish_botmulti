# AI-FishBot V3 architektúra

## Azonosság és állapot

| Modell | Élettartam | Szerep |
|---|---|---|
| `ClientProfile` | tartós JSON | profilkonfiguráció, titkok, target, lifetime statisztika |
| `ClientRuntime` | memória | PID/ablak, state machine, hálózat, input és diagnosztika |
| `ClientSession` | egy futás | session statisztika és időmérés |
| `LootSnapshot` | fájlolvasás + LKG | addon számlálók és metaadatok |
| `InputCommand` | rövid életű | egy profil prioritásos inputművelete |

A `ProfileId` az egyetlen tartós klienskulcs. A `RuntimePid` nem kerül a konfigurációba. Automatikus kötés csak egyetlen stabil találatnál történik executable path, ablakcím, account és character minták alapján; bizonytalan esetben a profil `Unbound` marad.

## Rétegek

- `AI-FishBot.Core`: domain modellek és interfészek.
- `AI-FishBot.Application`: kontrollerek, validálás, statisztika, revenue és háttér-state machine-ek.
- `AI-FishBot.Infrastructure`: Windows input/process/network, NAudio, DPAPI, JSON/Lua, Blizzard API és riportok.
- `AI-FishBot.App`: WPF/MVVM felület és dependency injection.

Minden profilnak saját prioritásos input queue-ja és workere van, de a Windows-input végrehajtása egyetlen globális execution gate-en halad át. Ez a V2 `InputBusy` megfelelője: a `célablak fókusza → billentyű → rövid feldolgozási várakozás` szakasz atomi, ezért két kliens nem lophatja el egymástól a fókuszt. A recovery és Bobber magasabb prioritású; azonos in-flight akció nem kerül kétszer sorba. Pause/Stop törli a vonatkozó pending inputot.

## Disconnect és reconnect

A network worker folyamatonként tanulja az established WoW endpointokat. A kapcsolatvesztést csak a konfigurált megerősítési idő után tekinti valódi disconnectnek. Telemetriahiba esetén minden automatikus input leáll; a no-bite fallback külön, kockázatos opció.

Egyszerre egy kliens birtokolhatja a reconnect slotot. A schema 4 alapértelmezett terv determinisztikus: `Enter → Ctrl+A → password → Enter → 30 s → Enter`. A hálózat korábbi visszatérése nem szakítja félbe a tervet. Jelszót kizárólag megerősített recovery állapotban, DPAPI-ból feloldva gépel; hiányzó engedély/titok esetén kézi beavatkozásra áll.

## Adatintegritás

A settings mentés `.tmp` fájlba serializál, visszaolvassa, majd atomikusan cseréli a célt és megőrzi a `.bak` fájlt. Sérült primary esetén backup fallback történik. A Lua parser részleges vagy hibás írást elutasítja, így az utolsó érvényes loot snapshot marad használatban. A Blizzard cache és price history realm szerint szeparált.

## Biztonsági határok

Jelszó és Blizzard secret nem kerül logba vagy riportba. A titkosítás Windows DPAPI CurrentUser, ezért más Windows-fiók nem tudja visszafejteni. A Windows `SendInput` előtt az adapter ellenőrzi a kötött folyamatot és biztonságosan fókuszálja annak ablakát. BootyBayBroker és Discord kód nincs a V3 scope-ban.
