# AI-FishBot V3 – folytatási jegyzet

Dátum: 2026-09-01

## Elkészült

- A végső .NET 10 Release build 0 hibával és 0 warninggal elkészült; 16/16 unit teszt sikeres.
- A friss self-contained Windows x64 kiadás elkészült: `publish/AI-FishBot.App.exe`.
- A WPF startup `ClientProfileManager` DI-konstruktorütközése explicit factory-regisztrációval javítva.
- A cast/buff Win32 hibájának oka a hibás x64 `INPUT` unionméret volt; teljes ABI-union és pontos hibanaplózás került be.
- Ablakaktiválás fallbackkel, processzellenőrzéssel és tényleges foreground validálással működik.
- WeakAura/FishingRetries, account alapú process-binding, biztonságos SavedVariables-felderítés és advanced Settings lap elkészült.
- Loot/stat reset, session/lifetime revenue, recovery telemetry fail-safe és input worker shutdown stabilizálva.
- Schema 4 reconnect sorrend: `Enter → Ctrl+A → jelszó → Enter → 30 s → Enter`. A régi schema 3 beállítás automatikusan erre frissül.
- Dokumentáció és kibővített unit tesztek elkészültek.

## Tudatosan kihagyva

- BootyBayBroker árazás, CSV-import, inventory export és kapcsolódó fájlfigyelés.
- Discord webhook és Discord értesítések.
- Ezeket csak új, kifejezett felhasználói kérésre szabad visszatenni.

## Hátralévő, valódi környezetet igénylő ellenőrzések

- Cast/buff/bobber és hangdetektálás élő WoW klienssel.
- A teljes reconnect sorrend élő disconnecttel és elmentett profiljelszóval.
- 8 egyidejű klienses input-, recovery- és loot-izoláció.
- Blizzard API valódi credential/realm/AH lekérés, cache és history.
- WPF startup/shutdown, kijelölésmegőrzés és hosszú futású smoke test.
- Installer és a régi `AI-FishBot.lnk` átállítása nincs elkészítve; a self-contained `publish` mappából indítható.

## Fejlesztési szabály

Az alkalmazást a felhasználó kérésére a fejlesztés közben ne indítsuk el. Build és unit teszt csak a munka végén fusson; ezek nem küldenek WoW inputot. Élő inputpróba a felhasználónál történik.
