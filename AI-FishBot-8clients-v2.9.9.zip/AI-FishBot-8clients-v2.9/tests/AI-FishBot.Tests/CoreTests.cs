using AIFishBot.Application;
using AIFishBot.Core;
using AIFishBot.Infrastructure;
using Xunit;

namespace AIFishBot.Tests;
public sealed class CoreTests {
    [Fact] public async Task Profile_binding_survives_pid_change() { var state = new ApplicationState(); var manager = new ClientProfileManager(new MemoryStore(), state); var profile = new ClientProfile { DisplayName = "one" }; await manager.CreateProfileAsync(profile); manager.BindRuntimeProcess(profile.ProfileId, 100); manager.BindRuntimeProcess(profile.ProfileId, 200); Assert.Equal(200, state.Clients.Single().RuntimePid); Assert.Equal(profile.ProfileId, state.Clients.Single().ProfileId); }
    [Fact] public void Wyrmfish_is_case_and_whitespace_insensitive() { var engine = new StatisticsEngine(); var id = Guid.NewGuid(); engine.UpdateLoot(id, new LootSnapshot { Items = new() { ["  WYRMFISH "] = new LootItem { Name = "  WYRMFISH ", Count = 4 } } }); Assert.Equal(4, engine.GetClientStatistics(id).LifetimeWyrmfish); }
    [Fact] public void Bad_loot_does_not_change_statistics() { var engine = new StatisticsEngine(); var id = Guid.NewGuid(); engine.UpdateLoot(id, new LootSnapshot { Items = new() { ["Wyrmfish"] = new LootItem { Name = "Wyrmfish", Count = 5 } } }); engine.UpdateLoot(id, new LootSnapshot()); Assert.Equal(5, engine.GetClientStatistics(id).LifetimeWyrmfish); }
    [Fact] public async Task Queue_deduplicates_and_clears_fishing() { await using var queue = new ClientInputQueue(); var id = Guid.NewGuid(); await queue.EnqueueAsync(new InputCommand { ProfileId = id, Action = "cast", Priority = InputPriority.Fishing }); await queue.EnqueueAsync(new InputCommand { ProfileId = id, Action = "cast", Priority = InputPriority.Fishing }); queue.ClearFishing(); using var cts = new CancellationTokenSource(20); await Assert.ThrowsAnyAsync<OperationCanceledException>(() => queue.DequeueAsync(cts.Token)); }
    [Fact] public async Task Target_is_preserved_by_profile_update() { var store = new MemoryStore(); var state = new ApplicationState(); var manager = new ClientProfileManager(store, state); var profile = new ClientProfile { Target = new TargetConfiguration { Enabled = true, TargetAmount = 5000 } }; await manager.CreateProfileAsync(profile); await manager.LoadProfilesAsync(); Assert.Equal(5000, manager.Profiles.Single().Target.TargetAmount); }
    private sealed class MemoryStore : IProfileStore { private ApplicationSettings _value = new(); public Task<ApplicationSettings> LoadAsync(CancellationToken token = default) => Task.FromResult(_value); public Task SaveAsync(ApplicationSettings settings, CancellationToken token = default) { _value = settings; return Task.CompletedTask; } }
}
