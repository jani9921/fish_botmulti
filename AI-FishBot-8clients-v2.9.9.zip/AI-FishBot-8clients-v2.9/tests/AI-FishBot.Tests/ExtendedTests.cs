using AIFishBot.Application;
using AIFishBot.Core;
using AIFishBot.Infrastructure;
using Xunit;

namespace AIFishBot.Tests;

public sealed class ExtendedTests {
    [Fact]
    public void Native_input_structure_matches_windows_abi() => Assert.Equal(Environment.Is64BitProcess ? 40 : 28, WindowsInputExecutor.NativeInputSize);

    [Fact]
    public async Task Queue_prioritizes_recovery_and_deduplicates_inflight_commands() {
        await using var queue = new ClientInputQueue(); var profileId = Guid.NewGuid();
        var cast = new InputCommand { ProfileId = profileId, Priority = InputPriority.Fishing, Action = "Cast" };
        var recovery = new InputCommand { ProfileId = profileId, Priority = InputPriority.Recovery, Action = "Key", Key = "ENTER" };
        await queue.EnqueueAsync(cast); await queue.EnqueueAsync(recovery);
        var first = await queue.DequeueAsync(CancellationToken.None); Assert.Same(recovery, first); queue.Complete(first!);
        var second = await queue.DequeueAsync(CancellationToken.None); Assert.Same(cast, second);
        await queue.EnqueueAsync(new InputCommand { ProfileId = profileId, Priority = InputPriority.Fishing, Action = "Cast" }); Assert.Equal(0, queue.Count);
        queue.Complete(second!); await queue.EnqueueAsync(new InputCommand { ProfileId = profileId, Priority = InputPriority.Fishing, Action = "Cast" }); Assert.Equal(1, queue.Count);
    }

    [Fact]
    public async Task Queue_uses_v2_order_bobber_before_cast_buff_and_maintenance() {
        await using var queue = new ClientInputQueue(); var profileId = Guid.NewGuid();
        await queue.EnqueueAsync(new InputCommand { ProfileId = profileId, Priority = InputPriority.Maintenance, Action = "Reload" });
        await queue.EnqueueAsync(new InputCommand { ProfileId = profileId, Priority = InputPriority.Cast, Action = "Cast" });
        await queue.EnqueueAsync(new InputCommand { ProfileId = profileId, Priority = InputPriority.Buff, Action = "Buff", Key = "F9" });
        await queue.EnqueueAsync(new InputCommand { ProfileId = profileId, Priority = InputPriority.Bobber, Action = "Bobber" });
        var expected = new[] { "Bobber", "Cast", "Buff", "Reload" }; foreach (var action in expected) { var command = await queue.DequeueAsync(CancellationToken.None); Assert.Equal(action, command!.Action); queue.Complete(command); }
    }

    [Fact]
    public void Lua_parser_handles_nested_metadata_and_rejects_partial_data() {
        const string lua = "AIFishLootDB = { [\" Wyrmfish \"] = 12, [\"Other\"] = 2 }\nAIFishLootMeta = { version = \"1.3\", duplicateSuppressed = 4, itemIds = { [\" Wyrmfish \"] = 238377 } }";
        var parser = new LuaSavedVariablesParser(); var snapshot = parser.Parse(lua);
        Assert.True(snapshot.IsValid); Assert.Equal("1.3", snapshot.AddonVersion); Assert.Equal(4, snapshot.DuplicateSuppressed); Assert.Equal(238377, snapshot.Items["Wyrmfish"].ItemId);
        Assert.Throws<FormatException>(() => parser.Parse("AIFishLootDB = { [\"Wyrmfish\"] = 2"));
    }

    [Fact]
    public void Statistics_are_isolated_and_invalid_snapshot_keeps_last_known_good() {
        var engine = new StatisticsEngine(); var first = Guid.NewGuid(); var second = Guid.NewGuid();
        engine.UpdateLoot(first, Snapshot(3)); engine.UpdateLoot(second, Snapshot(8)); engine.UpdateLoot(first, new LootSnapshot { IsValid = false });
        Assert.Equal(3, engine.GetClientStatistics(first).LifetimeWyrmfish); Assert.Equal(8, engine.GetClientStatistics(second).LifetimeWyrmfish); Assert.Equal(11, engine.GetGlobalStatistics().Wyrmfish);
    }

    [Fact]
    public async Task Controller_commands_are_idempotent_and_new_start_gets_new_session() {
        var state = new ApplicationState(); var profiles = new ClientProfileManager(new MemoryStore(), state); var profile = new ClientProfile(); await profiles.CreateProfileAsync(profile); profiles.BindRuntimeProcess(profile.ProfileId, 42); await using var queues = new ClientInputQueueFactory(); var controller = new ClientController(state, profiles, queues);
        await controller.StartAsync(profile.ProfileId); var firstSession = state.Clients.Single().Session!.SessionId; await controller.StartAsync(profile.ProfileId); Assert.Equal(firstSession, state.Clients.Single().Session!.SessionId);
        await controller.PauseAsync(profile.ProfileId); await controller.PauseAsync(profile.ProfileId); Assert.Equal(FishingState.Paused, state.Clients.Single().FishingState);
        await controller.StopAsync(profile.ProfileId); await controller.StopAsync(profile.ProfileId); await controller.StartAsync(profile.ProfileId); Assert.NotEqual(firstSession, state.Clients.Single().Session!.SessionId);
    }

    [Fact]
    public void Target_notification_is_once_only_and_resets_after_target_change() {
        var state = new ApplicationState(); var revenue = new RevenueService(state, new FixedPriceService()); var profile = new ClientProfile { Target = new TargetConfiguration { Enabled = true, TargetAmount = 100, Currency = "GOLD" } }; var statistics = new ClientStatistics { RevenueGold = 120 };
        var progress = revenue.GetTargetProgress(profile, statistics); Assert.True(revenue.TryMarkTargetReached(profile, progress)); Assert.False(revenue.TryMarkTargetReached(profile, progress));
        profile.Target.TargetAmount = 200; progress = revenue.GetTargetProgress(profile, statistics); Assert.False(revenue.TryMarkTargetReached(profile, progress)); Assert.False(profile.Target.ReachedNotified);
    }

    [Fact]
    public async Task Atomic_settings_store_recovers_from_backup() {
        var directory = Path.Combine(Path.GetTempPath(), $"aifishbot-store-{Guid.NewGuid():N}");
        try { var store = new JsonProfileStore(directory); await store.SaveAsync(new ApplicationSettings { HufPerGold = 11 }); await store.SaveAsync(new ApplicationSettings { HufPerGold = 22 }); await File.WriteAllTextAsync(Path.Combine(directory, "settings.json"), "{broken"); Assert.Equal(11, (await store.LoadAsync()).HufPerGold); }
        finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
    }

    [Fact]
    public async Task V2_migration_keeps_password_keys_target_and_serial_settings() {
        var directory = Path.Combine(Path.GetTempPath(), $"aifishbot-migrate-{Guid.NewGuid():N}"); Directory.CreateDirectory(directory); var input = Path.Combine(directory, "ai-fishbot-settings.json");
        const string json = "{\"ClientProfiles\":[{\"WindowTitle\":\"Mage\",\"Selected\":true,\"Cast\":\"CTRL+F6\",\"Bobber\":\"F7\",\"Logout\":\"F8\",\"PasswordProtected\":\"cipher\",\"Buffs\":[]}],\"Config\":[{\"Path\":\"Target.TargetHuf\",\"Value\":\"12345\"},{\"Path\":\"Client.UsePi\",\"Value\":\"true\"},{\"Path\":\"Client.PicoComPort\",\"Value\":\"COM9\"}]}";
        try { await File.WriteAllTextAsync(input, json); var settings = new ApplicationSettings(); Assert.True(await new V2MigrationService().TryMigrateAsync(input, Path.Combine(directory, "backup"), settings)); var profile = Assert.Single(settings.Profiles); Assert.Equal("cipher", profile.EncryptedPassword); Assert.Equal("CTRL+F6", profile.Keybinds.Cast); Assert.Equal(12345, profile.Target.TargetAmount); Assert.True(settings.General.UseSerialInput); Assert.Equal(30, settings.Recovery.ActionPlan[3].WaitForConnectionSeconds); Assert.True(File.Exists(Path.Combine(directory, "backup", "v2-settings-backup.json"))); }
        finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
    }

    [Fact]
    public void SavedVariables_locator_uses_account_and_character_segments() {
        var directory = Path.Combine(Path.GetTempPath(), $"aifishbot-locator-{Guid.NewGuid():N}"); var executable = Path.Combine(directory, "Wow.exe"); var first = Path.Combine(directory, "WTF", "Account", "ACC1", "Realm", "Mage", "SavedVariables"); var second = Path.Combine(directory, "WTF", "Account", "ACC2", "Realm", "Warrior", "SavedVariables");
        try { Directory.CreateDirectory(first); Directory.CreateDirectory(second); File.WriteAllText(executable, ""); File.WriteAllText(Path.Combine(first, "AIFishLootTracker.lua"), ""); File.WriteAllText(Path.Combine(second, "AIFishLootTracker.lua"), ""); var matches = new SavedVariablesLocator().FindCandidates(new ClientProfile { AccountIdentifier = "ACC2", CharacterIdentifier = "Warrior" }, executable); Assert.Single(matches); Assert.Contains("Warrior", matches[0], StringComparison.OrdinalIgnoreCase); }
        finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
    }

    [Fact]
    public void Dpapi_round_trip_does_not_store_plaintext() { var protector = new DpapiSecretProtector(); var encrypted = protector.Protect("sample-password"); Assert.DoesNotContain("sample-password", encrypted, StringComparison.Ordinal); Assert.Equal("sample-password", protector.Unprotect(encrypted)); }

    [Fact]
    public async Task Schema_4_upgrade_installs_exact_reconnect_sequence() {
        var legacy = new ApplicationSettings { SchemaVersion = 3 }; legacy.Recovery.ActionPlan = [new RecoveryStep { Name = "Legacy", Key = "ENTER", WaitForConnectionSeconds = 8 }]; var store = new MemoryStore(legacy); var loaded = await new SettingsService(store).LoadAsync();
        Assert.Equal(4, loaded.SchemaVersion); Assert.Collection(loaded.Recovery.ActionPlan,
            step => AssertStep(step, "Key", "ENTER", 1),
            step => AssertStep(step, "Key", "CTRL+A", 1),
            step => AssertStep(step, "Password", null, 1),
            step => AssertStep(step, "Key", "ENTER", 30),
            step => AssertStep(step, "Key", "ENTER", 5));
    }

    private static LootSnapshot Snapshot(long count) => new() { Items = new(StringComparer.OrdinalIgnoreCase) { ["Wyrmfish"] = new LootItem { Name = "Wyrmfish", Count = count, ItemId = 238377 } } };
    private static void AssertStep(RecoveryStep step, string type, string? key, int wait) { Assert.Equal(type, step.Type, ignoreCase: true); Assert.Equal(key, step.Key); Assert.Equal(wait, step.WaitForConnectionSeconds); }
    private sealed class MemoryStore(ApplicationSettings? initial = null) : IProfileStore { private ApplicationSettings _settings = initial ?? new(); public Task<ApplicationSettings> LoadAsync(CancellationToken token = default) => Task.FromResult(_settings); public Task SaveAsync(ApplicationSettings settings, CancellationToken token = default) { _settings = settings; return Task.CompletedTask; } }
    private sealed class FixedPriceService : IPriceService { public IReadOnlyDictionary<int, ItemPrice> Prices => new Dictionary<int, ItemPrice>(); public Task RefreshAsync(IEnumerable<int> itemIds, CancellationToken token = default) => Task.CompletedTask; public decimal? GetUnitPriceGold(LootItem item) => 1; public PriceAnalysis Analyze(int itemId) => new(); }
}
