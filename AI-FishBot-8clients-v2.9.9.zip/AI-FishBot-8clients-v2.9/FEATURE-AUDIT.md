# V2 Feature Audit

Forrás: `AI-Fishbot.ps1` (v2.9), `AIFishLootTracker/AIFishLootTracker.lua` (v1.3), `README-HU.txt`.

Kategóriák: **A** = V3 kötelező parity; **B** = későbbi kiegészítő; **C** = kihagyva vagy funkcionálisan kiváltva; **D** = bizonytalan. A PID-alapú tartós identitást és a WinForms megvalósítást biztonságos V3 komponens váltja ki. A BootyBayBroker és Discord funkciókat a felhasználó 2026-08-31-én kifejezetten kivette a V3 scope-ból.

| V2 réteg / funkció | V2 függvények vagy fájl | Állapot | V3 modul | Kat. / prioritás |
|---|---|---|---|---|
| Globális konfiguráció és validálás | `$Config`, `Test-Configuration` | működő, monolitikus | Core `ApplicationSettings`, Settings UI, validator | A / P0 |
| Strukturált fájllog és exception-throttle | `Write-Log`, `Write-LogException` | működő | Infrastructure logging, secret redaction | A / P0 |
| Azonnali catch CSV journal | `Write-CatchJournal` | működő | Reporting `CatchJournalService` | A / P1 |
| NAudio telepítés és WASAPI session peak | `Ensure-NAudio`, `Get-AudioDeviceCached`, `Get-ClientAudioPeaks` | működő, runtime letöltés törékeny | Audio `IAudioPeakService`, NuGet NAudio | A / P0 |
| Futó WoW kliensek listázása/kiválasztása | `Show-ClientSelectorDialog`, `Refresh-SetupPidGrid`, `Get-SelectedSetupProfiles` | működő, PID-slot alapú | ProcessMonitor + WPF profile binding | A / P0 |
| Keybind alapérték/másolás/import/export | `New-DefaultKeybindMap`, `Copy-KeybindMap`, `Import-KeybindSlots`, `Save-KeybindSlots` | működő, slot-alapú | profilhoz kötött `KeybindConfiguration` + V2 migráció | A / P0 |
| Keybind validálás és SendKeys konverzió | `Test-KeySpec`, `ConvertTo-SendKeysSequence`, `Get-EscapedSendKeys` | működő | Input `KeySpecParser` | A / P0 |
| Keybind szerkesztő | `Show-ClientKeybindDialog` | működő WinForms | WPF Profile editor | A / P1 |
| Profilonkénti jelszó | `ConvertTo-ClientSecurePassword`, `Test-ClientHasPassword`, `Send-ClientPassword` | működő, runtime SecureString | DPAPI + profil secret service + redacted recovery input | A / P0 |
| Buff konfiguráció és állapotgép | `New-DefaultClientBuffConfig`, `Copy-ClientBuffConfig`, `Update-ClientBuffs` | működő | Fishing/Buff engine, per-profile config | A / P0 |
| Kliens runtime létrehozása | `New-ClientState`, `Initialize-SessionRuntime` | működő, PID az elsődleges kulcs | `ClientRuntime`, `ClientSession`, ProfileId | C: implementáció kiváltva / P0 |
| Automatizálás engedélyezése/reset | `Test-ClientAutomationEnabled`, `Clear-ClientInputQueue`, `Reset-ClientAutomationState` | működő | controller/state machine/input queue | A / P0 |
| START/PAUSE/STOP | `Set-ClientControlState` | működő | idempotens `ClientController` | A / P0 |
| Process életjel cache | `Test-ClientProcess` | működő | `ProcessMonitorService` | A / P0 |
| Ablak fókusz | `Focus-Client` | működő | Win32 input adapter | A / P0 |
| Nyers billentyű/Pico serial | `Send-RawKey` | működő | `WindowsInputSender`, `SerialInputSender` | A / P1 |
| Prioritásos, deduplikált input queue | `Queue-Input`, `Invoke-InputAction`, `Complete-Input`, `Process-InputQueue` | ismert V2 előzményhibával stabilizált | kliensenkénti Channel/PriorityQueue worker | A / P0 |
| Fishing state machine (cast/bobber/retry) | `Complete-Input`, `Invoke-MonitorTick` | működő, timerhez kötött | `FishingEngine` | A / P0 |
| TCP endpoint snapshot | `Get-WowNetworkSnapshot` + beágyazott `TcpTableReader` | működő IPv4 | `WindowsNetworkMonitor` | A / P0 |
| Network baseline/cache | `Update-NetworkTelemetry` | működő, IPv4 korlát | profil runtime network state | A / P0 |
| Recovery queue cleanup | `Clear-ClientPendingInputs` | működő | input queue cancel policy | A / P0 |
| Recovery siker/manual/backoff | `Complete-ClientRecovery`, `Set-ClientRecoveryManual`, `Move-ClientRecoveryToBackoffOrManual` | működő | `RecoveryEngine` | A / P0 |
| Recovery action plan | `Queue-NextRecoveryAction` | működő | konfigurálható recovery steps | A / P0 |
| Recovery state machine | `Update-ClientRecoveryState` | működő | kliensenkénti async recovery worker | A / P0 |
| SavedVariables fájlok felderítése | `Get-SavedVarFiles`, `Get-SavedVarSnapshot`, `Find-ChangedSavedVarFile` | működő, indulásonként újraköthet | explicit profilútvonal + egyszeri discovery | A / P0 |
| Loot DB/meta olvasás | `Update-LootLog` | regex-only, részleges írásra érzékeny | robust Lua parser + Last Known Good | A / P0 |
| Addon reset/reload/binding/sync | `Update-LootReloadState` | működő, lassú és PID-kötött | `LootSyncService` profilútvonallal | A / P0 |
| Magyar napnév | `Get-HungarianDayName` | működő | price analysis formatter | A / P2 |
| Percentilis és price history sor | `Get-PricePercentile`, `Convert-PriceHistoryEntryToRow` | működő | `PriceAnalysisService` | A / P1 |
| Price history import/export/prune | `Import-PriceHistory`, `Export-PriceHistory`, `Prune-PriceHistory` | működő CSV | atomic price history store | A / P1 |
| Blizzard snapshot history | `Add-BlizzardPriceHistorySnapshot` | működő | price history service | A / P1 |
| Eladási tanács és confidence | `Get-ItemPriceAnalysis`, `Get-SellSignalColor`, `Update-SelectedItemDetails` | működő | price analysis + WPF detail panel | A / P1 |
| Árvalidálás/normalizálás/CSV mező | `Test-ValidPrice`, `ConvertTo-PositivePriceNumber`, `Get-RowValue`, `Get-ImportedUnitPriceGold` | működő | parsers/validators | A / P1 |
| Egységár prioritás | `Get-ItemUnitPrice` | működő | manual > Blizzard > fallback policy | A / P0 |
| BootyBay CSV import | `Import-BootyBayBrokerPrices` | működő | felhasználói döntéssel kihagyva | C / nincs |
| Price cache összegzés | `Update-PriceCacheSummary` | működő | diagnostics price status | A / P1 |
| Blizzard target ID-k | `Get-BlizzardTargetItemIds` | működő | item catalog | A / P1 |
| Blizzard cache import/export | `Import-BlizzardPriceCache`, `Export-BlizzardPriceCache` | működő | atomic JSON cache | A / P1 |
| Blizzard OAuth/realm/AH háttérlekérés | `Start-BlizzardAuctionPriceJob`, `Update-BlizzardAuctionPrices` | működő, PowerShell job | async `BlizzardAuctionService` | A / P1 |
| Több kliens loot aggregáció | `Get-AggregatedLootState`, `Add-LootCounts`, `Add-LootItemIds` | működő | `StatisticsEngine` | A / P0 |
| BootyBay inventory export/template/artifacts | `Export-BootyBayBrokerInventory`, `Update-PriceImportTemplate`, `Update-BootyBayBrokerArtifacts`, `Update-WyrmfishPrice` | működő | felhasználói döntéssel kihagyva | C / nincs |
| Safe number conversion | `ConvertTo-SafeNumber` | működő | numeric parser | A / P2 |
| Loot gold breakdown/total | `Get-LootGoldBreakdown`, `Get-LootGoldTotal` | működő | statistics/revenue service | A / P0 |
| Revenue gold/EUR/HUF és projekciók | `Get-RevenueStats` | működő | `RevenueService` | A / P0 |
| Target progress/remaining/ETA | `Get-TargetProgress` | működő | persistent target service | A / P0 |
| Aktív/pause/reload idő | `Update-ClientTimeAccumulators` | működő | session metrics | A / P1 |
| Kliens rate/metrika | `Get-ClientMetrics` | működő | statistics engine | A / P0 |
| Anomália felismerés | `Add-Alert`, `Test-ClientAnomalies` | működő | anomaly service + alert collection | A / P1 |
| Discord webhook | `Send-DiscordMessage`, `Send-ThrottledNotification` | működő | felhasználói döntéssel kihagyva | C / nincs |
| Session start/stop/warning/error/target esemény | `Send-SessionStartedEvent`, `Send-SessionStoppedEvent`, `Send-ClientWarningEvent`, `Send-ClientErrorEvent`, `Send-TargetReachedEvent` | működő | helyi alert/event log; Discord nélkül | A / P1 |
| Session CSV snapshot | `Add-ReportSnapshot` | működő | `SessionReportService` | A / P1 |
| Session JSON summary | `Export-SessionJsonSummary` | működő | `SessionReportService` | A / P1 |
| Gyors monitor ciklus | `Invoke-MonitorTick` | működő, egy szálas timer | több cancellable BackgroundService | C: implementáció kiváltva / P0 |
| DPAPI helper | `Protect-PlainTextForCurrentUser`, `Unprotect-PlainTextForCurrentUser`, `Get-SecureStringPlainText`, `Protect-SecureStringForCurrentUser` | működő | `ISecretProtector` | A / P0 |
| GUI config definíciók és típuskonverzió | `New-GuiConfigDefinition`, `Get-GuiConfigDefinitions`, `Get-ConfigContainerValue`, `Get-ConfigPathValue`, `Set-ConfigPathValue`, `Format-GuiConfigValue`, `Convert-GuiConfigValue` | működő | strongly typed settings VM | A / P1 |
| Setup grid alkalmazás/credentials | `Populate-SetupConfigGrid`, `Apply-SetupConfigGrid`, `Apply-SetupCredentialsFromGui` | működő | WPF binding/validation | A / P1 |
| GUI settings import/export/save | `Export-GuiSettings`, `Import-GuiSettings`, `Save-AllSetupSettings` | működő, PID-slot migrálandó | settings service + V2 migrator | A / P0 |
| Setup profile szerkesztő | `New-SetupClientProfile`, `Update-SetupPasswordStatusCell`, `Save-SetupProfileEditor`, `Load-SetupProfileEditor` | működő | WPF Profiles tab | A / P0 |
| Session start konfigurált kliensekkel | `Start-ConfiguredClientsFromSetup` | működő | controller start-all | A / P0 |
| WinForms UI felépítése | `New-InfoLabel`, `Build-MainForm` | működő, code-behind üzleti logikával | WPF/MVVM views | C: UI technológia kiváltva / P0 |
| Formázók és gridsor frissítés | `Format-Huf`, `Format-Duration`, `Update-ClientGridRow`, `Get-SelectedClientPidFromGrid`, `Format-GoldPrice`, `Update-LootItemGrid`, `Select-LootItemGridRow`, `Invoke-GuiRefresh` | működő, teljes refresh | converters + observable VM | A funkció / C implementáció / P1 |
| Kontrollált shutdown | `Stop-Monitor` | működő | host cancellation, final report, queue dispose | A / P0 |
| Entry point | 17. réteg | működő | Generic Host startup | A / P0 |
| Loot ablak/chat figyelés | `AIFishLootTracker.lua`: `AddLoot`, `HandleLootMessage`, `CaptureLootSlots` | működő | addon változatlanul szállítva | A / P0 |
| Loot duplikációszűrés | Lua `recentByName`, `seenLootSlots` | működő | addon változatlanul szállítva | A / P0 |
| `/aifishloot reset/status/debug` | Lua slash handler | működő | addon változatlanul szállítva | A / P1 |

## Nem átviendő hibás architekturális elemek

- PID vagy PID-sorrend mint tartós profilkulcs.
- Egyetlen globális input queue minden kliensre.
- GUI timerben végzett üzleti számítás és teljes grid refresh.
- Üres `catch {}` blokkok és runtime NuGet-letöltés.
- Minden induláskor új SavedVariables automatikus binding.

Ezek funkciója megmarad, de ProfileId-alapú, aszinkron, tesztelhető V3 szolgáltatásként.
