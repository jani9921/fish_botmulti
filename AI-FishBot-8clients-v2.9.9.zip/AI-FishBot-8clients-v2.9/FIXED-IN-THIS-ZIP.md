# Javítás ebben a ZIP-ben

A javítások a forráskódban vannak:

1. Loot szinkron: a program nem fogadja el új szinkronként ugyanazt a régi
   SavedVariables fájlt egy /reload után. Amíg a WoW ténylegesen nem ír új
   snapshotot, az állapot `WaitingForSavedVariables`, és a 10-es batch nem
   nullázódik el.

2. Wyrmfish: a retail Arcane Wyrmfish item ID alapértéke és a keményen kódolt
   felismerés 238377.

Megjegyzés: a `publish-github` előre fordított DLL/EXE fájljai nem lettek
újrafordítva ebben a környezetben, mert nincs telepített .NET SDK. A javított
forrás a ZIP-ben van, ezért a futó EXE-hez Windows alatt új build/publish kell.
