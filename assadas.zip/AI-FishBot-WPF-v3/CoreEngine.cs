using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;
using NAudio.CoreAudioApi;

namespace AIFishBotWpf {
  // The runtime engine is intentionally independent from the WPF controls.
  public enum FishingPhase { NeedCast, AwaitingBite, ClickBobber, PostCatch, Paused, Stopped, Recovering }
  public enum BotActionKind { Cast, Bobber, Buff, Logout, Reload, BindLoot, RecoveryKey, RecoveryPassword }
  public sealed class BotAction { public string ClientId; public BotActionKind Kind; public string Key; public string Text; public int Priority; public int HoldMilliseconds; public DateTime DueUtc; public int RetryCount; public Action<bool> Completed; }
  public sealed class RuntimeClient {
    public ClientProfile Profile; public FishingPhase Phase=FishingPhase.NeedCast; public DateTime NextUtc=DateTime.UtcNow;
    public DateTime CastDeadlineUtc; public int HookCount, NoBiteStreak, RecoveryAttempts; public bool ProcessAlive, NeedsManualHelp;
    public DateTime NetworkLostSinceUtc=DateTime.MinValue; public string RecoveryReason="";
  }
  public sealed class BotLog {
    readonly string _file; readonly object _gate=new object(); public bool Enabled=true; public bool Debug;
    public BotLog(string directory){Directory.CreateDirectory(directory);_file=Path.Combine(directory,"ai-fishbot-wpf.log");}
    public void Write(string level,string text){if(!Enabled||(level=="DEBUG"&&!Debug))return;lock(_gate)File.AppendAllText(_file,DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" ["+level+"] "+text+Environment.NewLine,new UTF8Encoding(false));}
  }
  public sealed class WasapiPeakReader : IDisposable {
    MMDeviceEnumerator _enumerator; MMDevice _device;
    public Dictionary<int,double> Read(IEnumerable<int> pids) { var wanted=new HashSet<int>(pids);var result=new Dictionary<int,double>();if(wanted.Count==0)return result;try{if(_enumerator==null)_enumerator=new MMDeviceEnumerator();if(_device==null)_device=_enumerator.GetDefaultAudioEndpoint(DataFlow.Render,Role.Multimedia);var sessions=_device.AudioSessionManager.Sessions;for(int i=0;i<sessions.Count;i++){var session=sessions[i];int pid=(int)session.GetProcessID;if(!wanted.Contains(pid))continue;double peak=session.AudioMeterInformation.MasterPeakValue*100d;double old;if(!result.TryGetValue(pid,out old)||peak>old)result[pid]=peak;}}catch{Dispose();}return result; }
    public void Dispose(){if(_device!=null){_device.Dispose();_device=null;}if(_enumerator!=null){_enumerator.Dispose();_enumerator=null;}}
  }
  public sealed class RuntimeQueue {
    readonly List<BotAction> _actions=new List<BotAction>(); readonly HashSet<string> _pending=new HashSet<string>(); readonly object _gate=new object();
    static string Key(BotAction a){return a.ClientId+"|"+a.Kind;}
    public bool Enqueue(BotAction action){lock(_gate){var key=Key(action);if(_pending.Contains(key))return false;_pending.Add(key);_actions.Add(action);return true;}}
    public BotAction TakeDue(){lock(_gate){var now=DateTime.UtcNow;var a=_actions.Where(x=>x.DueUtc<=now).OrderBy(x=>x.Priority).ThenBy(x=>x.DueUtc).FirstOrDefault();if(a!=null){_actions.Remove(a);_pending.Remove(Key(a));}return a;}}
    public int Count { get { lock(_gate)return _actions.Count; } }
    public void Clear(string clientId){lock(_gate){_actions.RemoveAll(x=>x.ClientId==clientId);foreach(var x in _pending.Where(x=>x.StartsWith(clientId+"|",StringComparison.Ordinal)).ToArray())_pending.Remove(x);}}
  }
  public sealed class SessionReporter {
    readonly string _directory; public SessionReporter(string directory){_directory=directory;Directory.CreateDirectory(directory);}
    public void Snapshot(IEnumerable<RuntimeClient> clients){var path=Path.Combine(_directory,"session.csv");var rows=clients.Select(c=>DateTime.UtcNow.ToString("o")+","+c.Profile.Pid+","+c.Phase+","+c.HookCount+","+c.Profile.Status);File.AppendAllLines(path,rows);}
    public void Catch(ClientProfile client){var path=Path.Combine(_directory,"catches.csv");if(!File.Exists(path))File.AppendAllText(path,"Timestamp,PID,HookCount\r\n",new UTF8Encoding(false));File.AppendAllText(path,DateTime.UtcNow.ToString("o")+","+client.Pid+","+client.HookCount+"\r\n",new UTF8Encoding(false));}
    public void JsonSummary(object model){File.WriteAllText(Path.Combine(_directory,"session-summary.json"),new JavaScriptSerializer{MaxJsonLength=int.MaxValue}.Serialize(model),new UTF8Encoding(false));}
  }
  public sealed class DiscordNotifier {
    public async void Send(string webhook,string text){if(string.IsNullOrWhiteSpace(webhook))return;try{using(var http=new HttpClient()){await http.PostAsync(webhook,new StringContent("{\"content\":\""+text.Replace("\\","\\\\").Replace("\"","\\\"")+"\"}",Encoding.UTF8,"application/json"));}}catch{}}
  }
  public sealed class TcpPidMonitor {
    const int AF_INET=2,ERROR_INSUFFICIENT_BUFFER=122,TCP_TABLE_OWNER_PID_ALL=5; const uint ESTABLISHED=5;
    [StructLayout(LayoutKind.Sequential)] struct Row { public uint state,localAddr,localPort,remoteAddr,remotePort,owningPid; }
    [DllImport("iphlpapi.dll",SetLastError=true)] static extern uint GetExtendedTcpTable(IntPtr table,ref int size,bool order,int version,int tableClass,uint reserved);
    static int Port(uint raw){var b=BitConverter.GetBytes(raw);return (b[0]<<8)+b[1];}
    public Dictionary<int,List<int>> EstablishedRemotePorts(){var result=new Dictionary<int,List<int>>();int size=0;var first=GetExtendedTcpTable(IntPtr.Zero,ref size,false,AF_INET,TCP_TABLE_OWNER_PID_ALL,0);if(first!=ERROR_INSUFFICIENT_BUFFER||size<=0)return result;var ptr=Marshal.AllocHGlobal(size);try{if(GetExtendedTcpTable(ptr,ref size,false,AF_INET,TCP_TABLE_OWNER_PID_ALL,0)!=0)return result;int count=Marshal.ReadInt32(ptr);int rowSize=Marshal.SizeOf(typeof(Row));var rowPtr=IntPtr.Add(ptr,4);for(int i=0;i<count;i++){var row=(Row)Marshal.PtrToStructure(rowPtr,typeof(Row));rowPtr=IntPtr.Add(rowPtr,rowSize);if(row.state!=ESTABLISHED)continue;int pid=(int)row.owningPid,port=Port(row.remotePort);List<int> ports;if(!result.TryGetValue(pid,out ports)){ports=new List<int>();result[pid]=ports;}ports.Add(port);}}finally{Marshal.FreeHGlobal(ptr);}return result;}
    public bool IsConnected(int pid,IEnumerable<int> serverPorts,IEnumerable<int> ignored){var map=EstablishedRemotePorts();List<int> ports;if(!map.TryGetValue(pid,out ports))return false;var wanted=new HashSet<int>(serverPorts??new int[0]);var skip=new HashSet<int>(ignored??new int[0]);return wanted.Count>0?ports.Any(wanted.Contains):ports.Any(p=>!skip.Contains(p));}
  }
}
